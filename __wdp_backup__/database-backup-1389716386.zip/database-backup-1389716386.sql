DROP TABLE IF EXISTS `wp_bwps_lockouts`;

CREATE TABLE `wp_bwps_lockouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(1) NOT NULL,
  `active` int(1) NOT NULL,
  `starttime` int(10) NOT NULL,
  `exptime` int(10) NOT NULL,
  `host` varchar(20) DEFAULT NULL,
  `user` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `wp_bwps_log`;

CREATE TABLE `wp_bwps_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(1) NOT NULL,
  `timestamp` int(10) NOT NULL,
  `host` varchar(20) DEFAULT NULL,
  `user` bigint(20) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `mem_used` varchar(255) DEFAULT NULL,
  `referrer` varchar(255) DEFAULT NULL,
  `data` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

INSERT INTO `wp_bwps_log` VALUES("1","2","1389711993","94.153.65.238","0","","/stretching/206","","http://narkologiya-voronezh.ru/","");
INSERT INTO `wp_bwps_log` VALUES("2","2","1389711994","94.153.65.238","0","","/stretching/206","","http://narkologiya-voronezh.ru/","");
INSERT INTO `wp_bwps_log` VALUES("3","2","1389711994","94.153.65.238","0","","/stretching/206","","http://narkologiya-voronezh.ru/","");
INSERT INTO `wp_bwps_log` VALUES("4","2","1389712514","2.88.11.45","0","","/wp-content/uploads/2011/05/trigger_point_chart.jpg","","","");
INSERT INTO `wp_bwps_log` VALUES("5","2","1389712761","174.102.212.147","0","","/wp-content/uploads/2013/01/wpid-20130123_105451.jpg","","http://www.bing.com/images/search?q=cupping+him&amp;qs=n&amp;form=QBIR&amp;pq=cupping+him&amp;sc=7-11&amp;sp=-1&amp;sk=","");
INSERT INTO `wp_bwps_log` VALUES("6","2","1389712801","174.102.212.147","0","","/wp-content/uploads/2013/01/wpid-20130123_105512.jpg","","http://www.bing.com/images/search?q=cupping+him&amp;qs=n&amp;form=QBIR&amp;pq=cupping+him&amp;sc=7-11&amp;sp=-1&amp;sk=","");
INSERT INTO `wp_bwps_log` VALUES("7","2","1389713512","199.15.233.176","0","","/stretching/206/","","http://www.kwmassage.com/stretching/206/","");
INSERT INTO `wp_bwps_log` VALUES("8","2","1389713683","66.249.73.25","0","","/new-clients","","","");
INSERT INTO `wp_bwps_log` VALUES("9","2","1389714900","216.16.232.115","0","","/images/internet_explorer/borderTopLeft.png","","","");
INSERT INTO `wp_bwps_log` VALUES("10","2","1389714900","216.16.232.115","0","","/images/internet_explorer/borderTopCenter.png","","","");
INSERT INTO `wp_bwps_log` VALUES("11","2","1389714900","216.16.232.115","0","","/images/internet_explorer/borderTopRight.png","","","");
INSERT INTO `wp_bwps_log` VALUES("12","2","1389714901","216.16.232.115","0","","/images/internet_explorer/borderMiddleLeft.png","","","");
INSERT INTO `wp_bwps_log` VALUES("13","2","1389714901","216.16.232.115","0","","/images/internet_explorer/borderMiddleRight.png","","","");
INSERT INTO `wp_bwps_log` VALUES("14","2","1389714901","216.16.232.115","0","","/images/internet_explorer/borderBottomLeft.png","","","");
INSERT INTO `wp_bwps_log` VALUES("15","2","1389714902","216.16.232.115","0","","/images/internet_explorer/borderBottomCenter.png","","","");
INSERT INTO `wp_bwps_log` VALUES("16","2","1389714902","216.16.232.115","0","","/images/internet_explorer/borderBottomRight.png","","","");
INSERT INTO `wp_bwps_log` VALUES("17","2","1389715714","157.55.34.93","0","","/rock_climbing/aerobic-vs-anaerobic-training-for-rock-climbing","","","");
INSERT INTO `wp_bwps_log` VALUES("18","1","1389715830","95.163.75.18","0","admin","","","","");
INSERT INTO `wp_bwps_log` VALUES("19","1","1389715830","95.163.75.18","0","admin","","","","");
INSERT INTO `wp_bwps_log` VALUES("20","1","1389715831","95.163.75.18","0","admin","","","","");
INSERT INTO `wp_bwps_log` VALUES("21","1","1389715847","95.163.75.18","0","admin","","","","");
INSERT INTO `wp_bwps_log` VALUES("22","2","1389715975","157.55.32.89","0","","/category/rock_climbing","","","");


DROP TABLE IF EXISTS `wp_commentmeta`;

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

INSERT INTO `wp_commentmeta` VALUES("1","3","akismet_error","1389564076");
INSERT INTO `wp_commentmeta` VALUES("2","3","akismet_history","a:4:{s:4:\"time\";d:1389564076.953030109405517578125;s:7:\"message\";s:92:\"Akismet was unable to check this comment (response: ), will automatically retry again later.\";s:5:\"event\";s:11:\"check-error\";s:4:\"user\";s:0:\"\";}");
INSERT INTO `wp_commentmeta` VALUES("3","3","akismet_as_submitted","a:44:{s:15:\"comment_post_ID\";i:211;s:14:\"comment_author\";s:43:\"Does Deep Tissue Massage Heart? | KWmassage\";s:18:\"comment_author_url\";s:77:\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\";s:20:\"comment_author_email\";s:0:\"\";s:15:\"comment_content\";s:414:\"[&#8230;] Often Deep Tissue massage therapy will cause some tenderness when your massage therapist is working hard to work out the tension, scar tissue, and trigger points from your muscles and ligaments. And yes, sometimes you will feel a little stiffness the day after. Most often, this soreness is a welcome relief as your therapist has the skill to pinpoint the source of your pain and work it out. [&#8230;]\";s:12:\"comment_type\";s:8:\"pingback\";s:7:\"user_ip\";s:13:\"69.90.161.250\";s:10:\"user_agent\";s:48:\"The Incutio XML-RPC PHP Library -- WordPress/3.8\";s:8:\"referrer\";N;s:4:\"blog\";s:24:\"http://www.kwmassage.com\";s:9:\"blog_lang\";s:5:\"en_US\";s:12:\"blog_charset\";s:5:\"UTF-8\";s:9:\"permalink\";s:74:\"http://www.kwmassage.com/generalmassagetherapy/what-is-deep-tissue-massage\";s:21:\"akismet_comment_nonce\";s:6:\"failed\";s:15:\"SERVER_SOFTWARE\";s:6:\"Apache\";s:11:\"REQUEST_URI\";s:11:\"/xmlrpc.php\";s:14:\"CONTENT_LENGTH\";s:3:\"339\";s:12:\"CONTENT_TYPE\";s:8:\"text/xml\";s:13:\"DOCUMENT_ROOT\";s:26:\"/home/kwma2903/public_html\";s:17:\"GATEWAY_INTERFACE\";s:7:\"CGI/1.1\";s:11:\"HTTP_ACCEPT\";s:3:\"*/*\";s:20:\"HTTP_ACCEPT_ENCODING\";s:29:\"deflate;q=1.0, compress;q=0.5\";s:9:\"HTTP_HOST\";s:17:\"www.kwmassage.com\";s:15:\"HTTP_USER_AGENT\";s:48:\"The Incutio XML-RPC PHP Library -- WordPress/3.8\";s:4:\"PATH\";s:13:\"/bin:/usr/bin\";s:12:\"QUERY_STRING\";s:0:\"\";s:15:\"REDIRECT_STATUS\";s:3:\"200\";s:11:\"REMOTE_ADDR\";s:13:\"69.90.161.250\";s:11:\"REMOTE_PORT\";s:5:\"41042\";s:14:\"REQUEST_METHOD\";s:4:\"POST\";s:15:\"SCRIPT_FILENAME\";s:37:\"/home/kwma2903/public_html/xmlrpc.php\";s:11:\"SCRIPT_NAME\";s:11:\"/xmlrpc.php\";s:11:\"SERVER_ADDR\";s:13:\"69.90.161.250\";s:12:\"SERVER_ADMIN\";s:23:\"webmaster@kwmassage.com\";s:11:\"SERVER_NAME\";s:17:\"www.kwmassage.com\";s:11:\"SERVER_PORT\";s:2:\"80\";s:15:\"SERVER_PROTOCOL\";s:8:\"HTTP/1.0\";s:16:\"SERVER_SIGNATURE\";s:0:\"\";s:9:\"UNIQUE_ID\";s:24:\"UtMQq0VaofoAABcbTPkAAAAu\";s:8:\"PHP_SELF\";s:11:\"/xmlrpc.php\";s:12:\"REQUEST_TIME\";s:10:\"1389564075\";s:4:\"argv\";s:0:\"\";s:4:\"argc\";s:1:\"0\";s:25:\"comment_post_modified_gmt\";s:19:\"2014-01-12 21:56:01\";}");
INSERT INTO `wp_commentmeta` VALUES("4","4","akismet_error","1389565059");
INSERT INTO `wp_commentmeta` VALUES("5","4","akismet_history","a:4:{s:4:\"time\";d:1389565059.589704036712646484375;s:7:\"message\";s:92:\"Akismet was unable to check this comment (response: ), will automatically retry again later.\";s:5:\"event\";s:11:\"check-error\";s:4:\"user\";s:0:\"\";}");
INSERT INTO `wp_commentmeta` VALUES("6","4","akismet_as_submitted","a:44:{s:15:\"comment_post_ID\";i:211;s:14:\"comment_author\";s:52:\"Trigger Points and Trigger Point Therapy | KWmassage\";s:18:\"comment_author_url\";s:87:\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\";s:20:\"comment_author_email\";s:0:\"\";s:15:\"comment_content\";s:185:\"[&#8230;] Kitchener Massage Therapy I use a few different Deep Tissue Massage techniques like muscle stripping, direct pressure held for up to a minute, and stretchingto treat [&#8230;]\";s:12:\"comment_type\";s:8:\"pingback\";s:7:\"user_ip\";s:13:\"69.90.161.250\";s:10:\"user_agent\";s:48:\"The Incutio XML-RPC PHP Library -- WordPress/3.8\";s:8:\"referrer\";N;s:4:\"blog\";s:24:\"http://www.kwmassage.com\";s:9:\"blog_lang\";s:5:\"en_US\";s:12:\"blog_charset\";s:5:\"UTF-8\";s:9:\"permalink\";s:74:\"http://www.kwmassage.com/generalmassagetherapy/what-is-deep-tissue-massage\";s:21:\"akismet_comment_nonce\";s:6:\"failed\";s:15:\"SERVER_SOFTWARE\";s:6:\"Apache\";s:11:\"REQUEST_URI\";s:11:\"/xmlrpc.php\";s:14:\"CONTENT_LENGTH\";s:3:\"362\";s:12:\"CONTENT_TYPE\";s:8:\"text/xml\";s:13:\"DOCUMENT_ROOT\";s:26:\"/home/kwma2903/public_html\";s:17:\"GATEWAY_INTERFACE\";s:7:\"CGI/1.1\";s:11:\"HTTP_ACCEPT\";s:3:\"*/*\";s:20:\"HTTP_ACCEPT_ENCODING\";s:29:\"deflate;q=1.0, compress;q=0.5\";s:9:\"HTTP_HOST\";s:17:\"www.kwmassage.com\";s:15:\"HTTP_USER_AGENT\";s:48:\"The Incutio XML-RPC PHP Library -- WordPress/3.8\";s:4:\"PATH\";s:13:\"/bin:/usr/bin\";s:12:\"QUERY_STRING\";s:0:\"\";s:15:\"REDIRECT_STATUS\";s:3:\"200\";s:11:\"REMOTE_ADDR\";s:13:\"69.90.161.250\";s:11:\"REMOTE_PORT\";s:5:\"46053\";s:14:\"REQUEST_METHOD\";s:4:\"POST\";s:15:\"SCRIPT_FILENAME\";s:37:\"/home/kwma2903/public_html/xmlrpc.php\";s:11:\"SCRIPT_NAME\";s:11:\"/xmlrpc.php\";s:11:\"SERVER_ADDR\";s:13:\"69.90.161.250\";s:12:\"SERVER_ADMIN\";s:23:\"webmaster@kwmassage.com\";s:11:\"SERVER_NAME\";s:17:\"www.kwmassage.com\";s:11:\"SERVER_PORT\";s:2:\"80\";s:15:\"SERVER_PROTOCOL\";s:8:\"HTTP/1.0\";s:16:\"SERVER_SIGNATURE\";s:0:\"\";s:9:\"UNIQUE_ID\";s:24:\"UtMUgkVaofoAACDsRmsAAABA\";s:8:\"PHP_SELF\";s:11:\"/xmlrpc.php\";s:12:\"REQUEST_TIME\";s:10:\"1389565058\";s:4:\"argv\";s:0:\"\";s:4:\"argc\";s:1:\"0\";s:25:\"comment_post_modified_gmt\";s:19:\"2014-01-12 21:56:01\";}");
INSERT INTO `wp_commentmeta` VALUES("7","4","akismet_history","a:4:{s:4:\"time\";d:1389565221.881247997283935546875;s:7:\"message\";s:44:\"admin changed the comment status to approved\";s:5:\"event\";s:15:\"status-approved\";s:4:\"user\";s:5:\"admin\";}");
INSERT INTO `wp_commentmeta` VALUES("8","3","akismet_history","a:4:{s:4:\"time\";d:1389565221.8841030597686767578125;s:7:\"message\";s:44:\"admin changed the comment status to approved\";s:5:\"event\";s:15:\"status-approved\";s:4:\"user\";s:5:\"admin\";}");
INSERT INTO `wp_commentmeta` VALUES("9","4","akismet_history","a:4:{s:4:\"time\";d:1389565640.129745960235595703125;s:7:\"message\";s:46:\"admin changed the comment status to unapproved\";s:5:\"event\";s:17:\"status-unapproved\";s:4:\"user\";s:5:\"admin\";}");
INSERT INTO `wp_commentmeta` VALUES("10","3","akismet_history","a:4:{s:4:\"time\";d:1389565643.8777139186859130859375;s:7:\"message\";s:46:\"admin changed the comment status to unapproved\";s:5:\"event\";s:17:\"status-unapproved\";s:4:\"user\";s:5:\"admin\";}");
INSERT INTO `wp_commentmeta` VALUES("11","5","akismet_error","1389623964");
INSERT INTO `wp_commentmeta` VALUES("12","5","akismet_history","a:4:{s:4:\"time\";d:1389623964.4831950664520263671875;s:7:\"message\";s:92:\"Akismet was unable to check this comment (response: ), will automatically retry again later.\";s:5:\"event\";s:11:\"check-error\";s:4:\"user\";s:0:\"\";}");
INSERT INTO `wp_commentmeta` VALUES("13","5","akismet_as_submitted","a:44:{s:15:\"comment_post_ID\";i:7;s:14:\"comment_author\";s:47:\"Note to New Massage Therapy Clients | KWmassage\";s:18:\"comment_author_url\";s:82:\"http://www.kwmassage.com/generalmassagetherapy/note-to-new-massage-therapy-clients\";s:20:\"comment_author_email\";s:0:\"\";s:15:\"comment_content\";s:32:\"[&#8230;] Appointments [&#8230;]\";s:12:\"comment_type\";s:8:\"pingback\";s:7:\"user_ip\";s:13:\"69.90.161.250\";s:10:\"user_agent\";s:48:\"The Incutio XML-RPC PHP Library -- WordPress/3.8\";s:8:\"referrer\";N;s:4:\"blog\";s:24:\"http://www.kwmassage.com\";s:9:\"blog_lang\";s:5:\"en_US\";s:12:\"blog_charset\";s:5:\"UTF-8\";s:9:\"permalink\";s:43:\"http://www.kwmassage.com/clinic-information\";s:21:\"akismet_comment_nonce\";s:6:\"failed\";s:15:\"SERVER_SOFTWARE\";s:6:\"Apache\";s:11:\"REQUEST_URI\";s:11:\"/xmlrpc.php\";s:14:\"CONTENT_LENGTH\";s:3:\"326\";s:12:\"CONTENT_TYPE\";s:8:\"text/xml\";s:13:\"DOCUMENT_ROOT\";s:26:\"/home/kwma2903/public_html\";s:17:\"GATEWAY_INTERFACE\";s:7:\"CGI/1.1\";s:11:\"HTTP_ACCEPT\";s:3:\"*/*\";s:20:\"HTTP_ACCEPT_ENCODING\";s:29:\"deflate;q=1.0, compress;q=0.5\";s:9:\"HTTP_HOST\";s:17:\"www.kwmassage.com\";s:15:\"HTTP_USER_AGENT\";s:48:\"The Incutio XML-RPC PHP Library -- WordPress/3.8\";s:4:\"PATH\";s:13:\"/bin:/usr/bin\";s:12:\"QUERY_STRING\";s:0:\"\";s:15:\"REDIRECT_STATUS\";s:3:\"200\";s:11:\"REMOTE_ADDR\";s:13:\"69.90.161.250\";s:11:\"REMOTE_PORT\";s:5:\"42754\";s:14:\"REQUEST_METHOD\";s:4:\"POST\";s:15:\"SCRIPT_FILENAME\";s:37:\"/home/kwma2903/public_html/xmlrpc.php\";s:11:\"SCRIPT_NAME\";s:11:\"/xmlrpc.php\";s:11:\"SERVER_ADDR\";s:13:\"69.90.161.250\";s:12:\"SERVER_ADMIN\";s:23:\"webmaster@kwmassage.com\";s:11:\"SERVER_NAME\";s:17:\"www.kwmassage.com\";s:11:\"SERVER_PORT\";s:2:\"80\";s:15:\"SERVER_PROTOCOL\";s:8:\"HTTP/1.0\";s:16:\"SERVER_SIGNATURE\";s:0:\"\";s:9:\"UNIQUE_ID\";s:24:\"UtP6mkVaofoAAGZSsEIAAAAA\";s:8:\"PHP_SELF\";s:11:\"/xmlrpc.php\";s:12:\"REQUEST_TIME\";s:10:\"1389623962\";s:4:\"argv\";s:0:\"\";s:4:\"argc\";s:1:\"0\";s:25:\"comment_post_modified_gmt\";s:19:\"2014-01-12 20:13:42\";}");
INSERT INTO `wp_commentmeta` VALUES("14","6","akismet_error","1389630419");
INSERT INTO `wp_commentmeta` VALUES("15","6","akismet_history","a:4:{s:4:\"time\";d:1389630419.4831790924072265625;s:7:\"message\";s:92:\"Akismet was unable to check this comment (response: ), will automatically retry again later.\";s:5:\"event\";s:11:\"check-error\";s:4:\"user\";s:0:\"\";}");
INSERT INTO `wp_commentmeta` VALUES("16","6","akismet_as_submitted","a:44:{s:15:\"comment_post_ID\";i:211;s:14:\"comment_author\";s:47:\"Note to New Massage Therapy Clients | KWmassage\";s:18:\"comment_author_url\";s:82:\"http://www.kwmassage.com/generalmassagetherapy/note-to-new-massage-therapy-clients\";s:20:\"comment_author_email\";s:0:\"\";s:15:\"comment_content\";s:230:\"[&#8230;] will be using an assortment of massage techniques. Some of these can be relaxing and others can be kind of tender. In most cases, a little pain is necessary to get the results you are looking for from a massage [&#8230;]\";s:12:\"comment_type\";s:8:\"pingback\";s:7:\"user_ip\";s:13:\"69.90.161.250\";s:10:\"user_agent\";s:48:\"The Incutio XML-RPC PHP Library -- WordPress/3.8\";s:8:\"referrer\";N;s:4:\"blog\";s:24:\"http://www.kwmassage.com\";s:9:\"blog_lang\";s:5:\"en_US\";s:12:\"blog_charset\";s:5:\"UTF-8\";s:9:\"permalink\";s:74:\"http://www.kwmassage.com/generalmassagetherapy/what-is-deep-tissue-massage\";s:21:\"akismet_comment_nonce\";s:6:\"failed\";s:15:\"SERVER_SOFTWARE\";s:6:\"Apache\";s:11:\"REQUEST_URI\";s:11:\"/xmlrpc.php\";s:14:\"CONTENT_LENGTH\";s:3:\"344\";s:12:\"CONTENT_TYPE\";s:8:\"text/xml\";s:13:\"DOCUMENT_ROOT\";s:26:\"/home/kwma2903/public_html\";s:17:\"GATEWAY_INTERFACE\";s:7:\"CGI/1.1\";s:11:\"HTTP_ACCEPT\";s:3:\"*/*\";s:20:\"HTTP_ACCEPT_ENCODING\";s:29:\"deflate;q=1.0, compress;q=0.5\";s:9:\"HTTP_HOST\";s:17:\"www.kwmassage.com\";s:15:\"HTTP_USER_AGENT\";s:48:\"The Incutio XML-RPC PHP Library -- WordPress/3.8\";s:4:\"PATH\";s:13:\"/bin:/usr/bin\";s:12:\"QUERY_STRING\";s:0:\"\";s:15:\"REDIRECT_STATUS\";s:3:\"200\";s:11:\"REMOTE_ADDR\";s:13:\"69.90.161.250\";s:11:\"REMOTE_PORT\";s:5:\"48863\";s:14:\"REQUEST_METHOD\";s:4:\"POST\";s:15:\"SCRIPT_FILENAME\";s:37:\"/home/kwma2903/public_html/xmlrpc.php\";s:11:\"SCRIPT_NAME\";s:11:\"/xmlrpc.php\";s:11:\"SERVER_ADDR\";s:13:\"69.90.161.250\";s:12:\"SERVER_ADMIN\";s:23:\"webmaster@kwmassage.com\";s:11:\"SERVER_NAME\";s:17:\"www.kwmassage.com\";s:11:\"SERVER_PORT\";s:2:\"80\";s:15:\"SERVER_PROTOCOL\";s:8:\"HTTP/1.0\";s:16:\"SERVER_SIGNATURE\";s:0:\"\";s:9:\"UNIQUE_ID\";s:24:\"UtQT0UVaofoAAHuPToQAAAA1\";s:8:\"PHP_SELF\";s:11:\"/xmlrpc.php\";s:12:\"REQUEST_TIME\";s:10:\"1389630417\";s:4:\"argv\";s:0:\"\";s:4:\"argc\";s:1:\"0\";s:25:\"comment_post_modified_gmt\";s:19:\"2014-01-12 21:56:01\";}");
INSERT INTO `wp_commentmeta` VALUES("17","7","akismet_error","1389635283");
INSERT INTO `wp_commentmeta` VALUES("18","7","akismet_history","a:4:{s:4:\"time\";d:1389635283.25652408599853515625;s:7:\"message\";s:92:\"Akismet was unable to check this comment (response: ), will automatically retry again later.\";s:5:\"event\";s:11:\"check-error\";s:4:\"user\";s:0:\"\";}");
INSERT INTO `wp_commentmeta` VALUES("19","7","akismet_as_submitted","a:44:{s:15:\"comment_post_ID\";i:216;s:14:\"comment_author\";s:52:\"Trigger Points and Trigger Point Therapy | KWmassage\";s:18:\"comment_author_url\";s:87:\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\";s:20:\"comment_author_email\";s:0:\"\";s:15:\"comment_content\";s:418:\"[&#8230;] It is uncomfortable to have a Trigger Point worked out but the relief you get from the headache, sore back or whatever it is you are experiencing can be great. My clients often describe the pain from Trigger Point work as a good pain . I think this stems from the fact that someone has finally been able to pinpoint and address the source of their discomfort after what could have been many years. [&#8230;]\";s:12:\"comment_type\";s:8:\"pingback\";s:7:\"user_ip\";s:13:\"69.90.161.250\";s:10:\"user_agent\";s:48:\"The Incutio XML-RPC PHP Library -- WordPress/3.8\";s:8:\"referrer\";N;s:4:\"blog\";s:24:\"http://www.kwmassage.com\";s:9:\"blog_lang\";s:5:\"en_US\";s:12:\"blog_charset\";s:5:\"UTF-8\";s:9:\"permalink\";s:77:\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\";s:21:\"akismet_comment_nonce\";s:6:\"failed\";s:15:\"SERVER_SOFTWARE\";s:6:\"Apache\";s:11:\"REQUEST_URI\";s:11:\"/xmlrpc.php\";s:14:\"CONTENT_LENGTH\";s:3:\"365\";s:12:\"CONTENT_TYPE\";s:8:\"text/xml\";s:13:\"DOCUMENT_ROOT\";s:26:\"/home/kwma2903/public_html\";s:17:\"GATEWAY_INTERFACE\";s:7:\"CGI/1.1\";s:11:\"HTTP_ACCEPT\";s:3:\"*/*\";s:20:\"HTTP_ACCEPT_ENCODING\";s:29:\"deflate;q=1.0, compress;q=0.5\";s:9:\"HTTP_HOST\";s:17:\"www.kwmassage.com\";s:15:\"HTTP_USER_AGENT\";s:48:\"The Incutio XML-RPC PHP Library -- WordPress/3.8\";s:4:\"PATH\";s:13:\"/bin:/usr/bin\";s:12:\"QUERY_STRING\";s:0:\"\";s:15:\"REDIRECT_STATUS\";s:3:\"200\";s:11:\"REMOTE_ADDR\";s:13:\"69.90.161.250\";s:11:\"REMOTE_PORT\";s:5:\"46087\";s:14:\"REQUEST_METHOD\";s:4:\"POST\";s:15:\"SCRIPT_FILENAME\";s:37:\"/home/kwma2903/public_html/xmlrpc.php\";s:11:\"SCRIPT_NAME\";s:11:\"/xmlrpc.php\";s:11:\"SERVER_ADDR\";s:13:\"69.90.161.250\";s:12:\"SERVER_ADMIN\";s:23:\"webmaster@kwmassage.com\";s:11:\"SERVER_NAME\";s:17:\"www.kwmassage.com\";s:11:\"SERVER_PORT\";s:2:\"80\";s:15:\"SERVER_PROTOCOL\";s:8:\"HTTP/1.0\";s:16:\"SERVER_SIGNATURE\";s:0:\"\";s:9:\"UNIQUE_ID\";s:24:\"UtQm0UVaofoAADBgKsEAAABF\";s:8:\"PHP_SELF\";s:11:\"/xmlrpc.php\";s:12:\"REQUEST_TIME\";s:10:\"1389635281\";s:4:\"argv\";s:0:\"\";s:4:\"argc\";s:1:\"0\";s:25:\"comment_post_modified_gmt\";s:19:\"2014-01-12 22:01:27\";}");
INSERT INTO `wp_commentmeta` VALUES("20","8","akismet_error","1389642499");
INSERT INTO `wp_commentmeta` VALUES("21","8","akismet_history","a:4:{s:4:\"time\";d:1389642499.9538009166717529296875;s:7:\"message\";s:92:\"Akismet was unable to check this comment (response: ), will automatically retry again later.\";s:5:\"event\";s:11:\"check-error\";s:4:\"user\";s:0:\"\";}");
INSERT INTO `wp_commentmeta` VALUES("22","8","akismet_as_submitted","a:44:{s:15:\"comment_post_ID\";i:21;s:14:\"comment_author\";s:41:\"Governance of massage therapy | KWmassage\";s:18:\"comment_author_url\";s:76:\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\";s:20:\"comment_author_email\";s:0:\"\";s:15:\"comment_content\";s:27:\"[&#8230;] Contact [&#8230;]\";s:12:\"comment_type\";s:8:\"pingback\";s:7:\"user_ip\";s:13:\"69.90.161.250\";s:10:\"user_agent\";s:48:\"The Incutio XML-RPC PHP Library -- WordPress/3.8\";s:8:\"referrer\";N;s:4:\"blog\";s:24:\"http://www.kwmassage.com\";s:9:\"blog_lang\";s:5:\"en_US\";s:12:\"blog_charset\";s:5:\"UTF-8\";s:9:\"permalink\";s:32:\"http://www.kwmassage.com/contact\";s:21:\"akismet_comment_nonce\";s:6:\"failed\";s:15:\"SERVER_SOFTWARE\";s:6:\"Apache\";s:11:\"REQUEST_URI\";s:11:\"/xmlrpc.php\";s:14:\"CONTENT_LENGTH\";s:3:\"309\";s:12:\"CONTENT_TYPE\";s:8:\"text/xml\";s:13:\"DOCUMENT_ROOT\";s:26:\"/home/kwma2903/public_html\";s:17:\"GATEWAY_INTERFACE\";s:7:\"CGI/1.1\";s:11:\"HTTP_ACCEPT\";s:3:\"*/*\";s:20:\"HTTP_ACCEPT_ENCODING\";s:29:\"deflate;q=1.0, compress;q=0.5\";s:9:\"HTTP_HOST\";s:17:\"www.kwmassage.com\";s:15:\"HTTP_USER_AGENT\";s:48:\"The Incutio XML-RPC PHP Library -- WordPress/3.8\";s:4:\"PATH\";s:13:\"/bin:/usr/bin\";s:12:\"QUERY_STRING\";s:0:\"\";s:15:\"REDIRECT_STATUS\";s:3:\"200\";s:11:\"REMOTE_ADDR\";s:13:\"69.90.161.250\";s:11:\"REMOTE_PORT\";s:5:\"55045\";s:14:\"REQUEST_METHOD\";s:4:\"POST\";s:15:\"SCRIPT_FILENAME\";s:37:\"/home/kwma2903/public_html/xmlrpc.php\";s:11:\"SCRIPT_NAME\";s:11:\"/xmlrpc.php\";s:11:\"SERVER_ADDR\";s:13:\"69.90.161.250\";s:12:\"SERVER_ADMIN\";s:23:\"webmaster@kwmassage.com\";s:11:\"SERVER_NAME\";s:17:\"www.kwmassage.com\";s:11:\"SERVER_PORT\";s:2:\"80\";s:15:\"SERVER_PROTOCOL\";s:8:\"HTTP/1.0\";s:16:\"SERVER_SIGNATURE\";s:0:\"\";s:9:\"UNIQUE_ID\";s:24:\"UtRDAkVaofoAAEiNZykAAAAM\";s:8:\"PHP_SELF\";s:11:\"/xmlrpc.php\";s:12:\"REQUEST_TIME\";s:10:\"1389642498\";s:4:\"argv\";s:0:\"\";s:4:\"argc\";s:1:\"0\";s:25:\"comment_post_modified_gmt\";s:19:\"2014-01-12 20:38:10\";}");
INSERT INTO `wp_commentmeta` VALUES("23","9","akismet_error","1389642583");
INSERT INTO `wp_commentmeta` VALUES("24","9","akismet_history","a:4:{s:4:\"time\";d:1389642583.492443084716796875;s:7:\"message\";s:92:\"Akismet was unable to check this comment (response: ), will automatically retry again later.\";s:5:\"event\";s:11:\"check-error\";s:4:\"user\";s:0:\"\";}");
INSERT INTO `wp_commentmeta` VALUES("25","9","akismet_as_submitted","a:44:{s:15:\"comment_post_ID\";i:249;s:14:\"comment_author\";s:29:\"Tension Headaches | KWmassage\";s:18:\"comment_author_url\";s:64:\"http://www.kwmassage.com/generalmassagetherapy/tension-headaches\";s:20:\"comment_author_email\";s:0:\"\";s:15:\"comment_content\";s:227:\"[&#8230;] of a headache without the use of Tylenol, Advil, or other pain controlling medications.  Regular stretching, exercise, and massage therapy can bring so much relief you would wonder why you never tried these [&#8230;]\";s:12:\"comment_type\";s:8:\"pingback\";s:7:\"user_ip\";s:13:\"69.90.161.250\";s:10:\"user_agent\";s:48:\"The Incutio XML-RPC PHP Library -- WordPress/3.8\";s:8:\"referrer\";N;s:4:\"blog\";s:24:\"http://www.kwmassage.com\";s:9:\"blog_lang\";s:5:\"en_US\";s:12:\"blog_charset\";s:5:\"UTF-8\";s:9:\"permalink\";s:69:\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\";s:21:\"akismet_comment_nonce\";s:6:\"failed\";s:15:\"SERVER_SOFTWARE\";s:6:\"Apache\";s:11:\"REQUEST_URI\";s:11:\"/xmlrpc.php\";s:14:\"CONTENT_LENGTH\";s:3:\"334\";s:12:\"CONTENT_TYPE\";s:8:\"text/xml\";s:13:\"DOCUMENT_ROOT\";s:26:\"/home/kwma2903/public_html\";s:17:\"GATEWAY_INTERFACE\";s:7:\"CGI/1.1\";s:11:\"HTTP_ACCEPT\";s:3:\"*/*\";s:20:\"HTTP_ACCEPT_ENCODING\";s:29:\"deflate;q=1.0, compress;q=0.5\";s:9:\"HTTP_HOST\";s:17:\"www.kwmassage.com\";s:15:\"HTTP_USER_AGENT\";s:48:\"The Incutio XML-RPC PHP Library -- WordPress/3.8\";s:4:\"PATH\";s:13:\"/bin:/usr/bin\";s:12:\"QUERY_STRING\";s:0:\"\";s:15:\"REDIRECT_STATUS\";s:3:\"200\";s:11:\"REMOTE_ADDR\";s:13:\"69.90.161.250\";s:11:\"REMOTE_PORT\";s:5:\"55430\";s:14:\"REQUEST_METHOD\";s:4:\"POST\";s:15:\"SCRIPT_FILENAME\";s:37:\"/home/kwma2903/public_html/xmlrpc.php\";s:11:\"SCRIPT_NAME\";s:11:\"/xmlrpc.php\";s:11:\"SERVER_ADDR\";s:13:\"69.90.161.250\";s:12:\"SERVER_ADMIN\";s:23:\"webmaster@kwmassage.com\";s:11:\"SERVER_NAME\";s:17:\"www.kwmassage.com\";s:11:\"SERVER_PORT\";s:2:\"80\";s:15:\"SERVER_PROTOCOL\";s:8:\"HTTP/1.0\";s:16:\"SERVER_SIGNATURE\";s:0:\"\";s:9:\"UNIQUE_ID\";s:24:\"UtRDVUVaofoAABCcuH8AAAAV\";s:8:\"PHP_SELF\";s:11:\"/xmlrpc.php\";s:12:\"REQUEST_TIME\";s:10:\"1389642581\";s:4:\"argv\";s:0:\"\";s:4:\"argc\";s:1:\"0\";s:25:\"comment_post_modified_gmt\";s:19:\"2014-01-13 19:41:08\";}");
INSERT INTO `wp_commentmeta` VALUES("26","10","akismet_error","1389642653");
INSERT INTO `wp_commentmeta` VALUES("27","10","akismet_history","a:4:{s:4:\"time\";d:1389642653.45236301422119140625;s:7:\"message\";s:92:\"Akismet was unable to check this comment (response: ), will automatically retry again later.\";s:5:\"event\";s:11:\"check-error\";s:4:\"user\";s:0:\"\";}");
INSERT INTO `wp_commentmeta` VALUES("28","10","akismet_as_submitted","a:44:{s:15:\"comment_post_ID\";i:251;s:14:\"comment_author\";s:29:\"Tension Headaches | KWmassage\";s:18:\"comment_author_url\";s:66:\"http://www.kwmassage.com/generalmassagetherapy/tension-headaches-3\";s:20:\"comment_author_email\";s:0:\"\";s:15:\"comment_content\";s:173:\"[&#8230;] before doing any of the stretches I demonstrate and recommend. It’s always a good idea to see a health care professional before starting a new exercise [&#8230;]\";s:12:\"comment_type\";s:8:\"pingback\";s:7:\"user_ip\";s:13:\"69.90.161.250\";s:10:\"user_agent\";s:48:\"The Incutio XML-RPC PHP Library -- WordPress/3.8\";s:8:\"referrer\";N;s:4:\"blog\";s:24:\"http://www.kwmassage.com\";s:9:\"blog_lang\";s:5:\"en_US\";s:12:\"blog_charset\";s:5:\"UTF-8\";s:9:\"permalink\";s:76:\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\";s:21:\"akismet_comment_nonce\";s:6:\"failed\";s:15:\"SERVER_SOFTWARE\";s:6:\"Apache\";s:11:\"REQUEST_URI\";s:11:\"/xmlrpc.php\";s:14:\"CONTENT_LENGTH\";s:3:\"343\";s:12:\"CONTENT_TYPE\";s:8:\"text/xml\";s:13:\"DOCUMENT_ROOT\";s:26:\"/home/kwma2903/public_html\";s:17:\"GATEWAY_INTERFACE\";s:7:\"CGI/1.1\";s:11:\"HTTP_ACCEPT\";s:3:\"*/*\";s:20:\"HTTP_ACCEPT_ENCODING\";s:29:\"deflate;q=1.0, compress;q=0.5\";s:9:\"HTTP_HOST\";s:17:\"www.kwmassage.com\";s:15:\"HTTP_USER_AGENT\";s:48:\"The Incutio XML-RPC PHP Library -- WordPress/3.8\";s:4:\"PATH\";s:13:\"/bin:/usr/bin\";s:12:\"QUERY_STRING\";s:0:\"\";s:15:\"REDIRECT_STATUS\";s:3:\"200\";s:11:\"REMOTE_ADDR\";s:13:\"69.90.161.250\";s:11:\"REMOTE_PORT\";s:5:\"55782\";s:14:\"REQUEST_METHOD\";s:4:\"POST\";s:15:\"SCRIPT_FILENAME\";s:37:\"/home/kwma2903/public_html/xmlrpc.php\";s:11:\"SCRIPT_NAME\";s:11:\"/xmlrpc.php\";s:11:\"SERVER_ADDR\";s:13:\"69.90.161.250\";s:12:\"SERVER_ADMIN\";s:23:\"webmaster@kwmassage.com\";s:11:\"SERVER_NAME\";s:17:\"www.kwmassage.com\";s:11:\"SERVER_PORT\";s:2:\"80\";s:15:\"SERVER_PROTOCOL\";s:8:\"HTTP/1.0\";s:16:\"SERVER_SIGNATURE\";s:0:\"\";s:9:\"UNIQUE_ID\";s:24:\"UtRDm0VaofoAAA7FQckAAAAY\";s:8:\"PHP_SELF\";s:11:\"/xmlrpc.php\";s:12:\"REQUEST_TIME\";s:10:\"1389642651\";s:4:\"argv\";s:0:\"\";s:4:\"argc\";s:1:\"0\";s:25:\"comment_post_modified_gmt\";s:19:\"2014-01-13 19:48:16\";}");
INSERT INTO `wp_commentmeta` VALUES("29","11","akismet_error","1389642730");
INSERT INTO `wp_commentmeta` VALUES("30","11","akismet_history","a:4:{s:4:\"time\";d:1389642730.7974970340728759765625;s:7:\"message\";s:92:\"Akismet was unable to check this comment (response: ), will automatically retry again later.\";s:5:\"event\";s:11:\"check-error\";s:4:\"user\";s:0:\"\";}");
INSERT INTO `wp_commentmeta` VALUES("31","11","akismet_as_submitted","a:44:{s:15:\"comment_post_ID\";i:219;s:14:\"comment_author\";s:29:\"Tension Headaches | KWmassage\";s:18:\"comment_author_url\";s:66:\"http://www.kwmassage.com/generalmassagetherapy/tension-headaches-3\";s:20:\"comment_author_email\";s:0:\"\";s:15:\"comment_content\";s:232:\"[&#8230;] and shoulders. Overuse of vulnerable muscles can cause large painful knots in your muscles called Trigger Points. The pain created by Trigger Points is not always located in the area of the Trigger Point itself. [&#8230;]\";s:12:\"comment_type\";s:8:\"pingback\";s:7:\"user_ip\";s:13:\"69.90.161.250\";s:10:\"user_agent\";s:48:\"The Incutio XML-RPC PHP Library -- WordPress/3.8\";s:8:\"referrer\";N;s:4:\"blog\";s:24:\"http://www.kwmassage.com\";s:9:\"blog_lang\";s:5:\"en_US\";s:12:\"blog_charset\";s:5:\"UTF-8\";s:9:\"permalink\";s:87:\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\";s:21:\"akismet_comment_nonce\";s:6:\"failed\";s:15:\"SERVER_SOFTWARE\";s:6:\"Apache\";s:11:\"REQUEST_URI\";s:11:\"/xmlrpc.php\";s:14:\"CONTENT_LENGTH\";s:3:\"354\";s:12:\"CONTENT_TYPE\";s:8:\"text/xml\";s:13:\"DOCUMENT_ROOT\";s:26:\"/home/kwma2903/public_html\";s:17:\"GATEWAY_INTERFACE\";s:7:\"CGI/1.1\";s:11:\"HTTP_ACCEPT\";s:3:\"*/*\";s:20:\"HTTP_ACCEPT_ENCODING\";s:29:\"deflate;q=1.0, compress;q=0.5\";s:9:\"HTTP_HOST\";s:17:\"www.kwmassage.com\";s:15:\"HTTP_USER_AGENT\";s:48:\"The Incutio XML-RPC PHP Library -- WordPress/3.8\";s:4:\"PATH\";s:13:\"/bin:/usr/bin\";s:12:\"QUERY_STRING\";s:0:\"\";s:15:\"REDIRECT_STATUS\";s:3:\"200\";s:11:\"REMOTE_ADDR\";s:13:\"69.90.161.250\";s:11:\"REMOTE_PORT\";s:5:\"56225\";s:14:\"REQUEST_METHOD\";s:4:\"POST\";s:15:\"SCRIPT_FILENAME\";s:37:\"/home/kwma2903/public_html/xmlrpc.php\";s:11:\"SCRIPT_NAME\";s:11:\"/xmlrpc.php\";s:11:\"SERVER_ADDR\";s:13:\"69.90.161.250\";s:12:\"SERVER_ADMIN\";s:23:\"webmaster@kwmassage.com\";s:11:\"SERVER_NAME\";s:17:\"www.kwmassage.com\";s:11:\"SERVER_PORT\";s:2:\"80\";s:15:\"SERVER_PROTOCOL\";s:8:\"HTTP/1.0\";s:16:\"SERVER_SIGNATURE\";s:0:\"\";s:9:\"UNIQUE_ID\";s:24:\"UtRD6UVaofoAAHELgZ0AAAAX\";s:8:\"PHP_SELF\";s:11:\"/xmlrpc.php\";s:12:\"REQUEST_TIME\";s:10:\"1389642729\";s:4:\"argv\";s:0:\"\";s:4:\"argc\";s:1:\"0\";s:25:\"comment_post_modified_gmt\";s:19:\"2014-01-13 17:47:58\";}");
INSERT INTO `wp_commentmeta` VALUES("32","12","akismet_error","1389643721");
INSERT INTO `wp_commentmeta` VALUES("33","12","akismet_history","a:4:{s:4:\"time\";d:1389643721.19902801513671875;s:7:\"message\";s:92:\"Akismet was unable to check this comment (response: ), will automatically retry again later.\";s:5:\"event\";s:11:\"check-error\";s:4:\"user\";s:0:\"\";}");
INSERT INTO `wp_commentmeta` VALUES("34","12","akismet_as_submitted","a:44:{s:15:\"comment_post_ID\";i:259;s:14:\"comment_author\";s:41:\"Governance of massage therapy | KWmassage\";s:18:\"comment_author_url\";s:76:\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\";s:20:\"comment_author_email\";s:0:\"\";s:15:\"comment_content\";s:25:\"[&#8230;] Facts [&#8230;]\";s:12:\"comment_type\";s:8:\"pingback\";s:7:\"user_ip\";s:13:\"69.90.161.250\";s:10:\"user_agent\";s:48:\"The Incutio XML-RPC PHP Library -- WordPress/3.8\";s:8:\"referrer\";N;s:4:\"blog\";s:24:\"http://www.kwmassage.com\";s:9:\"blog_lang\";s:5:\"en_US\";s:12:\"blog_charset\";s:5:\"UTF-8\";s:9:\"permalink\";s:91:\"http://www.kwmassage.com/knowledge-centre/facts-about-registered-massage-therapy-in-ontario\";s:21:\"akismet_comment_nonce\";s:6:\"failed\";s:15:\"SERVER_SOFTWARE\";s:6:\"Apache\";s:11:\"REQUEST_URI\";s:11:\"/xmlrpc.php\";s:14:\"CONTENT_LENGTH\";s:3:\"368\";s:12:\"CONTENT_TYPE\";s:8:\"text/xml\";s:13:\"DOCUMENT_ROOT\";s:26:\"/home/kwma2903/public_html\";s:17:\"GATEWAY_INTERFACE\";s:7:\"CGI/1.1\";s:11:\"HTTP_ACCEPT\";s:3:\"*/*\";s:20:\"HTTP_ACCEPT_ENCODING\";s:29:\"deflate;q=1.0, compress;q=0.5\";s:9:\"HTTP_HOST\";s:17:\"www.kwmassage.com\";s:15:\"HTTP_USER_AGENT\";s:48:\"The Incutio XML-RPC PHP Library -- WordPress/3.8\";s:4:\"PATH\";s:13:\"/bin:/usr/bin\";s:12:\"QUERY_STRING\";s:0:\"\";s:15:\"REDIRECT_STATUS\";s:3:\"200\";s:11:\"REMOTE_ADDR\";s:13:\"69.90.161.250\";s:11:\"REMOTE_PORT\";s:5:\"32975\";s:14:\"REQUEST_METHOD\";s:4:\"POST\";s:15:\"SCRIPT_FILENAME\";s:37:\"/home/kwma2903/public_html/xmlrpc.php\";s:11:\"SCRIPT_NAME\";s:11:\"/xmlrpc.php\";s:11:\"SERVER_ADDR\";s:13:\"69.90.161.250\";s:12:\"SERVER_ADMIN\";s:23:\"webmaster@kwmassage.com\";s:11:\"SERVER_NAME\";s:17:\"www.kwmassage.com\";s:11:\"SERVER_PORT\";s:2:\"80\";s:15:\"SERVER_PROTOCOL\";s:8:\"HTTP/1.0\";s:16:\"SERVER_SIGNATURE\";s:0:\"\";s:9:\"UNIQUE_ID\";s:24:\"UtRHx0VaofoAAFwVx@oAAABD\";s:8:\"PHP_SELF\";s:11:\"/xmlrpc.php\";s:12:\"REQUEST_TIME\";s:10:\"1389643719\";s:4:\"argv\";s:0:\"\";s:4:\"argc\";s:1:\"0\";s:25:\"comment_post_modified_gmt\";s:19:\"2014-01-13 20:05:54\";}");


DROP TABLE IF EXISTS `wp_comments`;

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `wp_comments` VALUES("3","211","Does Deep Tissue Massage Heart? | KWmassage","","http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart","69.90.161.250","2014-01-12 22:01:16","2014-01-12 22:01:16","[&#8230;] Often Deep Tissue massage therapy will cause some tenderness when your massage therapist is working hard to work out the tension, scar tissue, and trigger points from your muscles and ligaments. And yes, sometimes you will feel a little stiffness the day after. Most often, this soreness is a welcome relief as your therapist has the skill to pinpoint the source of your pain and work it out. [&#8230;]","0","0","The Incutio XML-RPC PHP Library -- WordPress/3.8","pingback","0","0");
INSERT INTO `wp_comments` VALUES("4","211","Trigger Points and Trigger Point Therapy | KWmassage","","http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy","69.90.161.250","2014-01-12 22:17:39","2014-01-12 22:17:39","[&#8230;] Kitchener Massage Therapy I use a few different Deep Tissue Massage techniques like muscle stripping, direct pressure held for up to a minute, and stretchingto treat [&#8230;]","0","0","The Incutio XML-RPC PHP Library -- WordPress/3.8","pingback","0","0");
INSERT INTO `wp_comments` VALUES("5","7","Note to New Massage Therapy Clients | KWmassage","","http://www.kwmassage.com/generalmassagetherapy/note-to-new-massage-therapy-clients","69.90.161.250","2014-01-13 14:39:24","2014-01-13 14:39:24","[&#8230;] Appointments [&#8230;]","0","0","The Incutio XML-RPC PHP Library -- WordPress/3.8","pingback","0","0");
INSERT INTO `wp_comments` VALUES("6","211","Note to New Massage Therapy Clients | KWmassage","","http://www.kwmassage.com/generalmassagetherapy/note-to-new-massage-therapy-clients","69.90.161.250","2014-01-13 16:26:59","2014-01-13 16:26:59","[&#8230;] will be using an assortment of massage techniques. Some of these can be relaxing and others can be kind of tender. In most cases, a little pain is necessary to get the results you are looking for from a massage [&#8230;]","0","0","The Incutio XML-RPC PHP Library -- WordPress/3.8","pingback","0","0");
INSERT INTO `wp_comments` VALUES("7","216","Trigger Points and Trigger Point Therapy | KWmassage","","http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy","69.90.161.250","2014-01-13 17:48:03","2014-01-13 17:48:03","[&#8230;] It is uncomfortable to have a Trigger Point worked out but the relief you get from the headache, sore back or whatever it is you are experiencing can be great. My clients often describe the pain from Trigger Point work as a good pain . I think this stems from the fact that someone has finally been able to pinpoint and address the source of their discomfort after what could have been many years. [&#8230;]","0","0","The Incutio XML-RPC PHP Library -- WordPress/3.8","pingback","0","0");
INSERT INTO `wp_comments` VALUES("8","21","Governance of massage therapy | KWmassage","","http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy","69.90.161.250","2014-01-13 19:48:19","2014-01-13 19:48:19","[&#8230;] Contact [&#8230;]","0","0","The Incutio XML-RPC PHP Library -- WordPress/3.8","pingback","0","0");
INSERT INTO `wp_comments` VALUES("9","249","Tension Headaches | KWmassage","","http://www.kwmassage.com/generalmassagetherapy/tension-headaches","69.90.161.250","2014-01-13 19:49:43","2014-01-13 19:49:43","[&#8230;] of a headache without the use of Tylenol, Advil, or other pain controlling medications.  Regular stretching, exercise, and massage therapy can bring so much relief you would wonder why you never tried these [&#8230;]","0","0","The Incutio XML-RPC PHP Library -- WordPress/3.8","pingback","0","0");
INSERT INTO `wp_comments` VALUES("10","251","Tension Headaches | KWmassage","","http://www.kwmassage.com/generalmassagetherapy/tension-headaches-3","69.90.161.250","2014-01-13 19:50:53","2014-01-13 19:50:53","[&#8230;] before doing any of the stretches I demonstrate and recommend. It’s always a good idea to see a health care professional before starting a new exercise [&#8230;]","0","0","The Incutio XML-RPC PHP Library -- WordPress/3.8","pingback","0","0");
INSERT INTO `wp_comments` VALUES("11","219","Tension Headaches | KWmassage","","http://www.kwmassage.com/generalmassagetherapy/tension-headaches-3","69.90.161.250","2014-01-13 19:52:10","2014-01-13 19:52:10","[&#8230;] and shoulders. Overuse of vulnerable muscles can cause large painful knots in your muscles called Trigger Points. The pain created by Trigger Points is not always located in the area of the Trigger Point itself. [&#8230;]","0","0","The Incutio XML-RPC PHP Library -- WordPress/3.8","pingback","0","0");
INSERT INTO `wp_comments` VALUES("12","259","Governance of massage therapy | KWmassage","","http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy","69.90.161.250","2014-01-13 20:08:41","2014-01-13 20:08:41","[&#8230;] Facts [&#8230;]","0","0","The Incutio XML-RPC PHP Library -- WordPress/3.8","pingback","0","0");


DROP TABLE IF EXISTS `wp_links`;

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_options`;

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=558 DEFAULT CHARSET=utf8;

INSERT INTO `wp_options` VALUES("1","siteurl","http://www.kwmassage.com","yes");
INSERT INTO `wp_options` VALUES("2","blogname","KWmassage","yes");
INSERT INTO `wp_options` VALUES("3","blogdescription","Registered Massage Therapy in Kitchener","yes");
INSERT INTO `wp_options` VALUES("4","users_can_register","0","yes");
INSERT INTO `wp_options` VALUES("5","admin_email","jeremy@kwmassage.com","yes");
INSERT INTO `wp_options` VALUES("6","start_of_week","1","yes");
INSERT INTO `wp_options` VALUES("7","use_balanceTags","0","yes");
INSERT INTO `wp_options` VALUES("8","use_smilies","1","yes");
INSERT INTO `wp_options` VALUES("9","require_name_email","1","yes");
INSERT INTO `wp_options` VALUES("10","comments_notify","","yes");
INSERT INTO `wp_options` VALUES("11","posts_per_rss","10","yes");
INSERT INTO `wp_options` VALUES("12","rss_use_excerpt","0","yes");
INSERT INTO `wp_options` VALUES("13","mailserver_url","mail.example.com","yes");
INSERT INTO `wp_options` VALUES("14","mailserver_login","login@example.com","yes");
INSERT INTO `wp_options` VALUES("15","mailserver_pass","password","yes");
INSERT INTO `wp_options` VALUES("16","mailserver_port","110","yes");
INSERT INTO `wp_options` VALUES("17","default_category","1","yes");
INSERT INTO `wp_options` VALUES("18","default_comment_status","open","yes");
INSERT INTO `wp_options` VALUES("19","default_ping_status","open","yes");
INSERT INTO `wp_options` VALUES("20","default_pingback_flag","1","yes");
INSERT INTO `wp_options` VALUES("21","posts_per_page","10","yes");
INSERT INTO `wp_options` VALUES("22","date_format","F j, Y","yes");
INSERT INTO `wp_options` VALUES("23","time_format","g:i a","yes");
INSERT INTO `wp_options` VALUES("24","links_updated_date_format","F j, Y g:i a","yes");
INSERT INTO `wp_options` VALUES("25","links_recently_updated_prepend","<em>","yes");
INSERT INTO `wp_options` VALUES("26","links_recently_updated_append","</em>","yes");
INSERT INTO `wp_options` VALUES("27","links_recently_updated_time","120","yes");
INSERT INTO `wp_options` VALUES("28","comment_moderation","","yes");
INSERT INTO `wp_options` VALUES("29","moderation_notify","","yes");
INSERT INTO `wp_options` VALUES("30","permalink_structure","/%category%/%postname%","yes");
INSERT INTO `wp_options` VALUES("31","gzipcompression","0","yes");
INSERT INTO `wp_options` VALUES("32","hack_file","0","yes");
INSERT INTO `wp_options` VALUES("33","blog_charset","UTF-8","yes");
INSERT INTO `wp_options` VALUES("34","moderation_keys","","no");
INSERT INTO `wp_options` VALUES("35","active_plugins","a:9:{i:0;s:25:\"404-plugin/404-plugin.php\";i:1;s:19:\"akismet/akismet.php\";i:2;s:43:\"all-in-one-seo-pack/all_in_one_seo_pack.php\";i:3;s:41:\"better-wp-security/better-wp-security.php\";i:4;s:36:\"contact-form-7/wp-contact-form-7.php\";i:5;s:36:\"google-sitemap-generator/sitemap.php\";i:6;s:33:\"seo-automatic-links/seo-links.php\";i:7;s:52:\"wordpress-backup-to-dropbox/wp-backup-to-dropbox.php\";i:8;s:41:\"wordpress-importer/wordpress-importer.php\";}","yes");
INSERT INTO `wp_options` VALUES("36","home","http://www.kwmassage.com","yes");
INSERT INTO `wp_options` VALUES("37","category_base","","yes");
INSERT INTO `wp_options` VALUES("38","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `wp_options` VALUES("39","advanced_edit","0","yes");
INSERT INTO `wp_options` VALUES("40","comment_max_links","2","yes");
INSERT INTO `wp_options` VALUES("41","gmt_offset","0","yes");
INSERT INTO `wp_options` VALUES("42","default_email_category","1","yes");
INSERT INTO `wp_options` VALUES("43","recently_edited","a:5:{i:0;s:98:\"/home/kwma2903/public_html/wp-content/plugins/wordpress-backup-to-dropbox/wp-backup-to-dropbox.php\";i:1;s:64:\"/home/kwma2903/public_html/wp-content/themes/KWMassage/style.css\";i:2;s:68:\"/home/kwma2903/public_html/wp-content/themes/KWMassage/functions.php\";i:3;s:75:\"/home/kwma2903/public_html/wp-content/themes/KWMassage/editor-style-rtl.css\";i:4;s:69:\"/home/kwma2903/public_html/wp-content/themes/KWMassage/attachment.php\";}","no");
INSERT INTO `wp_options` VALUES("44","template","KWMassage","yes");
INSERT INTO `wp_options` VALUES("45","stylesheet","KWMassage","yes");
INSERT INTO `wp_options` VALUES("46","comment_whitelist","1","yes");
INSERT INTO `wp_options` VALUES("47","blacklist_keys","","no");
INSERT INTO `wp_options` VALUES("48","comment_registration","","yes");
INSERT INTO `wp_options` VALUES("49","html_type","text/html","yes");
INSERT INTO `wp_options` VALUES("50","use_trackback","0","yes");
INSERT INTO `wp_options` VALUES("51","default_role","subscriber","yes");
INSERT INTO `wp_options` VALUES("52","db_version","26691","yes");
INSERT INTO `wp_options` VALUES("53","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `wp_options` VALUES("54","upload_path","","yes");
INSERT INTO `wp_options` VALUES("55","blog_public","1","yes");
INSERT INTO `wp_options` VALUES("56","default_link_category","2","yes");
INSERT INTO `wp_options` VALUES("57","show_on_front","posts","yes");
INSERT INTO `wp_options` VALUES("58","tag_base","","yes");
INSERT INTO `wp_options` VALUES("59","show_avatars","1","yes");
INSERT INTO `wp_options` VALUES("60","avatar_rating","G","yes");
INSERT INTO `wp_options` VALUES("61","upload_url_path","","yes");
INSERT INTO `wp_options` VALUES("62","thumbnail_size_w","150","yes");
INSERT INTO `wp_options` VALUES("63","thumbnail_size_h","150","yes");
INSERT INTO `wp_options` VALUES("64","thumbnail_crop","1","yes");
INSERT INTO `wp_options` VALUES("65","medium_size_w","300","yes");
INSERT INTO `wp_options` VALUES("66","medium_size_h","300","yes");
INSERT INTO `wp_options` VALUES("67","avatar_default","mystery","yes");
INSERT INTO `wp_options` VALUES("68","large_size_w","1024","yes");
INSERT INTO `wp_options` VALUES("69","large_size_h","1024","yes");
INSERT INTO `wp_options` VALUES("70","image_default_link_type","file","yes");
INSERT INTO `wp_options` VALUES("71","image_default_size","","yes");
INSERT INTO `wp_options` VALUES("72","image_default_align","","yes");
INSERT INTO `wp_options` VALUES("73","close_comments_for_old_posts","","yes");
INSERT INTO `wp_options` VALUES("74","close_comments_days_old","14","yes");
INSERT INTO `wp_options` VALUES("75","thread_comments","1","yes");
INSERT INTO `wp_options` VALUES("76","thread_comments_depth","5","yes");
INSERT INTO `wp_options` VALUES("77","page_comments","","yes");
INSERT INTO `wp_options` VALUES("78","comments_per_page","50","yes");
INSERT INTO `wp_options` VALUES("79","default_comments_page","newest","yes");
INSERT INTO `wp_options` VALUES("80","comment_order","asc","yes");
INSERT INTO `wp_options` VALUES("81","sticky_posts","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("82","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("83","widget_text","a:3:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:4:\"text\";s:691:\"<a href=\"http://www.schedulicity.com/Scheduling/Default.aspx?business=KDXBZN\" title=\"Online scheduling\" target=\"_blank\" class=\"{buttonClass}\"><img src=\"http://www.schedulicity.com/Business/Images/ScheduleNow_LG.png\" alt=\"Schedule online now\" border=\"0\" /></a>
<h1>Hours</h1>
<div id=\"timebox\">
<span>Monday 10:00 - 5:00</Span>
<span>Tuesday 10:00 - 8:00</Span>
<span>Wednesday 10:00 - 5:00</Span>
<span>Thursday 10:00 - 3:00</Span>
<span>Friday 10:00 - 3:00</Span>
<span>Saturday 10:00 - 3:00</Span>
<span>Sunday Closed</Span>
</div>
<h1>Rates</h1>
<div id=\"rate_box\">
<span>1/2 Hour $55</span></br>
<span>1Hour $85</span></br>
<span>11/2 Hour $120</span></br></div>




\";s:6:\"filter\";b:0;}i:3;a:3:{s:5:\"title\";s:0:\"\";s:4:\"text\";s:133:\"<div id=\"videobox\">
<img src=\"http://www.kwmassage.com/wp-content/uploads/2014/01/img_video.gif\" alt=\"Watch Welcom Video\">
</div>
\";s:6:\"filter\";b:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("84","widget_rss","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("85","uninstall_plugins","a:1:{s:41:\"better-wp-security/better-wp-security.php\";a:2:{i:0;s:10:\"bwps_setup\";i:1;s:12:\"on_uninstall\";}}","no");
INSERT INTO `wp_options` VALUES("86","timezone_string","","yes");
INSERT INTO `wp_options` VALUES("87","page_for_posts","0","yes");
INSERT INTO `wp_options` VALUES("88","page_on_front","0","yes");
INSERT INTO `wp_options` VALUES("89","default_post_format","0","yes");
INSERT INTO `wp_options` VALUES("90","link_manager_enabled","0","yes");
INSERT INTO `wp_options` VALUES("91","initial_db_version","26691","yes");
INSERT INTO `wp_options` VALUES("92","wp_user_roles","a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:62:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:9:\"add_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}","yes");
INSERT INTO `wp_options` VALUES("93","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("94","widget_recent-posts","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("95","widget_recent-comments","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("96","widget_archives","a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("97","widget_meta","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("98","sidebars_widgets","a:8:{s:19:\"wp_inactive_widgets\";a:0:{}s:19:\"primary-widget-area\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:21:\"secondary-widget-area\";a:0:{}s:24:\"first-footer-widget-area\";a:1:{i:0;s:6:\"text-3\";}s:25:\"second-footer-widget-area\";a:1:{i:0;s:6:\"text-2\";}s:24:\"third-footer-widget-area\";a:0:{}s:25:\"fourth-footer-widget-area\";a:0:{}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `wp_options` VALUES("99","cron","a:8:{i:1389727440;a:1:{s:20:\"wp_maybe_auto_update\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1389730738;a:1:{s:29:\"akismet_schedule_cron_recheck\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1389736876;a:1:{s:24:\"akismet_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1389759575;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1389782881;a:1:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1389784728;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1390302000;a:1:{s:30:\"execute_periodic_drobox_backup\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `wp_options` VALUES("101","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:39:\"https://wordpress.org/wordpress-3.8.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:39:\"https://wordpress.org/wordpress-3.8.zip\";s:10:\"no_content\";s:50:\"https://wordpress.org/wordpress-3.8-no-content.zip\";s:11:\"new_bundled\";s:51:\"https://wordpress.org/wordpress-3.8-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:3:\"3.8\";s:7:\"version\";s:3:\"3.8\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"3.8\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1389716375;s:15:\"version_checked\";s:3:\"3.8\";s:12:\"translations\";a:0:{}}","yes");
INSERT INTO `wp_options` VALUES("556","_site_transient_timeout_theme_roots","1389718176","yes");
INSERT INTO `wp_options` VALUES("557","_site_transient_theme_roots","a:4:{s:9:\"KWMassage\";s:7:\"/themes\";s:14:\"twentyfourteen\";s:7:\"/themes\";s:14:\"twentythirteen\";s:7:\"/themes\";s:12:\"twentytwelve\";s:7:\"/themes\";}","yes");
INSERT INTO `wp_options` VALUES("105","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1389716376;s:7:\"checked\";a:4:{s:9:\"KWMassage\";s:3:\"1.1\";s:14:\"twentyfourteen\";s:3:\"1.0\";s:14:\"twentythirteen\";s:3:\"1.1\";s:12:\"twentytwelve\";s:3:\"1.3\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}","yes");
INSERT INTO `wp_options` VALUES("106","_site_transient_timeout_browser_3f947c51580a0abb6a41fc0b9411b81e","1389955682","yes");
INSERT INTO `wp_options` VALUES("107","_site_transient_browser_3f947c51580a0abb6a41fc0b9411b81e","a:9:{s:8:\"platform\";s:7:\"Windows\";s:4:\"name\";s:7:\"Firefox\";s:7:\"version\";s:4:\"26.0\";s:10:\"update_url\";s:23:\"http://www.firefox.com/\";s:7:\"img_src\";s:50:\"http://s.wordpress.org/images/browsers/firefox.png\";s:11:\"img_src_ssl\";s:49:\"https://wordpress.org/images/browsers/firefox.png\";s:15:\"current_version\";s:2:\"16\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("507","_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca","1389753332","no");
INSERT INTO `wp_options` VALUES("508","_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca","1389710132","no");
INSERT INTO `wp_options` VALUES("505","_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca","1389753332","no");
INSERT INTO `wp_options` VALUES("506","_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:51:\"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"http://wordpress.org/news\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 20 Dec 2013 08:24:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/?v=3.9-alpha\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:42:\"
		
		
		
		
		
				

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"WordPress 3.8 “Parker”\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"http://wordpress.org/news/2013/12/parker/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"http://wordpress.org/news/2013/12/parker/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 12 Dec 2013 17:00:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=2765\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:354:\"Version 3.8 of WordPress, named “Parker” in honor of Charlie Parker, bebop innovator, is available for download or update in your WordPress dashboard. We hope you&#8217;ll think this is the most beautiful update yet. Introducing a modern new design WordPress has gotten a facelift. 3.8 brings a fresh new look to the entire admin dashboard. [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:18197:\"<p>Version 3.8 of WordPress, named “Parker” in honor of <a href=\"http://en.wikipedia.org/wiki/Charlie_Parker\">Charlie Parker</a>, bebop innovator, is available <a href=\"http://wordpress.org/download/\">for download</a> or update in your WordPress dashboard. We hope you&#8217;ll think this is the most beautiful update yet.</p>
<div id=\"v-6wORgoGb-1\" class=\"video-player\"><embed id=\"v-6wORgoGb-1-video\" src=\"http://s0.videopress.com/player.swf?v=1.03&amp;guid=6wORgoGb&amp;isDynamicSeeking=true\" type=\"application/x-shockwave-flash\" width=\"692\" height=\"388\" wmode=\"direct\" seamlesstabbing=\"true\" allowfullscreen=\"true\" allowscriptaccess=\"always\" overstretch=\"true\"></embed></div>
<h2 class=\"aligncenter\">Introducing a modern new design</h2>
<p><img class=\"wp-image-2951 aligncenter\" alt=\"overview\" src=\"http://i0.wp.com/wpdotorg.files.wordpress.com/2013/12/overview.jpg?resize=623%2C193\" data-recalc-dims=\"1\" /></p>
<p>WordPress has gotten a facelift. 3.8 brings a fresh new look to the entire admin dashboard. Gone are overbearing gradients and dozens of shades of grey — bring on a bigger, bolder, more colorful design!</p>
<p><img class=\"aligncenter  wp-image-2856\" style=\"margin-left: 0;margin-right: 0\" alt=\"about-modern-wordpress\" src=\"http://i2.wp.com/wpdotorg.files.wordpress.com/2013/12/design.png?resize=623%2C151\" data-recalc-dims=\"1\" /></p>
<h3>Modern aesthetic</h3>
<p>The new WordPress dashboard has a fresh, uncluttered design that embraces clarity and simplicity.</p>
<h3>Clean typography</h3>
<p>The Open Sans typeface provides simple, friendly text that is optimized for both desktop and mobile viewing. It’s even open source, just like WordPress.</p>
<h3>Refined contrast</h3>
<p>We think beautiful design should never sacrifice legibility. With superior contrast and large, comfortable type, the new design is easy to read and a pleasure to navigate.</p>
<hr />
<h2 class=\"aligncenter\">WordPress on every device</h2>
<p><img class=\"alignright  wp-image-2984\" alt=\"responsive\" src=\"http://i2.wp.com/wpdotorg.files.wordpress.com/2013/12/responsive.jpg?resize=255%2C255\" data-recalc-dims=\"1\" />We all access the internet in different ways. Smartphone, tablet, notebook, desktop — no matter what you use, WordPress will adapt and you’ll feel right at home.</p>
<h3>High definition at high speed</h3>
<p>WordPress is sharper than ever with new vector-based icons that scale to your screen. By ditching pixels, pages load significantly faster, too.</p>
<hr />
<h2 class=\"aligncenter\">Admin color schemes to match your personality</h2>
<p><img class=\"aligncenter  wp-image-2954\" alt=\"colors\" src=\"http://i0.wp.com/wpdotorg.files.wordpress.com/2013/12/colors.jpg?resize=623%2C339\" data-recalc-dims=\"1\" /></p>
<p>WordPress just got a colorful new update. We’ve included eight new admin color schemes so you can pick the one that suits you best.</p>
<p>Color schemes can be previewed and changed from your Profile page.</p>
<hr />
<h2 class=\"aligncenter\">Refined theme management</h2>
<p><img class=\"alignright  wp-image-2967\" alt=\"themes\" src=\"http://i0.wp.com/wpdotorg.files.wordpress.com/2013/12/themes.jpg?resize=360%2C344\" data-recalc-dims=\"1\" />The new themes screen lets you survey your themes at a glance. Or want more information? Click to discover more. Then sit back and use your keyboard’s navigation arrows to flip through every theme you’ve got.</p>
<h3>Smoother widget experience</h3>
<p>Drag-drag-drag. Scroll-scroll-scroll. Widget management can be complicated. With the new design, we’ve worked to streamline the widgets screen.</p>
<p>Have a large monitor? Multiple widget areas stack side-by-side to use the available space. Using a tablet? Just tap a widget to add it.</p>
<hr />
<h2 class=\"aligncenter\">Twenty Fourteen, a sleek new magazine theme</h2>
<p><img class=\"aligncenter size-large wp-image-2789\" alt=\"The new Twenty Fourteen theme displayed on a laptop. tablet and phone\" src=\"http://i0.wp.com/wpdotorg.files.wordpress.com/2013/12/twentyfourteen.jpg?resize=692%2C275\" data-recalc-dims=\"1\" /></p>
<h3>Turn your blog into a magazine</h3>
<p>Create a beautiful magazine-style site with WordPress and Twenty Fourteen. Choose a grid or a slider to display featured content on your homepage. Customize your site with three widget areas or change your layout with two page templates.</p>
<p>With a striking design that does not compromise our trademark simplicity, Twenty Fourteen is our most intrepid default theme yet.</p>
<hr />
<h2>Beginning of a new era</h2>
<p>This release was led by Matt Mullenweg. This is our second release using the new plugin-first development process, with a much shorter timeframe than in the past. We think it’s been going great. You can check out the features currently in production on the <a title=\"Make WordPress Core\" href=\"http://make.wordpress.org/core/\" target=\"_blank\">make/core blog</a>.</p>
<p>There are 188 contributors with props in this release:</p>
<p><a href=\"http://profiles.wordpress.org/aaronholbrook\">Aaron Holbrook</a>, <a href=\"http://profiles.wordpress.org/jorbin\">Aaron Jorbin</a>, <a href=\"http://profiles.wordpress.org/adamsilverstein\">adamsilverstein</a>, <a href=\"http://profiles.wordpress.org/admiralthrawn\">admiralthrawn</a>, <a href=\"http://profiles.wordpress.org/ahoereth\">Alexander Hoereth</a>, <a href=\"http://profiles.wordpress.org/sabreuse\">Amy Hendrix (sabreuse)</a>, <a href=\"http://profiles.wordpress.org/nacin\">Andrew Nacin</a>, <a href=\"http://profiles.wordpress.org/azaozz\">Andrew Ozz</a>, <a href=\"http://profiles.wordpress.org/aralbald\">Andrey Kabakchiev</a>, <a href=\"http://profiles.wordpress.org/apeatling\">Andy Peatling</a>, <a href=\"http://profiles.wordpress.org/ankitgadertcampcom\">Ankit Gade</a>, <a href=\"http://profiles.wordpress.org/atimmer\">Anton Timmermans</a>, <a href=\"http://profiles.wordpress.org/fliespl\">Arkadiusz Rzadkowolski</a>, <a href=\"http://profiles.wordpress.org/aubreypwd\">Aubrey Portwood</a>, <a href=\"http://profiles.wordpress.org/bassgang\">bassgang</a>, <a href=\"http://profiles.wordpress.org/empireoflight\">Ben Dunkle</a>, <a href=\"http://profiles.wordpress.org/bananastalktome\">Billy (bananastalktome)</a>, <a href=\"http://profiles.wordpress.org/binarymoon\">binarymoon</a>, <a href=\"http://profiles.wordpress.org/bradyvercher\">Brady Vercher</a>, <a href=\"http://profiles.wordpress.org/kraftbj\">Brandon Kraft</a>, <a href=\"http://profiles.wordpress.org/rzen\">Brian Richards</a>, <a href=\"http://profiles.wordpress.org/bpetty\">Bryan Petty</a>, <a href=\"http://profiles.wordpress.org/calin\">Calin Don</a>, <a href=\"http://profiles.wordpress.org/carldanley\">Carl Danley</a>, <a href=\"http://profiles.wordpress.org/sixhours\">Caroline Moore</a>, <a href=\"http://profiles.wordpress.org/caspie\">Caspie</a>, <a href=\"http://profiles.wordpress.org/chrisbliss18\">Chris Jean</a>, <a href=\"http://profiles.wordpress.org/iblamefish\">Clinton Montague</a>, <a href=\"http://profiles.wordpress.org/corphi\">Corphi</a>, <a href=\"http://profiles.wordpress.org/dbernar1\">Dan Bernardic</a>, <a href=\"http://profiles.wordpress.org/danieldudzic\">Daniel Dudzic</a>, <a href=\"http://profiles.wordpress.org/koop\">Daryl Koopersmith</a>, <a href=\"http://profiles.wordpress.org/datafeedrcom\">datafeedr</a>, <a href=\"http://profiles.wordpress.org/lessbloat\">Dave Martin</a>, <a href=\"http://profiles.wordpress.org/drw158\">Dave Whitley</a>, <a href=\"http://profiles.wordpress.org/dd32\">Dion Hulse</a>, <a href=\"http://profiles.wordpress.org/ocean90\">Dominik Schilling</a>, <a href=\"http://profiles.wordpress.org/dougwollison\">Doug Wollison</a>, <a href=\"http://profiles.wordpress.org/drewapicture\">Drew Jaynes</a>, <a href=\"http://profiles.wordpress.org/dziudek\">dziudek</a>, <a href=\"http://profiles.wordpress.org/ericlewis\">Eric Andrew Lewis</a>, <a href=\"http://profiles.wordpress.org/ericmann\">Eric Mann</a>, <a href=\"http://profiles.wordpress.org/ethitter\">Erick Hitter</a>, <a href=\"http://profiles.wordpress.org/evansolomon\">Evan Solomon</a>, <a href=\"http://profiles.wordpress.org/faison\">Faison</a>, <a href=\"http://profiles.wordpress.org/frank-klein\">Frank Klein</a>, <a href=\"http://profiles.wordpress.org/garyj\">Gary Jones</a>, <a href=\"http://profiles.wordpress.org/pento\">Gary Pendergast</a>, <a href=\"http://profiles.wordpress.org/soulseekah\">Gennady Kovshenin</a>, <a href=\"http://profiles.wordpress.org/georgestephanis\">George Stephanis</a>, <a href=\"http://profiles.wordpress.org/gnarf37\">gnarf37</a>, <a href=\"http://profiles.wordpress.org/tivnet\">Gregory Karpinsky</a>, <a href=\"http://profiles.wordpress.org/hanni\">hanni</a>, <a href=\"http://profiles.wordpress.org/helen\">Helen Hou-Sandi</a>, <a href=\"http://profiles.wordpress.org/iandunn\">Ian Dunn</a>, <a href=\"http://profiles.wordpress.org/ipstenu\">Ipstenu (Mika Epstein)</a>, <a href=\"http://profiles.wordpress.org/isaackeyet\">Isaac Keyet</a>, <a href=\"http://profiles.wordpress.org/jdgrimes\">J.D. Grimes</a>, <a href=\"http://profiles.wordpress.org/jacklenox\">Jack Lenox</a>, <a href=\"http://profiles.wordpress.org/janhenckens\">janhenckens</a>, <a href=\"http://profiles.wordpress.org/jblz\">Jeff Bowen</a>, <a href=\"http://profiles.wordpress.org/jeffr0\">Jeff Chandler</a>, <a href=\"http://profiles.wordpress.org/jenmylo\">Jen Mylo</a>, <a href=\"http://profiles.wordpress.org/buffler\">Jeremy Buller</a>, <a href=\"http://profiles.wordpress.org/jeremyfelt\">Jeremy Felt</a>, <a href=\"http://profiles.wordpress.org/jeherve\">Jeremy Herve</a>, <a href=\"http://profiles.wordpress.org/jpry\">Jeremy Pry</a>, <a href=\"http://profiles.wordpress.org/jayjdk\">Jesper Johansen (jayjdk)</a>, <a href=\"http://profiles.wordpress.org/jhned\">jhned</a>, <a href=\"http://profiles.wordpress.org/jim912\">jim912</a>, <a href=\"http://profiles.wordpress.org/jartes\">Joan Artes</a>, <a href=\"http://profiles.wordpress.org/joedolson\">Joe Dolson</a>, <a href=\"http://profiles.wordpress.org/joen\">Joen Asmussen</a>, <a href=\"http://profiles.wordpress.org/johnbillion\">John Blackbourn</a>, <a href=\"http://profiles.wordpress.org/johnafish\">John Fish</a>, <a href=\"http://profiles.wordpress.org/johnjamesjacoby\">John James Jacoby</a>, <a href=\"http://profiles.wordpress.org/duck_\">Jon Cave</a>, <a href=\"http://profiles.wordpress.org/joostdevalk\">Joost de Valk</a>, <a href=\"http://profiles.wordpress.org/joshuaabenazer\">Joshua Abenazer</a>, <a href=\"http://profiles.wordpress.org/nukaga\">Junko Nukaga</a>, <a href=\"http://profiles.wordpress.org/devesine\">Justin de Vesine</a>, <a href=\"http://profiles.wordpress.org/justinsainton\">Justin Sainton</a>, <a href=\"http://profiles.wordpress.org/kadamwhite\">K. Adam White</a>, <a href=\"http://profiles.wordpress.org/trepmal\">Kailey (trepmal)</a>, <a href=\"http://profiles.wordpress.org/codebykat\">Kat Hagan</a>, <a href=\"http://profiles.wordpress.org/littlethingsstudio\">Kate Whitley</a>, <a href=\"http://profiles.wordpress.org/ryelle\">Kelly Dwan</a>, <a href=\"http://profiles.wordpress.org/kpdesign\">Kim Parsell</a>, <a href=\"http://profiles.wordpress.org/kwight\">Kirk Wight</a>, <a href=\"http://profiles.wordpress.org/koki4a\">Konstantin Dankov</a>, <a href=\"http://profiles.wordpress.org/kovshenin\">Konstantin Kovshenin</a>, <a href=\"http://profiles.wordpress.org/obenland\">Konstantin Obenland</a>, <a href=\"http://profiles.wordpress.org/drozdz\">Krzysiek Drozdz</a>, <a href=\"http://profiles.wordpress.org/lancewillett\">Lance Willett</a>, <a href=\"http://profiles.wordpress.org/leewillis77\">Lee Willis</a>, <a href=\"http://profiles.wordpress.org/lite3\">lite3</a>, <a href=\"http://profiles.wordpress.org/lucp\">Luc Princen</a>, <a href=\"http://profiles.wordpress.org/latz\">Lutz Schroer</a>, <a href=\"http://profiles.wordpress.org/mako09\">Mako</a>, <a href=\"http://profiles.wordpress.org/markjaquith\">Mark Jaquith</a>, <a href=\"http://profiles.wordpress.org/markmcwilliams\">Mark McWilliams</a>, <a href=\"http://profiles.wordpress.org/markoheijnen\">Marko Heijnen</a>, <a href=\"http://profiles.wordpress.org/matt\">Matt Mullenweg</a>, <a href=\"http://profiles.wordpress.org/iammattthomas\">Matt Thomas</a>, <a href=\"http://profiles.wordpress.org/mattwiebe\">Matt Wiebe</a>, <a href=\"http://profiles.wordpress.org/mdbitz\">Matthew Denton</a>, <a href=\"http://profiles.wordpress.org/mattheu\">Matthew Haines-Young</a>, <a href=\"http://profiles.wordpress.org/matveb\">Matías Ventura</a>, <a href=\"http://profiles.wordpress.org/megane9988\">megane9988</a>, <a href=\"http://profiles.wordpress.org/melchoyce\">Mel Choyce</a>, <a href=\"http://profiles.wordpress.org/micahwave\">micahwave</a>, <a href=\"http://profiles.wordpress.org/cainm\">Michael Cain</a>, <a href=\"http://profiles.wordpress.org/mitchoyoshitaka\">Michael Erlewine</a>, <a href=\"http://profiles.wordpress.org/michelwppi\">Michel - xiligroup dev</a>, <a href=\"http://profiles.wordpress.org/chellycat\">Michelle Langston</a>, <a href=\"http://profiles.wordpress.org/gradyetc\">Mike Burns</a>, <a href=\"http://profiles.wordpress.org/mikehansenme\">Mike Hansen</a>, <a href=\"http://profiles.wordpress.org/mikelittle\">Mike Little</a>, <a href=\"http://profiles.wordpress.org/dh-shredder\">Mike Schroder</a>, <a href=\"http://profiles.wordpress.org/dimadin\">Milan Dinic</a>, <a href=\"http://profiles.wordpress.org/batmoo\">Mohammad Jangda</a>, <a href=\"http://profiles.wordpress.org/morganestes\">Morgan Estes</a>, <a href=\"http://profiles.wordpress.org/mt8biz\">moto hachi</a>, <a href=\"http://profiles.wordpress.org/Nao\">Naoko Takano</a>, <a href=\"http://profiles.wordpress.org/neil_pie\">Neil Pie</a>, <a href=\"http://profiles.wordpress.org/nickdaugherty\">Nick Daugherty</a>, <a href=\"http://profiles.wordpress.org/celloexpressions\">Nick Halsey</a>, <a href=\"http://profiles.wordpress.org/nbachiyski\">Nikolay Bachiyski</a>, <a href=\"http://profiles.wordpress.org/ninio\">ninio</a>, <a href=\"http://profiles.wordpress.org/ninnypants\">ninnypants</a>, <a href=\"http://profiles.wordpress.org/nofearinc\">nofearinc</a>, <a href=\"http://profiles.wordpress.org/nvwd\">Nowell VanHoesen</a>, <a href=\"http://profiles.wordpress.org/odysseygate\">odyssey</a>, <a href=\"http://profiles.wordpress.org/originalexe\">OriginalEXE</a>, <a href=\"http://profiles.wordpress.org/swissspidy\">Pascal Birchler</a>, <a href=\"http://profiles.wordpress.org/pauldewouters\">Paul de Wouters</a>, <a href=\"http://profiles.wordpress.org/pavelevap\">pavelevap</a>, <a href=\"http://profiles.wordpress.org/westi\">Peter Westwood</a>, <a href=\"http://profiles.wordpress.org/senlin\">Piet</a>, <a href=\"http://profiles.wordpress.org/ptahdunbar\">Ptah Dunbar</a>, <a href=\"http://profiles.wordpress.org/raamdev\">Raam Dev</a>, <a href=\"http://profiles.wordpress.org/bamadesigner\">Rachel Carden</a>, <a href=\"http://profiles.wordpress.org/rachelbaker\">rachelbaker</a>, <a href=\"http://profiles.wordpress.org/radices\">Radices</a>, <a href=\"http://profiles.wordpress.org/mauryaratan\">Ram Ratan Maurya</a>, <a href=\"http://profiles.wordpress.org/defries\">Remkus de Vries</a>, <a href=\"http://profiles.wordpress.org/ounziw\">Rescuework Support</a>, <a href=\"http://profiles.wordpress.org/rickalee\">Ricky Lee Whittemore</a>, <a href=\"http://profiles.wordpress.org/rdall\">Robert Dall</a>, <a href=\"http://profiles.wordpress.org/wet\">Robert Wetzlmayr, PHP-Programmierer</a>, <a href=\"http://profiles.wordpress.org/rodrigosprimo\">Rodrigo Primo</a>, <a href=\"http://profiles.wordpress.org/ryan\">Ryan Boren</a>, <a href=\"http://profiles.wordpress.org/otto42\">Samuel Wood</a>, <a href=\"http://profiles.wordpress.org/sanchothefat\">sanchothefat</a>, <a href=\"http://profiles.wordpress.org/sboisvert\">sboisvert</a>, <a href=\"http://profiles.wordpress.org/scottbasgaard\">Scott Basgaard</a>, <a href=\"http://profiles.wordpress.org/coffee2code\">Scott Reilly</a>, <a href=\"http://profiles.wordpress.org/wonderboymusic\">Scott Taylor</a>, <a href=\"http://profiles.wordpress.org/scribu\">scribu</a>, <a href=\"http://profiles.wordpress.org/seanchayes\">Sean Hayes</a>, <a href=\"http://profiles.wordpress.org/sergeybiryukov\">Sergey Biryukov</a>, <a href=\"http://profiles.wordpress.org/shaunandrews\">Shaun Andrews</a>, <a href=\"http://profiles.wordpress.org/designsimply\">Sheri Bigelow (designsimply)</a>, <a href=\"http://profiles.wordpress.org/shinichin\">ShinichiN</a>, <a href=\"http://profiles.wordpress.org/simonwheatley\">Simon Wheatley</a>, <a href=\"http://profiles.wordpress.org/siobhan\">Siobhan</a>, <a href=\"http://profiles.wordpress.org/siobhyb\">Siobhan Bamber (siobhyb)</a>, <a href=\"http://profiles.wordpress.org/sirbrillig\">sirbrillig</a>, <a href=\"http://profiles.wordpress.org/solarissmoke\">solarissmoke</a>, <a href=\"http://profiles.wordpress.org/netweb\">Stephen Edgar</a>, <a href=\"http://profiles.wordpress.org/stephenharris\">Stephen Harris</a>, <a href=\"http://profiles.wordpress.org/stevenkword\">Steven Word</a>, <a href=\"http://profiles.wordpress.org/iamtakashi\">Takashi Irie</a>, <a href=\"http://profiles.wordpress.org/miyauchi\">Takayuki Miyauchi</a>, <a href=\"http://profiles.wordpress.org/tmtoy\">Takuma Morikawa</a>, <a href=\"http://profiles.wordpress.org/thomasguillot\">Thomas Guillot</a>, <a href=\"http://profiles.wordpress.org/tierra\">tierra</a>, <a href=\"http://profiles.wordpress.org/tillkruess\">Till Krüss</a>, <a href=\"http://profiles.wordpress.org/tlamedia\">TLA Media</a>, <a href=\"http://profiles.wordpress.org/tobiasbg\">TobiasBg</a>, <a href=\"http://profiles.wordpress.org/tommcfarlin\">tommcfarlin</a>, <a href=\"http://profiles.wordpress.org/zodiac1978\">Torsten Landsiedel</a>, <a href=\"http://profiles.wordpress.org/taupecat\">Tracy Rotton</a>, <a href=\"http://profiles.wordpress.org/trishasalas\">trishasalas</a>, <a href=\"http://profiles.wordpress.org/mbmufffin\">Tyler Smith</a>, <a href=\"http://profiles.wordpress.org/grapplerulrich\">Ulrich</a>, <a href=\"http://profiles.wordpress.org/l10n\">Vladimir</a>, <a href=\"http://profiles.wordpress.org/westonruter\">Weston Ruter</a>, <a href=\"http://profiles.wordpress.org/yoavf\">Yoav Farhi</a>, <a href=\"http://profiles.wordpress.org/yonasy\">yonasy</a>, and <a href=\"http://profiles.wordpress.org/tollmanz\">Zack Tollman</a>. Also thanks to <a href=\"http://benmorrison.org/\">Ben Morrison</a> and <a href=\"http://christineswebb.com/\">Christine Webb</a> for help with the video.</p>
<p>Thanks for choosing WordPress. See you soon for version 3.9!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"http://wordpress.org/news/2013/12/parker/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"3.8 RC2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"http://wordpress.org/news/2013/12/3-8-rc2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"http://wordpress.org/news/2013/12/3-8-rc2/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 10 Dec 2013 01:08:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=2805\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:343:\"Release candidate 2 of WordPress 3.8 is now available for download. This is the last pre-release, and we expect it to be effectively identical to what&#8217;s officially released to the public on Thursday. This means if you are a plugin or theme developer, start your engines! (If they&#8217;re not going already.) Lots of admin code [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1180:\"<p>Release candidate 2 of WordPress 3.8 is <a href=\"http://wordpress.org/wordpress-3.8-RC2.zip\">now available for download</a>. This is the last pre-release, and we expect it to be effectively identical to what&#8217;s officially released to the public on Thursday.</p>
<p>This means if you are a plugin or theme developer, start your engines! (If they&#8217;re not going already.) Lots of admin code has changed so it&#8217;s especially important to see if your plugin works well within the new admin design and layout, and update <a href=\"http://wordpress.org/plugins/about/readme.txt\">the &#8220;Tested up to:&#8221; part of your plugin readme.txt</a>.</p>
<p>If there is something in your plugin that you&#8217;re unable to fix, or if you think you&#8217;ve found a bug, join us <a href=\"http://codex.wordpress.org/IRC\">in #wordpress-dev in IRC</a>, especially if you&#8217;re able to join during the dev chat on Wednesday, or post in the <a href=\"http://wordpress.org/support/forum/alphabeta\">alpha/beta forum</a>. The developers and designers who worked on this release are happy to help anyone update their code before the 3.8 release.</p>
<p>Happy hacking, everybody!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"http://wordpress.org/news/2013/12/3-8-rc2/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"WordPress 3.8 RC1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"http://wordpress.org/news/2013/12/3-8-almost/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"http://wordpress.org/news/2013/12/3-8-almost/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 04 Dec 2013 09:54:48 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=2760\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:345:\"We&#8217;re entering the quiet but busy part of a release, whittling down issues to bring you all of the new features you&#8217;re excited about with the stability you expect from WordPress. There are just a few days from the &#8220;code freeze&#8221; for our 3.8 release, which includes a number of exciting enhancements, so the focus [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1873:\"<p>We&#8217;re entering the quiet but busy part of a release, whittling down issues to bring you all of the new features you&#8217;re excited about with the stability you expect from WordPress. There are just a few days from the &#8220;code freeze&#8221; for our 3.8 release, <a href=\"http://wordpress.org/news/2013/11/wordpress-3-8-beta-1/\">which includes a number of exciting enhancements</a>, so the focus is on identifying any major issues and resolving them as soon as possible.</p>
<p>If you&#8217;ve ever wondered about how to contribute to WordPress, here&#8217;s a time you can: download this release candidate and use it in as many ways as you can imagine. Try to break it, and if you do, let us know how you did it so we can make sure it never happens again. If you work for a web host, this is the release you should test as much as possible and start getting your automatic upgrade systems and 1-click installers ready.</p>
<p><a href=\"http://wordpress.org/wordpress-3.8-RC1.zip\">Download WordPress 3.8 RC1</a> (zip) or use the <a href=\"http://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;).</p>
<p>If you think you’ve found a bug, you can post to the <a href=\"http://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href=\"http://core.trac.wordpress.org/\">file one on the WordPress Trac</a>. There, you can also find <a href=\"http://core.trac.wordpress.org/report/5\">a list of known bugs</a> and <a href=\"http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.8\">everything we’ve fixed</a> so far.</p>
<p><em>We&#8217;re so close to the</em><br />
<em>finish line, jump in and help</em><br />
<em>good karma is yours.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"http://wordpress.org/news/2013/12/3-8-almost/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 3.8 Beta 1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"http://wordpress.org/news/2013/11/wordpress-3-8-beta-1/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"http://wordpress.org/news/2013/11/wordpress-3-8-beta-1/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 21 Nov 2013 05:21:56 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=2754\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:307:\"The first beta of the 3.8 is now available, and the next dates to watch out for are code freeze on December 5th and a final release on December 12th. 3.8 brings together several of the features as plugins projects and while this isn&#8217;t our first rodeo, expect this to be more beta than usual. [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2236:\"<p>The first beta of the 3.8 is now available, and the next dates to watch out for are code freeze on December 5th and a final release on December 12th.</p>
<p>3.8 brings together <a href=\"http://make.wordpress.org/core/features-as-plugins/\">several of the features as plugins projects</a> and while this isn&#8217;t our first rodeo, expect this to be more beta than usual. The headline things to test out in this release are:</p>
<ul>
<li>The new admin design, especially the responsive aspect of it. Try it out on different devices and browsers, see how it goes, especially the more complex pages like widgets or seldom-looked-at-places like Press This. Color schemes, which you can change on your profile, have also been spruced up.</li>
<li>The dashboard homepage has been refreshed, poke and prod it.</li>
<li>Choosing themes under Appearance is completely different, try to break it however possible.</li>
<li>There&#8217;s a new default theme, Twenty Fourteen.</li>
<li>Over 250 issues closed already.</li>
</ul>
<p>Given how many things in the admin have changed it&#8217;s extra super duper important to test as many plugins and themes with admin pages against the new stuff. Also if you&#8217;re a developer consider how you can make your admin interface fit the MP6 aesthetic better.</p>
<p>As always, if you think you’ve found a bug, you can post to the <a href=\"http://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href=\"http://core.trac.wordpress.org/\">file one on the WordPress Trac</a>. There, you can also find <a href=\"http://core.trac.wordpress.org/report/5\">a list of known bugs</a> and <a href=\"http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.8\">everything we’ve fixed</a> so far.</p>
<p><a href=\"http://wordpress.org/wordpress-3.8-beta-1.zip\">Download WordPress 3.8 Beta 1</a> (zip) or use the <a href=\"http://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;).</p>
<p><em>Alphabet soup of</em><br />
<em>Plugins as features galore</em><br />
<em>The future is here</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"http://wordpress.org/news/2013/11/wordpress-3-8-beta-1/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"WordPress 3.7.1 Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"http://wordpress.org/news/2013/10/wordpress-3-7-1/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"http://wordpress.org/news/2013/10/wordpress-3-7-1/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 29 Oct 2013 21:04:59 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=2745\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:371:\"WordPress 3.7.1 is now available! This maintenance release addresses 11 bugs in WordPress 3.7, including: Images with captions no longer appear broken in the visual editor. Allow some sites running on old or poorly configured servers to continue to check for updates from WordPress.org. Avoid fatal errors with certain plugins that were incorrectly calling some [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Andrew Nacin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1594:\"<p>WordPress 3.7.1 is now available! This maintenance release addresses 11 bugs in WordPress 3.7, including:</p>
<ul>
<li>Images with captions no longer appear broken in the visual editor.</li>
<li>Allow some sites running on old or poorly configured servers to continue to check for updates from WordPress.org.</li>
<li>Avoid fatal errors with certain plugins that were incorrectly calling some WordPress functions too early.</li>
<li>Fix hierarchical sorting in get_pages(), exclusions in wp_list_categories(), and in_category() when called with empty values.</li>
<li>Fix a warning that may occur in certain setups while performing a search, and a few other notices.</li>
</ul>
<p>For a full list of changes, consult the <a href=\"http://core.trac.wordpress.org/query?milestone=3.7.1\">list of tickets</a> and <a href=\"http://core.trac.wordpress.org/log/branches/3.7?stop_rev=25914&amp;rev=25986\">the changelog</a>.</p>
<p>If you are one of the <a href=\"http://wordpress.org/download/counter/\">nearly two million</a> already running WordPress 3.7, we will start rolling out the all-new <a href=\"http://wordpress.org/news/2013/10/basie/\">automatic background updates</a> for WordPress 3.7.1 in the next few hours. For sites <a href=\"http://wordpress.org/plugins/background-update-tester/\">that support them</a>, of course.</p>
<p><a href=\"http://wordpress.org/download/\">Download WordPress 3.7.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p><em>Just a few fixes<br />
Your new update attitude:<br />
Zero clicks given</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"http://wordpress.org/news/2013/10/wordpress-3-7-1/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:42:\"
		
		
		
		
		
				

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"WordPress 3.7 “Basie”\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"http://wordpress.org/news/2013/10/basie/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"http://wordpress.org/news/2013/10/basie/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 24 Oct 2013 22:35:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=2736\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:357:\"Version 3.7 of WordPress, named &#8220;Basie&#8221; in honor of Count Basie, is available for download or update in your WordPress dashboard. This release features some of the most important architectural updates we&#8217;ve made to date. Here are the big ones: Updates while you sleep: With WordPress 3.7, you don&#8217;t have to lift a finger to [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:17229:\"<p>Version 3.7 of WordPress, named &#8220;Basie&#8221; in honor of <a href=\"http://en.wikipedia.org/wiki/Count_basie\">Count Basie</a>, is available <a href=\"http://wordpress.org/download/\">for download</a> or update in your WordPress dashboard. This release features some of the most important architectural updates we&#8217;ve made to date. Here are the big ones:</p>
<ul>
<li><strong>Updates while you sleep</strong>: With WordPress 3.7, you don&#8217;t have to lift a finger to apply maintenance and security updates. Most sites are now able to automatically apply these updates in the background. The update process also has been made even more reliable and secure, with dozens of new checks and safeguards.</li>
<li><strong>Stronger password recommendations</strong>: Your password is your site&#8217;s first line of defense. It&#8217;s best to create passwords that are complex, long, and unique. To that end, our password meter has been updated in WordPress 3.7 to recognize common mistakes that can weaken your password: dates, names, keyboard patterns (123456789), and even pop culture references.</li>
<li><strong>Better global support</strong>: Localized versions of WordPress will receive faster and more complete translations. WordPress 3.7 adds support for automatically installing the right language files and keeping them up to date, a boon for the many millions who use WordPress in a language other than English.</li>
</ul>
<p>For developers there are lots of options around how to control the new updates feature, including allowing it to handle major upgrades as well as minor ones, more sophisticated date query support, and multisite improvements. As always, if you&#8217;re hungry for more <a href=\"http://codex.wordpress.org/Version_3.7\">dive into the Codex</a> or browse the <a href=\"http://core.trac.wordpress.org/query?status=closed&amp;group=resolution&amp;milestone=3.7\">over 400 closed tickets on Trac</a>.</p>
<h3>A New Wave</h3>
<p>This release was led by Andrew Nacin, backed up by Dion Hulse and Jon Cave. This is our first release using the new plugin-first development process, with a much shorter timeframe than in the past. (3.6 was released in August.) The 3.8 release, due in December, will continue this plugin-led development cycle that gives much more autonomy to plugin leads and allows us to decouple feature development from a release. You can follow this grand experiment, and what we&#8217;re learning from it, <a href=\"http://make.wordpress.org/core/\">on the make/core blog</a>. There are 211 contributors with props in this release:</p>
<p><a href=\"http://profiles.wordpress.org/technosailor\">Aaron Brazell</a>, <a href=\"http://profiles.wordpress.org/aaroncampbell\">Aaron D. Campbell</a>, <a href=\"http://profiles.wordpress.org/aaronholbrook\">Aaron Holbrook</a>, <a href=\"http://profiles.wordpress.org/jorbin\">Aaron Jorbin</a>, <a href=\"http://profiles.wordpress.org/adamsilverstein\">adamsilverstein</a>, <a href=\"http://profiles.wordpress.org/ahoereth\">Alexander Hoereth</a>, <a href=\"http://profiles.wordpress.org/viper007bond\">Alex Mills (Viper007Bond)</a>, <a href=\"http://profiles.wordpress.org/sabreuse\">Amy Hendrix (sabreuse)</a>, <a href=\"http://profiles.wordpress.org/andg\">andg</a>, <a href=\"http://profiles.wordpress.org/nacin\">Andrew Nacin</a>, <a href=\"http://profiles.wordpress.org/norcross\">Andrew Norcross</a>, <a href=\"http://profiles.wordpress.org/azaozz\">Andrew Ozz</a>, <a href=\"http://profiles.wordpress.org/andrewspittle\">Andrew Spittle</a>, <a href=\"http://profiles.wordpress.org/askapache\">askapache</a>, <a href=\"http://profiles.wordpress.org/atimmer\">atimmer</a>, <a href=\"http://profiles.wordpress.org/barry\">Barry</a>, <a href=\"http://profiles.wordpress.org/beaulebens\">Beau Lebens</a>, <a href=\"http://profiles.wordpress.org/benmoody\">ben.moody</a>, <a href=\"http://profiles.wordpress.org/bhengh\">Ben Miller</a>, <a href=\"http://profiles.wordpress.org/neoxx\">Bernhard Riedl</a>, <a href=\"http://profiles.wordpress.org/bftrick\">BFTrick</a>, <a href=\"http://profiles.wordpress.org/bananastalktome\">Billy (bananastalktome)</a>, <a href=\"http://profiles.wordpress.org/bmb\">bmb</a>, <a href=\"http://profiles.wordpress.org/kraftbj\">Brandon Kraft</a>, <a href=\"http://profiles.wordpress.org/brianhogg\">brianhogg</a>, <a href=\"http://profiles.wordpress.org/rzen\">Brian Richards</a>, <a href=\"http://profiles.wordpress.org/bpetty\">Bryan Petty</a>, <a href=\"http://profiles.wordpress.org/carldanley\">Carl Danley</a>, <a href=\"http://profiles.wordpress.org/charlesclarkson\">CharlesClarkson</a>, <a href=\"http://profiles.wordpress.org/chipbennett\">Chip Bennett</a>, <a href=\"http://profiles.wordpress.org/chouby\">Chouby</a>, <a href=\"http://profiles.wordpress.org/c3mdigital\">Chris Olbekson</a>, <a href=\"http://profiles.wordpress.org/chrisrudzki\">Chris Rudzki</a>, <a href=\"http://profiles.wordpress.org/aeg0125\">coderaaron</a>, <a href=\"http://profiles.wordpress.org/coenjacobs\">Coen Jacobs</a>, <a href=\"http://profiles.wordpress.org/crrobi01\">Colin Robinson</a>, <a href=\"http://profiles.wordpress.org/andreasnrb\">cyonite</a>, <a href=\"http://profiles.wordpress.org/daankortenbach\">Daan Kortenbach</a>, <a href=\"http://profiles.wordpress.org/danielbachhuber\">Daniel Bachhuber</a>, <a href=\"http://profiles.wordpress.org/convissor\">Daniel Convissor</a>, <a href=\"http://profiles.wordpress.org/dartiss\">dartiss</a>, <a href=\"http://profiles.wordpress.org/koop\">Daryl Koopersmith</a>, <a href=\"http://profiles.wordpress.org/csixty4\">Dave Ross</a>, <a href=\"http://profiles.wordpress.org/davidjlaietta\">David Laietta</a>, <a href=\"http://profiles.wordpress.org/dd32\">Dion Hulse</a>, <a href=\"http://profiles.wordpress.org/dllh\">dllh</a>, <a href=\"http://profiles.wordpress.org/ocean90\">Dominik Schilling (ocean90)</a>, <a href=\"http://profiles.wordpress.org/dpash\">dpash</a>, <a href=\"http://profiles.wordpress.org/drewapicture\">Drew Jaynes</a>, <a href=\"http://profiles.wordpress.org/drprotocols\">DrProtocols</a>, <a href=\"http://profiles.wordpress.org/dustyf\">Dustin Filippini</a>, <a href=\"http://profiles.wordpress.org/dzver\">dzver</a>, <a href=\"http://profiles.wordpress.org/cais\">Edward Caissie</a>, <a href=\"http://profiles.wordpress.org/enej\">enej</a>, <a href=\"http://profiles.wordpress.org/ericlewis\">Eric Andrew Lewis</a>, <a href=\"http://profiles.wordpress.org/ericmann\">Eric Mann</a>, <a href=\"http://profiles.wordpress.org/evansolomon\">Evan Solomon</a>, <a href=\"http://profiles.wordpress.org/faishal\">faishal</a>, <a href=\"http://profiles.wordpress.org/faison\">Faison</a>, <a href=\"http://profiles.wordpress.org/foofy\">Foofy</a>, <a href=\"http://profiles.wordpress.org/fjarrett\">Frankie Jarrett</a>, <a href=\"http://profiles.wordpress.org/frank-klein\">Frank Klein</a>, <a href=\"http://profiles.wordpress.org/garyc40\">Gary Cao</a>, <a href=\"http://profiles.wordpress.org/pento\">Gary Pendergast</a>, <a href=\"http://profiles.wordpress.org/gayadesign\">Gaya Kessler</a>, <a href=\"http://profiles.wordpress.org/georgestephanis\">George Stephanis</a>, <a href=\"http://profiles.wordpress.org/gizburdt\">Gizburdt</a>, <a href=\"http://profiles.wordpress.org/goldenapples\">goldenapples</a>, <a href=\"http://profiles.wordpress.org/gradyetc\">gradyetc</a>, <a href=\"http://profiles.wordpress.org/gcorne\">Gregory Cornelius</a>, <a href=\"http://profiles.wordpress.org/webord\">Gustavo Bordoni</a>, <a href=\"http://profiles.wordpress.org/hakre\">hakre</a>, <a href=\"http://profiles.wordpress.org/helen\">Helen Hou-Sandi</a>, <a href=\"http://profiles.wordpress.org/iandunn\">Ian Dunn</a>, <a href=\"http://profiles.wordpress.org/ipstenu\">Ipstenu (Mika Epstein)</a>, <a href=\"http://profiles.wordpress.org/creativeinfusion\">itinerant</a>, <a href=\"http://profiles.wordpress.org/jdgrimes\">J.D. Grimes</a>, <a href=\"http://profiles.wordpress.org/jakubtyrcha\">jakub.tyrcha</a>, <a href=\"http://profiles.wordpress.org/jamescollins\">James Collins</a>, <a href=\"http://profiles.wordpress.org/jenmylo\">Jen Mylo</a>, <a href=\"http://profiles.wordpress.org/buffler\">Jeremy Buller</a>, <a href=\"http://profiles.wordpress.org/jeremyfelt\">Jeremy Felt</a>, <a href=\"http://profiles.wordpress.org/jayjdk\">Jesper Johansen (jayjdk)</a>, <a href=\"http://profiles.wordpress.org/joehoyle\">Joe Hoyle</a>, <a href=\"http://profiles.wordpress.org/jkudish\">Joey Kudish</a>, <a href=\"http://profiles.wordpress.org/johnnyb\">John Beales</a>, <a href=\"http://profiles.wordpress.org/johnbillion\">John Blackbourn (johnbillion)</a>, <a href=\"http://profiles.wordpress.org/johnafish\">John Fish</a>, <a href=\"http://profiles.wordpress.org/johnjamesjacoby\">John James Jacoby</a>, <a href=\"http://profiles.wordpress.org/johnpbloch\">John P. Bloch</a>, <a href=\"http://profiles.wordpress.org/jond3r\">Jonas Bolinder (jond3r)</a>, <a href=\"http://profiles.wordpress.org/jchristopher\">Jonathan Christopher</a>, <a href=\"http://profiles.wordpress.org/desrosj\">Jonathan Desrosiers</a>, <a href=\"http://profiles.wordpress.org/duck_\">Jon Cave</a>, <a href=\"http://profiles.wordpress.org/jonlynch\">Jon Lynch</a>, <a href=\"http://profiles.wordpress.org/joostdevalk\">Joost de Valk</a>, <a href=\"http://profiles.wordpress.org/josephscott\">Joseph Scott</a>, <a href=\"http://profiles.wordpress.org/betzster\">Josh Betz</a>, <a href=\"http://profiles.wordpress.org/devesine\">Justin de Vesine</a>, <a href=\"http://profiles.wordpress.org/justinsainton\">Justin Sainton</a>, <a href=\"http://profiles.wordpress.org/kadamwhite\">K.Adam White</a>, <a href=\"http://profiles.wordpress.org/trepmal\">Kailey (trepmal)</a>, <a href=\"http://profiles.wordpress.org/ketwaroo\">Ketwaroo</a>, <a href=\"http://profiles.wordpress.org/kevinb\">kevinB</a>, <a href=\"http://profiles.wordpress.org/kpdesign\">Kim Parsell</a>, <a href=\"http://profiles.wordpress.org/kitchin\">kitchin</a>, <a href=\"http://profiles.wordpress.org/kovshenin\">Konstantin Kovshenin</a>, <a href=\"http://profiles.wordpress.org/obenland\">Konstantin Obenland</a>, <a href=\"http://profiles.wordpress.org/koopersmith\">koopersmith</a>, <a href=\"http://profiles.wordpress.org/kurtpayne\">Kurt Payne</a>, <a href=\"http://profiles.wordpress.org/lancewillett\">Lance Willett</a>, <a href=\"http://profiles.wordpress.org/leewillis77\">Lee Willis (leewillis77)</a>, <a href=\"http://profiles.wordpress.org/lessbloat\">lessbloat</a>, <a href=\"http://profiles.wordpress.org/layotte\">Lew Ayotte</a>, <a href=\"http://profiles.wordpress.org/lgedeon\">Luke Gedeon</a>, <a href=\"http://profiles.wordpress.org/iworks\">Marcin Pietrzak</a>, <a href=\"http://profiles.wordpress.org/cimmo\">Marco Cimmino</a>, <a href=\"http://profiles.wordpress.org/marco_teethgrinder\">Marco Galasso</a>, <a href=\"http://profiles.wordpress.org/markjaquith\">Mark Jaquith</a>, <a href=\"http://profiles.wordpress.org/markmcwilliams\">Mark McWilliams</a>, <a href=\"http://profiles.wordpress.org/markoheijnen\">Marko Heijnen</a>, <a href=\"http://profiles.wordpress.org/melchoyce\">Mel Choyce</a>, <a href=\"http://profiles.wordpress.org/tw2113\">Michael Beckwith</a>, <a href=\"http://profiles.wordpress.org/mikehansenme\">Mike Hansen</a>, <a href=\"http://profiles.wordpress.org/mikeschinkel\">Mike Schinkel</a>, <a href=\"http://profiles.wordpress.org/dh-shredder\">Mike Schroder</a>, <a href=\"http://profiles.wordpress.org/dimadin\">Milan Dinic</a>, <a href=\"http://profiles.wordpress.org/mitchoyoshitaka\">mitcho (Michael Yoshitaka Erlewine)</a>, <a href=\"http://profiles.wordpress.org/usermrpapa\">Mr Papa</a>, <a href=\"http://profiles.wordpress.org/Nao\">Naoko Takano</a>, <a href=\"http://profiles.wordpress.org/naomicbush\">Naomi</a>, <a href=\"http://profiles.wordpress.org/alex-ye\">Nashwan Doaqan</a>, <a href=\"http://profiles.wordpress.org/natejacobs\">NateJacobs</a>, <a href=\"http://profiles.wordpress.org/nathanrice\">nathanrice</a>, <a href=\"http://profiles.wordpress.org/niallkennedy\">Niall Kennedy</a>, <a href=\"http://profiles.wordpress.org/nickdaugherty\">Nick Daugherty</a>, <a href=\"http://profiles.wordpress.org/celloexpressions\">Nick Halsey</a>, <a href=\"http://profiles.wordpress.org/nickmomrik\">Nick Momrik</a>, <a href=\"http://profiles.wordpress.org/nikv\">Nikhil Vimal (NikV)</a>, <a href=\"http://profiles.wordpress.org/nbachiyski\">Nikolay Bachiyski</a>, <a href=\"http://profiles.wordpress.org/noahsilverstein\">noahsilverstein</a>, <a href=\"http://profiles.wordpress.org/nofearinc\">nofearinc</a>, <a href=\"http://profiles.wordpress.org/nukaga\">nukaga</a>, <a href=\"http://profiles.wordpress.org/nullvariable\">nullvariable</a>, <a href=\"http://profiles.wordpress.org/butuzov\">Oleg Butuzov</a>, <a href=\"http://profiles.wordpress.org/paolal\">Paolo Belcastro</a>, <a href=\"http://profiles.wordpress.org/xparham\">Parham</a>, <a href=\"http://profiles.wordpress.org/pbiron\">Paul Biron</a>, <a href=\"http://profiles.wordpress.org/pauldewouters\">Paul de Wouters</a>, <a href=\"http://profiles.wordpress.org/pavelevap\">pavelevap</a>, <a href=\"http://profiles.wordpress.org/peterjaap\">peterjaap</a>, <a href=\"http://profiles.wordpress.org/westi\">Peter Westwood</a>, <a href=\"http://profiles.wordpress.org/philiparthurmoore\">Philip Arthur Moore</a>, <a href=\"http://profiles.wordpress.org/mordauk\">Pippin Williamson</a>, <a href=\"http://profiles.wordpress.org/plocha\">plocha</a>, <a href=\"http://profiles.wordpress.org/pollett\">Pollett</a>, <a href=\"http://profiles.wordpress.org/ptahdunbar\">Ptah Dunbar</a>, <a href=\"http://profiles.wordpress.org/ramiy\">Rami Yushuvaev</a>, <a href=\"http://profiles.wordpress.org/rasheed\">Rasheed Bydousi</a>, <a href=\"http://profiles.wordpress.org/raybernard\">RayBernard</a>, <a href=\"http://profiles.wordpress.org/rboren\">rboren</a>, <a href=\"http://profiles.wordpress.org/greuben\">Reuben Gunday</a>, <a href=\"http://profiles.wordpress.org/rfair404\">rfair404</a>, <a href=\"http://profiles.wordpress.org/iamfriendly\">Richard Tape</a>, <a href=\"http://profiles.wordpress.org/r3df\">Rick Radko</a>, <a href=\"http://profiles.wordpress.org/miqrogroove\">Robert Chapin</a>, <a href=\"http://profiles.wordpress.org/rdall\">Robert Dall</a>, <a href=\"http://profiles.wordpress.org/rodrigosprimo\">Rodrigo Primo</a>, <a href=\"http://profiles.wordpress.org/wpmuguru\">Ron Rennick</a>, <a href=\"http://profiles.wordpress.org/rpattillo\">rpattillo</a>, <a href=\"http://profiles.wordpress.org/ryan\">Ryan Boren</a>, <a href=\"http://profiles.wordpress.org/rmccue\">Ryan McCue</a>, <a href=\"http://profiles.wordpress.org/hotchkissconsulting\">Sam Hotchkiss</a>, <a href=\"http://profiles.wordpress.org/coffee2code\">Scott Reilly</a>, <a href=\"http://profiles.wordpress.org/scottsweb\">scottsweb</a>, <a href=\"http://profiles.wordpress.org/wonderboymusic\">Scott Taylor</a>, <a href=\"http://profiles.wordpress.org/scribu\">scribu</a>, <a href=\"http://profiles.wordpress.org/scruffian\">scruffian</a>, <a href=\"http://profiles.wordpress.org/tenpura\">Seisuke Kuraishi (tenpura)</a>, <a href=\"http://profiles.wordpress.org/sergeybiryukov\">Sergey Biryukov</a>, <a href=\"http://profiles.wordpress.org/shinichin\">ShinichiN</a>, <a href=\"http://profiles.wordpress.org/pross\">Simon Prosser</a>, <a href=\"http://profiles.wordpress.org/simonwheatley\">Simon Wheatley</a>, <a href=\"http://profiles.wordpress.org/siobhan\">Siobhan</a>, <a href=\"http://profiles.wordpress.org/siobhyb\">Siobhan Bamber (siobhyb)</a>, <a href=\"http://profiles.wordpress.org/sirzooro\">sirzooro</a>, <a href=\"http://profiles.wordpress.org/solarissmoke\">solarissmoke</a>, <a href=\"http://profiles.wordpress.org/sillybean\">Stephanie Leary</a>, <a href=\"http://profiles.wordpress.org/netweb\">Stephen Edgar (@netweb)</a>, <a href=\"http://profiles.wordpress.org/stephenharris\">Stephen Harris</a>, <a href=\"http://profiles.wordpress.org/strangerstudios\">strangerstudios</a>, <a href=\"http://profiles.wordpress.org/sweetie089\">sweetie089</a>, <a href=\"http://profiles.wordpress.org/swissspidy\">swissspidy</a>, <a href=\"http://profiles.wordpress.org/miyauchi\">Takayuki Miyauchi</a>, <a href=\"http://profiles.wordpress.org/tmtoy\">Takuma Morikawa</a>, <a href=\"http://profiles.wordpress.org/tlovett1\">Taylor Lovett</a>, <a href=\"http://profiles.wordpress.org/tivnet\">tivnet</a>, <a href=\"http://profiles.wordpress.org/tobiasbg\">TobiasBg</a>, <a href=\"http://profiles.wordpress.org/tomauger\">Tom Auger</a>, <a href=\"http://profiles.wordpress.org/toscho\">toscho</a>, <a href=\"http://profiles.wordpress.org/wpsmith\">Travis Smith</a>, <a href=\"http://profiles.wordpress.org/sorich87\">Ulrich Sossou</a>, <a href=\"http://profiles.wordpress.org/vericgar\">vericgar</a>, <a href=\"http://profiles.wordpress.org/vinod-dalvi\">Vinod Dalvi</a>, <a href=\"http://profiles.wordpress.org/westonruter\">Weston Ruter</a>, <a href=\"http://profiles.wordpress.org/wikicms\">wikicms</a>, <a href=\"http://profiles.wordpress.org/willnorris\">Will Norris</a>, <a href=\"http://profiles.wordpress.org/wojtekszkutnik\">Wojtek Szkutnik</a>, <a href=\"http://profiles.wordpress.org/wycks\">wycks</a>, <a href=\"http://profiles.wordpress.org/yoavf\">Yoav Farhi</a>, and <a href=\"http://profiles.wordpress.org/yurivictor\">Yuri Victor</a>.</p>
<p>Enjoy what may be one of your last few manual updates. See you soon for version 3.8!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"http://wordpress.org/news/2013/10/basie/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"WordPress 3.7 Release Candidate 2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate-2/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 23 Oct 2013 00:05:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=2729\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:417:\"The second release candidate of WordPress 3.7 is now available for testing! Those of you already testing WordPress 3.7 will be updated automatically to RC2. (Nice.) If you&#8217;d like to start testing, there&#8217;s no time like the present! Try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”) or download the release candidate here (zip). Please post to the Alpha/Beta [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Andrew Nacin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1183:\"<p>The second release candidate of WordPress 3.7 is now available for testing!</p>
<p>Those of you already testing WordPress 3.7 will be updated automatically to RC2. (<em>Nice.</em>) If you&#8217;d like to start testing, there&#8217;s no time like the present! Try the <a href=\"http://wordpress.org/extend/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”) or <a href=\"http://wordpress.org/wordpress-3.7-RC2.zip\">download the release candidate here</a> (zip). Please post to the <a href=\"http://wordpress.org/support/forum/alphabeta/\">Alpha/Beta area in the support forums</a> if you think you&#8217;ve found a bug, and if any known issues are raised, you’ll be able to <a href=\"http://core.trac.wordpress.org/report/5\">find them here</a>.</p>
<p>Developers, please test your plugins and themes against WordPress 3.7. If there is a compatibility issue, let us know as soon as possible so we can deal with it before the final release.</p>
<p>For more on WordPress 3.7, check out the <a href=\"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate/\">announcement post for Release Candidate 1</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate-2/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Upcoming WordCamps\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"http://wordpress.org/news/2013/10/upcoming-wordcamps-4/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"http://wordpress.org/news/2013/10/upcoming-wordcamps-4/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 22 Oct 2013 19:25:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:9:\"Community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"WordCamp\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=2723\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:368:\"WordCamps are casual, locally-organized conferences that celebrate everything related to WordPress, and are a great opportunity to meet other WordPress users and professionals in your community. This has been a great year for WordCamps &#8212; there have been 56 so far in more than 20 countries, and there another 15 on the calendar before the year&#8217;s [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Jen Mylo\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3584:\"<p><a href=\"http://central.wordcamp.org/\">WordCamps</a> are casual, locally-organized conferences that celebrate everything related to WordPress, and are a great opportunity to meet other WordPress users and professionals in your community. This has been a great year for WordCamps &#8212; there have been 56 so far in more than 20 countries, and there another 15 on the calendar before the year&#8217;s over. If there&#8217;s one near you, check it out! In addition to getting to know your local WordPress community, most WordCamps attract some traveling visitors a well, giving you the chance to meet contributors to the WordPress open source project and <a href=\"http://make.wordpress.org/\">get involved</a> yourself.</p>
<p>Here are the WordCamps on the schedule for the rest of this year.</p>
<p>October 25-27: <strong><a href=\"http://2013.boston.wordcamp.org/\">WordCamp Boston</a></strong>, Boston, MA, USA<br />
October 25-26: <strong><a href=\"http://2013.malaga.wordcamp.org/\">WordCamp Malaga</a></strong>, Spain<br />
October 26: <strong><a href=\"http://2013.nepal.wordcamp.org/\">WordCamp Nepal</a></strong>, Kathmandu, Nepal<br />
October 26: <strong><a href=\"http://2013.sofia.wordcamp.org/\">WordCamp Sofia</a></strong>, Bulgaria<br />
November 7: <strong><a href=\"http://2013.capetown.wordcamp.org/\">WordCamp Cape Town</a></strong>, South Africa<br />
November 9: <strong><a href=\"http://2013.porto.wordcamp.org/\">WordCamp Porto</a></strong>, Portugal<br />
November 9-10: <strong><a href=\"http://2013.kenya.wordcamp.org/\">WordCamp Kenya</a></strong>, Nairobi, Kenya<br />
November 15: <strong><a href=\"http://2013.edmonton.wordcamp.org/\">WordCamp Edmonton</a></strong>, AB, Canada<br />
November 16-17: <strong><a href=\"http://2013.orlando.wordcamp.org/\">WordCamp Orlando</a></strong>, FL, USA<br />
November 16: <strong><a href=\"http://2013.denver.wordcamp.org/\">WordCamp Denver</a></strong>, CO, USA<br />
November 23-24: <strong><a href=\"http://2013.london.wordcamp.org/\">WordCamp London</a></strong>, UK<br />
November 23-24: <strong><a href=\"http://2013.raleigh.wordcamp.org/\">WordCamp Raleigh</a></strong>, NC, USA<br />
November 23: <strong><a href=\"http://2013.saopaulo.wordcamp.org/\">WordCamp São Paulo</a></strong>, Brazil<br />
December 14: <strong><a href=\"http://2013.vegas.wordcamp.org/\">WordCamp Las Vegas</a></strong>, NV, USA<br />
December 14-15: <strong><a href=\"http://2013.sevilla.wordcamp.org/\">WordCamp Sevilla</a></strong>, Spain</p>
<p>No WordCamps on this list in your area? Not to worry! There are thriving <a href=\"http://wordpress.meetup.com/\">WordPress meetups</a> all over the world where you can meet like-minded people, and we maintain a library of <a href=\"http://wordpress.tv/category/wordcamptv/\">WordCamp videos</a> at <a href=\"http://wordpress.tv/\">WordPress.tv</a>.</p>
<h3>Get Involved</h3>
<ul>
<li>If you&#8217;re interested in organizing a WordCamp in your area, check out our <a href=\"http://plan.wordcamp.org/\">WordCamp planning</a> site.</li>
<li>If you&#8217;re interested in <a href=\"http://make.wordpress.org/community/meetup-interest-form/\">starting a WordPress meetup</a> in your area, let us know and we can set up a group on meetup.com for you.</li>
<li>And speaking of WordCamp videos, we&#8217;ve recently enabled volunteer-generated subtitles/closed captioning of the videos on WordPress.tv to make them more accessible. Interested in helping? Check out the <a href=\"http://wordpress.tv/using-amara-org-to-caption-or-subtitle-a-wordpress-tv-video/\">WordPress.tv subtitling instructions</a>.</li>
</ul>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"http://wordpress.org/news/2013/10/upcoming-wordcamps-4/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"WordPress 3.7 Release Candidate\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 18 Oct 2013 19:52:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=2718\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:331:\"The first release candidate for WordPress 3.7 is now available! In RC 1, we&#8217;ve made some adjustments to the update process to make it more reliable than ever. We hope to ship WordPress 3.7 next week, but we need your help to get there. If you haven’t tested 3.7 yet, there’s no time like the present. (Please, [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Andrew Nacin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2274:\"<p>The first release candidate for WordPress 3.7 is now available!</p>
<p>In RC 1, we&#8217;ve made some adjustments to the update process to make it more reliable than ever. We hope to ship WordPress 3.7 <em>next week</em>, but we need your help to get there. If you haven’t tested 3.7 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.)</p>
<p>WordPress 3.7 introduces <strong>automatic background updates</strong> for security and minor releases (like updating from 3.7 to 3.7.1). These are really easy to test  — RC 1 will update every 12 hours or so to the latest development version, and then email you the results. (You may get two emails: one for debugging, and one all users of 3.7 will receive.) If something went wrong, you can report it.</p>
<p><strong>Think you’ve found a bug? </strong>Please post to the <a href=\"http://wordpress.org/support/forum/alphabeta/\">Alpha/Beta area in the support forums</a>. If any known issues come up, you’ll be able to <a href=\"http://core.trac.wordpress.org/report/5\">find them here</a>.</p>
<p>To test WordPress 3.7 RC1, try the <a href=\"http://wordpress.org/extend/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href=\"http://wordpress.org/wordpress-3.7-RC1.zip\">download the release candidate here</a> (zip). If you’d like to learn more about what&#8217;s new in WordPress 3.7, visit the awesome About screen in your dashboard (<strong><img alt=\"\" src=\"http://i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692\" data-recalc-dims=\"1\" /> → About</strong> in the toolbar). There, you can also see if your install is eligible for background updates. WordPress won’t automatically update, for example, if you’re using version control like Subversion or Git.</p>
<p><strong>Developers,</strong> please test your plugins and themes against WordPress 3.7, so that if there is a compatibility issue, we can figure it out before the final release. Make sure you post any issues to the support forums.</p>
<p><em>WordPress three seven</em><br />
<em>A self-updating engine</em><br />
<em>Lies beneath the hood</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 3.7 Beta 2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"http://wordpress.org/news/2013/10/wordpress-3-7-beta-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"http://wordpress.org/news/2013/10/wordpress-3-7-beta-2/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 10 Oct 2013 21:28:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=2706\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:357:\"WordPress 3.7 Beta 2 is now available for download and testing. This is software still in development, so we don&#8217;t recommend that you run it on a production site. This has been a quiet beta period. We&#8217;re hoping to get some more testers for automatic background updates, which will occur for security and minor releases (like updating [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Andrew Nacin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2108:\"<p>WordPress 3.7 Beta 2 is now available for download and testing. This is software still in development, so we don&#8217;t recommend that you run it on a production site.</p>
<p>This has been a quiet beta period. We&#8217;re hoping to get some more testers for <strong>automatic background updates</strong>, which will occur for security and minor releases (like updating from 3.7 to 3.7.1). It&#8217;s really easy to test this, as Beta 2 will update each day to the latest development version and then email you the results. If something goes wrong, you can report it — it&#8217;s that simple. To get the beta, try the <a href=\"http://wordpress.org/extend/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href=\"http://wordpress.org/wordpress-3.7-beta2.zip\">download the beta here</a> (zip). Check out <strong>Dashboard → Updates</strong> to see if your install is eligible for background updates. WordPress won&#8217;t update if, for example, you&#8217;re using version control like SVN or Git.</p>
<p>For more of what&#8217;s new in version 3.7, <a title=\"WordPress 3.7 Beta 1\" href=\"http://wordpress.org/news/2013/09/wordpress-3-7-beta-1/\">check out the Beta 1 blog post</a>. In Beta 2, we further increased the stability of background updates and also added about 50 bug fixes, including a fix for Internet Explorer 11 in the visual editor.</p>
<p>If you think you’ve found a bug, you can post to the <a href=\"http://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href=\"http://core.trac.wordpress.org/\">file one on the WordPress Trac</a>. There, you can also find <a href=\"http://core.trac.wordpress.org/report/5\">a list of known bugs</a> and <a href=\"http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.7\">everything we’ve fixed</a>.</p>
<p>Happy testing!</p>
<p><em>Beta 2 released<br />
Dotting i&#8217;s and crossing t&#8217;s</em><br />
<em>Expect RC next</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"http://wordpress.org/news/2013/10/wordpress-3-7-beta-2/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:31:\"http://wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"hourly\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Tue, 14 Jan 2014 14:35:33 GMT\";s:12:\"content-type\";s:23:\"text/xml; charset=UTF-8\";s:10:\"connection\";s:5:\"close\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:10:\"x-pingback\";s:36:\"http://wordpress.org/news/xmlrpc.php\";s:13:\"last-modified\";s:29:\"Fri, 20 Dec 2013 08:24:58 GMT\";s:4:\"x-nc\";s:11:\"HIT lax 249\";}s:5:\"build\";s:14:\"20140110102336\";}","no");
INSERT INTO `wp_options` VALUES("113","can_compress_scripts","0","yes");
INSERT INTO `wp_options` VALUES("115","_transient_twentyfourteen_category_count","1","yes");
INSERT INTO `wp_options` VALUES("511","_transient_timeout_feed_mod_867bd5c64f85878d03a060509cd2f92c","1389753333","no");
INSERT INTO `wp_options` VALUES("512","_transient_feed_mod_867bd5c64f85878d03a060509cd2f92c","1389710133","no");
INSERT INTO `wp_options` VALUES("509","_transient_timeout_feed_867bd5c64f85878d03a060509cd2f92c","1389753333","no");
INSERT INTO `wp_options` VALUES("510","_transient_feed_867bd5c64f85878d03a060509cd2f92c","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:61:\"
	
	
	
	




















































\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"WordPress Planet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"en\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WordPress Planet - http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:50:{i:0;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"WPTavern: WP Updates Settings: An Admin UI For Configuring WordPress Updates\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=14562\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:194:\"http://wptavern.com/wp-updates-settings-an-admin-ui-for-configuring-wordpress-updates?utm_source=rss&utm_medium=rss&utm_campaign=wp-updates-settings-an-admin-ui-for-configuring-wordpress-updates\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2977:\"<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/updates.png\" rel=\"prettyphoto[14562]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/updates.png\" alt=\"updates\" width=\"800\" height=\"259\" class=\"aligncenter size-full wp-image-14565\" /></a></p>
<p>One of the most exciting features in <a href=\"http://wptavern.com/wordpress-3-7-released-wordpress-now-updates-itself\" target=\"_blank\">WordPress 3.7</a> was the ability for WordPress to stay up to date through automatic background updates. However, WordPress provides no easy way to change your update settings in the admin. Update settings require <a href=\"http://wptavern.com/how-to-configure-automatic-core-updates-for-wordpress-3-7\" target=\"_blank\">manual configuration</a> in your <em>wp-config.php</em> file.</p>
<p><a href=\"http://wordpress.org/plugins/wp-updates-settings/\" target=\"_blank\">WP Updates Settings</a> is a new plugin released today, just in time for users to experiment using it with the upcoming WordPress 3.8.1 release. It provides a user interface for configuring update settings within the WordPress admin at <strong>Settings >> Updates</strong>.</p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/update-settings.png\" rel=\"prettyphoto[14562]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/update-settings.png\" alt=\"update-settings\" width=\"790\" height=\"625\" class=\"aligncenter size-full wp-image-14569\" /></a></p>
<p>The WP Updates Settings plugin includes a comprehensive list of update options, including translation files, as well as a few other extras such as contextual help:</p>
<ul>
<li>Show/hide Updates notification</li>
<li>Use default WordPress behaviors</li>
<li>Enable/Disable Updates capabilities to Administrator users</li>
<li>Set Major Core Automatic Background Updates</li>
<li>Set Minor Core Automatic Background Updates</li>
<li>Set Plugin Automatic Background Updates</li>
<li>Set Theme Automatic Background Updates</li>
<li>Set Translation files Automatic Background Updates</li>
<li>Contextual Help</li>
<li>Translation MO/PO files</li>
<li>Clean uninstall</li>
</ul>
<p>This plugin provides a good option for WordPress users who want to change some extra settings, such as adding in automatic theme updates, but are intimidated by editing the <em>wp-config.php</em> file. </p>
<p>If you try the plugin for awhile but want to uninstall it later, the default update settings are restored (core updates for minor versions). I&#8217;ve got it installed on a WordPress site to fully test whether my update settings are correctly recorded and implemented when WordPress 3.8.1 is released.  I&#8217;ll report back here when it is complete. </p>
<p><a href=\"http://wordpress.org/plugins/wp-updates-settings/\" target=\"_blank\">WP Updates Settings</a> is the first plugin to provide a comprehensive UI for the most common selections users would otherwise define in <em>wp-config.php</em>. Download it for free from the WordPress plugin repository.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 14 Jan 2014 00:00:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"WPTavern: Rant On WordPress Photography Themes Raises Concerns For Consumers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=14542\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:196:\"http://wptavern.com/rant-on-wordpress-photography-themes-raises-concerns-for-consumers?utm_source=rss&utm_medium=rss&utm_campaign=rant-on-wordpress-photography-themes-raises-concerns-for-consumers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4509:\"<p>Peter Adams who runs the site <a title=\"http://wpphotog.com\" href=\"http://wpphotog.com\">WP Photog</a> has published a <a title=\"http://wpphotog.com/the-ugly-side-of-wordpress-themes-for-photographers/\" href=\"http://wpphotog.com/the-ugly-side-of-wordpress-themes-for-photographers/\">rant against Photography based WordPress themes</a> that is filled with interesting things to consider, especially for consumers. The rant covers a lot of familiar territory such as themes using Custom Post Types instead of built-in functionality, using plugins for functionality instead of building it into the theme and finally, bypassing the gallery shortcode generated by the core of WordPress.</p>
<blockquote><p>There are a lot of reasons that these photography oriented Themes are so messed up. I could point to the fact that many Theme designers are web designers and not software engineers or to the fact that the incentive of premium theme designers is to lure buyers in with a good demo and not low long-term ownership costs. Or maybe it’s just ignorance on the part of Theme designers as to how WordPress really works and what the trade-offs really are.</p>
<p>However, what I think is really going on here is that many of the proprietary workarounds found in these themes are trying to make up for the usability issues that new users face when starting out with WordPress</p></blockquote>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/KISS.jpg\" rel=\"prettyphoto[14542]\"><img class=\"aligncenter size-large wp-image-14545\" alt=\"Keep In Simple Stupid Featured Image\" src=\"http://wptavern.com/wp-content/uploads/2014/01/KISS-500x156.jpg\" width=\"500\" height=\"156\" /></a></p>
<p>Peter says something in his post that I wish all theme designers/developers would get back to doing. &#8220;<em><strong>Keep Theme code dedicated to design and layout – not proprietary functionality.</strong>&#8220;</em> Many of the complaints against Photography specific themes are similar to the complaints Justin Tadlock mentioned in his <a title=\"http://wptavern.com/justin-tadlock-publishes-the-results-of-his-themeforest-experiment\" href=\"http://wptavern.com/justin-tadlock-publishes-the-results-of-his-themeforest-experiment\">ThemeForest experiment</a>.</p>
<blockquote><p>From a consumer standpoint, Justin’s experiment proves how important it is to pick the right theme that won’t lock you in. I can’t imagine the common user knowing about shortcodes, post types, etc and factoring those into their decision on which theme to buy. As has been the case for a long time, choosing themes is like walking down the street looking at each storefront window to see which one looks best. Between all these dependencies with shortcodes, etc. someone could really screw themselves by investing time and money into a theme that does everything wrong.</p></blockquote>
<p>I feel like WordPress themes have gone through a giant cycle. A few years ago, themes contained awesome features that manipulated the display of content. Features that could have existed as plugins but were built into themes. Now we&#8217;re on the other side of the cycle where there is demand for theme developers to get rid of all the extra fat found within themes and to get back to the basics of the <strong>KISS</strong> principle (Keep It Simple, Stupid). While progressing through the cycle the WordPress theme ecosystem has become filled with themes that make a consumers life a living nightmare.</p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/ThemeReviewGuidelines.jpg\" rel=\"prettyphoto[14542]\"><img class=\"aligncenter size-large wp-image-14544\" alt=\"Theme Review Guidelines\" src=\"http://wptavern.com/wp-content/uploads/2014/01/ThemeReviewGuidelines-500x394.jpg\" width=\"500\" height=\"394\" /></a></p>
<p>Justin Tadlock is doing his part to change things for the better. He <a title=\"http://wptavern.com/justin-tadlock-joins-the-wordpress-theme-review-team\" href=\"http://wptavern.com/justin-tadlock-joins-the-wordpress-theme-review-team\">joined the WordPress Theme Review team</a> and is working with other members of the community to help straighten things out. But themes hosted on WordPress.org are just a tiny drop in the bucket compared to the commercial theme market, which doesn’t always follow the same theme guidelines. The WordPress theme world has dug themselves a deep hole that they might not be able to get out of. The unfortunate aspect in all of this is that consumers are the ones who lose the most.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 13 Jan 2014 20:43:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"Jeffro\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"WPTavern: Matt Mullenweg Takes On New Role As CEO of Automattic\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=14524\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:170:\"http://wptavern.com/matt-mullenweg-takes-on-new-role-as-ceo-of-automattic?utm_source=rss&utm_medium=rss&utm_campaign=matt-mullenweg-takes-on-new-role-as-ceo-of-automattic\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2482:\"<div id=\"attachment_14529\" class=\"wp-caption aligncenter\"><a href=\"http://wptavern.com/wp-content/uploads/2014/01/leweb.jpg\" rel=\"prettyphoto[14524]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/leweb.jpg\" alt=\"photo credit: LeWeb 2010 \" width=\"849\" height=\"413\" class=\"size-full wp-image-14529\" /></a><p class=\"wp-caption-text\">photo credit: <a href=\"http://www.youtube.com/watch?v=LTaqQozpbXs\">LeWeb 2010</a></p></div>
<p>After celebrating his <a href=\"http://ma.tt/2014/01/matt-3-0/\" target=\"_blank\">30th birthday</a> this weekend, Matt Mullenweg announced that he has accepted a new role as CEO of <a href=\"http://automattic.com/\" title=\"Automattic\" target=\"_blank\">Automattic</a>. </p>
<p>Toni Schneider joined Automattic as CEO eight years ago in January 2006 and has helped to expand Automattic&#8217;s reach to close to a billion people each month. But Schneider <a href=\"http://toni.org/2014/01/13/a-new-ceo-for-automattic/\" target=\"_blank\">isn&#8217;t saying goodbye</a>. He&#8217;s swapping roles with Matt who will now become the new CEO, as Matt announced in his <a href=\"http://ma.tt/2014/01/toni-automattic-ceo/\" target=\"_blank\">post</a> this morning:</p>
<blockquote><p>Today we’re announcing publicly that Toni and I are switching jobs — he’s going to focus on some of Automattic’s new products, and I’m going to take on the role of CEO. Internally this isn’t a big change as our roles have always been quite fluid</p></blockquote>
<p>I asked Matt if the new role would change his relationship and involvement with WordPress.org, but it turns out that it won&#8217;t bring too big of a change to his day-to-day. He replied, <strong>&#8220;No major changes planned, as things are working very well already.&#8221;</strong>  The business of Automattic, which was started to help make WordPress simple to setup and host, is entirely separate from the open source project. Its growth has mirrored the success of the open source software, with WordPress currently powering <a href=\"http://w3techs.com/technologies/history_overview/content_management/all/y\" target=\"_blank\">21.2% of the web</a>. </p>
<p>Congrats to both Matt Mullenweg and Toni Schneider on their new positions in Automattic. With their flagship product WordPress.com now <a href=\"http://wptavern.com/wordpress-com-is-ranked-8-for-internet-traffic-in-the-us\" target=\"_blank\">ranked 8th for traffic in the US</a>, I&#8217;d say the two are working together quite successfully. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 13 Jan 2014 18:33:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"Matt: Toni Schneider &amp; Automattic CEO\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=43446\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"http://ma.tt/2014/01/toni-automattic-ceo/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2101:\"<p><a href=\"http://ma.tt/2006/01/automattic-toni/\">Eight years and one day ago I blogged about Toni Schneider joining Automattic as CEO</a>, as I said then:</p>
<blockquote><p>I first met Toni shortly after I moved to San Francisco and I&#8217;ve wanted him to be a part of Automattic pretty much since the idea first entered my mind. We&#8217;ve spent many long meals over the past year discussing the Automattic idea before it even had a name. I&#8217;ve been on cloud nine since (somehow) I convinced him to leave the incredibly cushy corporate job and rough it out in startup world again. I&#8217;m very very excited about some of the things coming down the line.</p></blockquote>
<p>Fast-forward roughly two thousand, nine hundred, and twenty-two days and I&#8217;m still on cloud nine and love working together with Toni. We have been through some incredible ups and downs in people, valuation, been on both sides of the table for acquisitions, and seen dozens of competitors come, go, and come again as the hyperactive tech news cycle loops back around.</p>
<p>Today we&#8217;re announcing publicly that Toni and I are switching jobs &#8212; he&#8217;s going to focus on some of Automattic&#8217;s new products, and I&#8217;m going to take on the role of CEO.  Internally this isn&#8217;t a big change as our roles have always been quite fluid, and I&#8217;ve had some recent practice filling in for him for a few months last year when he was on sabbatical. I&#8217;ve learned a tremendous amount from Toni over the years and I&#8217;m looking forward to putting that into practice.</p>
<p>Besides, it&#8217;s obvious that no one in their twenties should run a company. They think they know everything, a fact I can now say with complete confidence now that <a href=\"http://ma.tt/2014/01/matt-3-0/\">I&#8217;m 30 and two days old</a>.</p>
<p>See also: <a href=\"http://toni.org/2014/01/13/a-new-ceo-for-automattic/\">Toni Scheider&#8217;s post</a>, <a href=\"http://om.co/2014/01/13/toni-matt/\">Om Malik</a>, <a href=\"http://tonyconrad.wordpress.com/2014/01/13/future-forward/\">Tony Conrad</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 13 Jan 2014 16:59:49 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"WPTavern: WordCamp Miami Adds BuddyCamp to 2014 Event\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=14486\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:150:\"http://wptavern.com/wordcamp-miami-adds-buddycamp-to-2014-event?utm_source=rss&utm_medium=rss&utm_campaign=wordcamp-miami-adds-buddycamp-to-2014-event\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2208:\"<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/buddycamp-miami.jpg\" rel=\"prettyphoto[14486]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/buddycamp-miami.jpg\" alt=\"buddycamp-miami\" width=\"1000\" height=\"288\" class=\"aligncenter size-full wp-image-14491\" /></a></p>
<p>Over the weekend, WordCamp Miami <a href=\"http://2014.miami.wordcamp.org/wordcamp-miami-date-change-may-9-11-2014/\" target=\"_blank\">announced a date change</a> for the <a href=\"http://wptavern.com/wordcamp-miami-to-celebrate-5th-anniversary-in-may-2014\" target=\"_blank\">5th anniversary event</a>. It&#8217;s now pushed up to to May 9-11, 2014. BuddyPress designers, developers and enthusiasts will be pleased to know that the organizers of the event have also given the green light to host another <a href=\"http://2014.miami.wordcamp.org/announcing-buddycamp-miami-2014/\">BuddyCamp Miami</a>.</p>
<p>This is the second BuddyCamp that Miami has hosted. The event will be a mini-conference and will focus on both BuddyPress and bbPress topics. The organizers plan to have beginner sessions alongside designer / developer presentations. This event will be an excellent opportunity for anyone who builds or manages BuddyPress sites to learn from others and network with other BuddyPress fans from around the world.  </p>
<h4>BuddyCamp Miami Dates and Speaker Submissions</h4>
<p>Applications are now open for BuddyCamp speakers. The BuddyCamp Miami planning team will be accepting <a href=\"http://2014.miami.wordcamp.org/speakers/speaker-submissions/\" target=\"_blank\">speaker submissions</a> until February 3, 2014, which is the same deadline for the WordCamp presentations.</p>
<p>The dates for BuddyCamp Miami have not yet been set in stone but the conference will be held within WordCamp Miami. May 9th or May 11th are the dates in consideration. If you&#8217;re thinking about going, follow <a href=\"https://twitter.com/wordcampmiami\" target=\"_blank\">@wordcampmiami</a> and <a href=\"https://twitter.com/buddycampmia\">@buddycampmia</a> for up-to-the-minute details and announcements. The organizers anticipate 600 – 700 attendees. This event has sold out every single time, so make sure to buy your tickets early.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 13 Jan 2014 13:40:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt: Matt 3.0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=43438\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"http://ma.tt/2014/01/matt-3-0/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2433:\"<p>As in WordPress, the X.0 release is just the one that came after (X-1).9 before it, so while it seems more significant, it’s just another iteration in the steady march of progress, a job never done. I&#8217;ve now managed to stay alive for three decades, thirty rotations around the sun, and I woke up this morning a little hungover (there’s a lot of tequila in Mexico) but with a huge grin on my face.</p>
<p>In many ways life accumulates complexity as you get older, but the things that are most important are simple and universal: friends and loved ones, health, and working on something you enjoy and has an impact. I&#8217;m happier and finding balance more often than at any period I can remember since I was a young child.</p>
<p>This was another year in motion, traveling 345,211 miles to 78 cities in 13 countries. I&#8217;m still really enjoying being on the road, and it’s very intrinsic to how Automattic works, so I expect that to continue or even pick up pace.</p>
<p>Every generation feels this way, but it also genuinely seems like we’re at shift in how society works, with technology accelerating change, and navigating and more importantly creating that change is one of the most interesting challenges I can imagine working on. </p>
<p>Finally I’m humbled and amazed by <a href=\"http://my.charitywater.org/matt-30\">the support for the charity: water campaign</a>, which already is going to bring close to 2,000 people clean water.</p>
<p>Tomorrow I’ll wake up a little sunburnt, but hopefully with that same grin and ready to take on the years of my life that start with 3 and hopefully end with a bigger impact than my 20s had. It was a decade when I failed a lot, tried even more, and most importantly learned how to say yes and how to say no, something that gets easier as you learn about yourself.</p>
<p>My twenties: <a href=\"http://ma.tt/2003/01/bday/\">19</a>, <a href=\"http://ma.tt/2004/01/so-im-20/\">20</a>, <a href=\"http://ma.tt/2005/01/hot-barely-legal-matt/\">21</a>, <a href=\"http://ma.tt/2006/01/matt-22/\">22</a>, <a href=\"http://ma.tt/2007/01/twenty-three/\">23</a>, <a href=\"http://ma.tt/2008/01/twenty-four/\">24</a>, <a href=\"http://ma.tt/2009/01/twenty-five/\">25</a>, <a href=\"http://ma.tt/2010/01/twenty-six/\">26</a>, <a href=\"http://ma.tt/2011/01/twenty-seven/\">27</a>, <a href=\"http://ma.tt/2012/01/twenty-eight/\">28</a>, and <a href=\"http://ma.tt/2013/01/twenty-nine/\">29</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 12 Jan 2014 01:46:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"WordPress.tv: Richard Martin: How Video Can Boost Your Traffic\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wordpress.tv/?p=29139\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"http://wordpress.tv/2014/01/11/richard-martin-how-video-can-boost-your-traffic/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:673:\"<div id=\"v-KU4sfPVI-1\" class=\"video-player\">
</div><br />  <a rel=\"nofollow\" href=\"http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/29139/\"><img alt=\"\" border=\"0\" src=\"http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/29139/\" /></a> <img alt=\"\" border=\"0\" src=\"http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=29139&subd=wptv&ref=&feed=1\" width=\"1\" height=\"1\" /><div><a href=\"http://wordpress.tv/2014/01/11/richard-martin-how-video-can-boost-your-traffic/\"><img alt=\"Richard Martin: How Video Can Boost Your Traffic\" src=\"http://videos.videopress.com/KU4sfPVI/video-1c2a356d38_std.original.jpg\" width=\"160\" height=\"120\" /></a></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 11 Jan 2014 20:56:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"WordPress.tv\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"WordPress.tv: Becky Davis: You Can Make A Living With WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wordpress.tv/?p=29401\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"http://wordpress.tv/2014/01/11/becky-davis-you-can-make-a-living-with-wordpress/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:675:\"<div id=\"v-cf7jcWP2-1\" class=\"video-player\">
</div><br />  <a rel=\"nofollow\" href=\"http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/29401/\"><img alt=\"\" border=\"0\" src=\"http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/29401/\" /></a> <img alt=\"\" border=\"0\" src=\"http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=29401&subd=wptv&ref=&feed=1\" width=\"1\" height=\"1\" /><div><a href=\"http://wordpress.tv/2014/01/11/becky-davis-you-can-make-a-living-with-wordpress/\"><img alt=\"Becky Davis: You Can Make A Living With WordPress\" src=\"http://videos.videopress.com/cf7jcWP2/video-868202f2cd_std.original.jpg\" width=\"160\" height=\"120\" /></a></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 11 Jan 2014 17:14:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"WordPress.tv\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"WPTavern: WPWeekly Episode 133 – Does Your Plugin Suck?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"http://wptavern.com?p=14474&preview_id=14474\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:148:\"http://wptavern.com/wpweekly-episode-133-does-your-plugin-suck?utm_source=rss&utm_medium=rss&utm_campaign=wpweekly-episode-133-does-your-plugin-suck\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3789:\"<p><a href=\"http://www.wptavern.com/wp-content/uploads/2013/08/WordPressWeekly_albumart2.jpg\" rel=\"prettyphoto[14474]\"><img src=\"http://www.wptavern.com/wp-content/uploads/2013/08/WordPressWeekly_albumart2-150x150.jpg\" alt=\"WordPress Weekly Cover Art\" width=\"150\" height=\"150\" class=\"alignright size-thumbnail wp-image-8715\" /></a> All three <a href=\"http://wptavern.com/contributors\" title=\"http://wptavern.com/contributors\">contributing writers</a> to WPTavern were able to be part of the first episode of WordPress Weekly for 2014. In this episode, we get you caught up on the headlines and give you our New Years resolutions. We had a great conversation about the launch of AppPresser and the Aesop story engine. Near the end of the show, <a href=\"http://marcuscouch.com/\" title=\"http://marcuscouch.com/\">Marcus Couch</a> shared three new plugins from the repository that caught his eye.  <span id=\"more-14474\"></span></p>
<h2>Stories Discussed:</h2>
<p><a href=\"http://wptavern.com/aesop-story-engine-an-open-source-wordpress-plugin-for-storytelling\" title=\"http://wptavern.com/aesop-story-engine-an-open-source-wordpress-plugin-for-storytelling\">Aesop Story Engine: An Open Source WordPress Plugin For Storytelling</a><br />
<a href=\"http://wptavern.com/mentor-others-in-the-wordpress-community-with-wpmentor\" title=\"http://wptavern.com/mentor-others-in-the-wordpress-community-with-wpmentor\">Mentor Others In The WordPress Community With WPMentor</a><br />
<a href=\"http://wptavern.com/wordpress-core-trac-gets-a-design-refresh-new-features-and-enhancements\" title=\"http://wptavern.com/wordpress-core-trac-gets-a-design-refresh-new-features-and-enhancements\">WordPress Core Trac Gets a Design Refresh, New Features and Enhancements</a><br />
<a href=\"http://wptavern.com/apppresser-launches-first-mobile-app-development-framework-for-wordpress\" title=\"http://wptavern.com/apppresser-launches-first-mobile-app-development-framework-for-wordpress\">AppPresser Launches First Mobile App Development Framework For WordPress</a><br />
<a href=\"http://wptavern.com/help-shape-buddypress-development-in-2014\" title=\"http://wptavern.com/help-shape-buddypress-development-in-2014\">Help Shape BuddyPress Development in 2014</a><br />
<a href=\"http://wptavern.com/industry-night-5-david-cramer-my-shortcodes-and-caldera-engine\" title=\"http://wptavern.com/industry-night-5-david-cramer-my-shortcodes-and-caldera-engine\">Industry Night #5 – David Cramer, My Shortcodes and Caldera Engine</a></p>
<h2>Plugins Mentioned By Marcus Couch:</h2>
<p><a href=\"http://wordpress.org/plugins/magic-liquidizer-responsive-table/\" title=\"http://wordpress.org/plugins/magic-liquidizer-responsive-table/\">Magic Liquidizer Responsive Table</a><br />
<a href=\"http://wordpress.org/plugins/read-and-understood/\" title=\"http://wordpress.org/plugins/read-and-understood/\">Read and Understood</a><br />
<a href=\"http://wordpress.org/plugins/plugin-organizer/\" title=\"http://wordpress.org/plugins/plugin-organizer/\">Plugin Organizer</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Friday, January 17th 3 P.M. Eastern &#8211; Special Guest <a href=\"http://www.davidbisset.com/\" title=\"http://www.davidbisset.com/\">David Bisset</a></p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href=\"http://www.wptavern.com/feed/podcast\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Listen To Episode #133:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 11 Jan 2014 04:14:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"Jeffro\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"WPTavern: ManageWP Is Now Integrated Into cPanel With SiteGround Hosting\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=14423\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:188:\"http://wptavern.com/managewp-is-now-integrated-into-cpanel-with-siteground-hosting?utm_source=rss&utm_medium=rss&utm_campaign=managewp-is-now-integrated-into-cpanel-with-siteground-hosting\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3814:\"<p>ManageWP <a href=\"https://managewp.com/hosting-partnership-programme\" target=\"_blank\">announced</a> today that it has made its way into cPanel on sites hosted with SiteGround via their new hosting partnership program. <a href=\"http://www.siteground.com/\" target=\"_blank\">SiteGround</a> customers will now find a ManageWP button within cPanel, which includes one click ManageWP account activation and also allows users to automatically add existing websites to the management dashboard.</p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/ManageWP_cPanel.png\" rel=\"prettyphoto[14423]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/ManageWP_cPanel.png\" alt=\"ManageWP_cPanel\" width=\"626\" height=\"305\" class=\"aligncenter size-full wp-image-14433\" /></a></p>
<p>I had the chance to chat briefly with <a href=\"http://profiles.wordpress.org/freediver/\" target=\"_blank\">Vladimir Prelovac</a>, the founder of ManageWP, to find out more about the new account provisioning API that powers the hosting partnership. <strong>&#8220;We created this API with hosting partners in mind,&#8221;</strong> he said. The development team then built a cPanel plugin on top of the API so hosting companies can easily plug ManageWP functionality into their hosting offers. </p>
<p>Tina Kesova, SiteGround&#8217;s business development strategist, said that ManageWP services have significantly improved SiteGround customer satisfaction: &#8220;The great amount of signups and extremely fast adoption of ManageWP by our customers proves that it is a great solution for our clients&#8217; needs and adds great value to our service offering.&#8221; </p>
<h3>Partnering with Hosts</h3>
<p>Partnering with hosting companies is nothing new when it comes to integrating both free and commercial WordPress products. <a href=\"http://wp-cli.org/\" target=\"_blank\">WP-CLI</a>, the WordPress command line interface, comes <a href=\"http://wptavern.com/hosting-companies-that-have-wp-cli-pre-installed\" target=\"_blank\">pre-installed</a> on many major hosting providers. Hosts also commonly integrate and/or recommend caching solutions, staging, GIT version control, as well as WordPress auto-installers.</p>
<p>Prelovac said they are targeting more hosts for integration with ManageWP. &#8220;At this moment, we are looking for hosting companies that have great reputation as WordPress hosts. Of course we also have a lot of plans, including very close integration with hosting products and perhaps being a part of the ultimate WordPress hosting product in the near future,&#8221; he said. Though he would not offer more specifics, Prelovac anticipates the that more hosts will begin to see the value of integrating WordPress-related products. He predicts, &#8220;Given the popularity of WordPress, I expect that in the future ManageWP will become a standard on hosting panels similar to how CloudFlare is now, so that people who can really benefit from using our solution can do so more easily.&#8221;</p>
<p>According to <a href=\"http://w3techs.com/technologies/history_overview/content_management/all/y\" target=\"_blank\">W3techs</a>, <strong>WordPress currently powers 21.2% of the web</strong>. It&#8217;s a prudent move on the part of hosting companies to try to attract more WordPress users by adding WordPress-related tools to their control panels. </p>
<p>With ManageWP successfully working its way into cPanels across SiteGround servers, do you think we&#8217;ll see more commercial WordPress products seeking hosting partnerships? This seems like a smart thing to do, especially if you offer WordPress backup services or anything related to migration and staging. If a host doesn&#8217;t already include generic options for these products and services, this is one easy way for the company to extend its capabilities. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 10 Jan 2014 22:22:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"WordPress.tv: Christopher Cochran: 320, 480, 640, 720, 768, 960, 1024… NO\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wordpress.tv/?p=28215\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"http://wordpress.tv/2014/01/10/christopher-cochran-320-480-640-720-768-960-1024-no/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:690:\"<div id=\"v-CCT2iYAF-1\" class=\"video-player\">
</div><br />  <a rel=\"nofollow\" href=\"http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/28215/\"><img alt=\"\" border=\"0\" src=\"http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/28215/\" /></a> <img alt=\"\" border=\"0\" src=\"http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=28215&subd=wptv&ref=&feed=1\" width=\"1\" height=\"1\" /><div><a href=\"http://wordpress.tv/2014/01/10/christopher-cochran-320-480-640-720-768-960-1024-no/\"><img alt=\"Christopher Cochran: 320, 480, 640, 720, 768, 960, 1024… NO\" src=\"http://videos.videopress.com/CCT2iYAF/video-c3d551940b_std.original.jpg\" width=\"160\" height=\"120\" /></a></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 10 Jan 2014 20:51:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"WordPress.tv\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"WordPress.tv: Ben Lobaugh: Interacting With External APIs\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wordpress.tv/?p=26703\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"http://wordpress.tv/2014/01/10/ben-lobaugh-interacting-with-external-apis-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:671:\"<div id=\"v-PfNuDAR1-1\" class=\"video-player\">
</div><br />  <a rel=\"nofollow\" href=\"http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/26703/\"><img alt=\"\" border=\"0\" src=\"http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/26703/\" /></a> <img alt=\"\" border=\"0\" src=\"http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=26703&subd=wptv&ref=&feed=1\" width=\"1\" height=\"1\" /><div><a href=\"http://wordpress.tv/2014/01/10/ben-lobaugh-interacting-with-external-apis-2/\"><img alt=\"Ben Lobaugh: Interacting With External APIs\" src=\"http://videos.videopress.com/PfNuDAR1/video-6c97821093_scruberthumbnail_0.jpg\" width=\"160\" height=\"120\" /></a></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 10 Jan 2014 20:42:03 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"WordPress.tv\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:38:\"Alex King: Interviewed on WP Elevation\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://alexking.org/?p=19206\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"http://alexking.org/blog/2014/01/10/interviewed-on-wp-elevation\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:888:\"<p><a href=\"http://www.wpelevation.com/2014/01/episode-15-alex-king/\">I did an interview with Troy Dean</a> for <a href=\"http://www.wpelevation.com/\">WP Elevation</a> which is now available. I talk quite a bit about my history with WordPress and my approaches to various things including my work experience, my team, working with clients, and the merger with VeloMedia. </p>
<p>This is the first time I&#8217;ve done an interview like this over video, I think it worked really well &#8211; both to allow Troy and I to have better rapport and to let you see facial expressions, etc. during the conversation. My thanks to Troy for having me on and asking great questions; I had a great time.</p>
<p></p>
<p>You can also <a href=\"http://media.blubrry.com/wp_elevation/p/wpe-podcast.s3.amazonaws.com/WPElevation-AlexKing.mp3\">download the MP3</a> if you&#8217;re more of a podcast person.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 10 Jan 2014 16:29:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Alex\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"WPTavern: Ridizain: A Free WordPress Magazine Theme Inspired By Twenty Fourteen\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=14397\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:200:\"http://wptavern.com/ridizain-a-free-wordpress-magazine-theme-inspired-by-twenty-fourteen?utm_source=rss&utm_medium=rss&utm_campaign=ridizain-a-free-wordpress-magazine-theme-inspired-by-twenty-fourteen\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2053:\"<p><a href=\"http://wordpress.org/themes/ridizain\" target=\"_blank\">Ridizain</a> is a free WordPress magazine theme, heavily inspired by the new Twenty Fourteen default theme. <a href=\"http://profiles.wordpress.org/ZGani/\" target=\"_blank\">Zulfikar Nore</a> released it just before Christmas, adding to his library of 17 themes in the official WordPress.org directory.</p>
<p>It&#8217;s important to note that Ridizain is not a child theme of <a href=\"http://wordpress.org/themes/twentyfourteen\" target=\"_blank\">Twenty Fourteen</a>. Rather, it&#8217;s an adaptation or re-design of it, as the name suggests, with two important design distinctions: Ridizain is full width and centered. These major differences answer a couple of the most common complaints about Twenty Fourteen. </p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/ridizain.jpg\" rel=\"prettyphoto[14397]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/ridizain.jpg\" alt=\"ridizain\" width=\"880\" height=\"660\" class=\"aligncenter size-full wp-image-14399\" /></a></p>
<p>Check out the <a href=\"http://www.wpstrapcode.com/ridizain/\" target=\"_blank\">Ridizain demo</a> and compare to the <a href=\"http://twentyfourteendemo.wordpress.com/\" target=\"_blank\">Twenty Fourteen demo</a> to spot the differences between the two themes.</p>
<p>Ridizain is built with the same template structure as Twenty Fourteen and maintains all of its other features, including featured homepage content, three widget areas, custom recent posts and full color control for many of the theme&#8217;s elements.</p>
<p>Hopefully, the developer will incorporate any major changes added to Twenty Fourteen in the future. If this is a concern for you, it might be better to simply create a child theme of Twenty Fourteen with the CSS changes included. This is a theme worth looking at if you&#8217;re a fan of Twenty Fourteen and want a quick way to get it centered and full width. You can download <a href=\"http://wordpress.org/themes/ridizain\" target=\"_blank\">Ridizain</a> for free from WordPress.org. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 10 Jan 2014 15:33:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"WPTavern: Hosting Companies That Have WP-CLI Pre-Installed\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=14376\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:160:\"http://wptavern.com/hosting-companies-that-have-wp-cli-pre-installed?utm_source=rss&utm_medium=rss&utm_campaign=hosting-companies-that-have-wp-cli-pre-installed\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2881:\"<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/wp-cli.jpg\" rel=\"prettyphoto[14376]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/wp-cli.jpg\" alt=\"wp-cli\" width=\"800\" height=\"271\" class=\"aligncenter size-full wp-image-14390\" /></a><br />
<a href=\"http://wp-cli.org/\" target=\"_blank\">WP-CLI</a> was one of the most exciting WordPress tools to be released a couple of years ago in <a href=\"http://scribu.net/wordpress/a-command-line-interface-for-wordpress.html\" target=\"_blank\">2011</a> and has quickly become an indispensable part of many developers&#8217; workflow. The project was originally created by <a href=\"https://github.com/andreascreten\" target=\"_blank\">Andreas Creten</a> and is now maintained by <a href=\"https://github.com/scribu\" target=\"_blank\">Cristi Burcă</a> (Scribu) and other <a href=\"https://github.com/wp-cli?tab=members\" target=\"_blank\">contributors</a>. </p>
<p>WP-CLI provides a command line interface for managing WordPress sites without having to use the admin screens. It makes many routine development tasks faster and easier, including updating the core and plugins, installing themes, backing up your database, managing user roles and so much more. A full list of <a href=\"http://wp-cli.org/commands/\" target=\"_blank\">commands</a> is available on the project site and a list of <a href=\"https://github.com/wp-cli/wp-cli/wiki/List-of-community-commands\" target=\"_blank\">community commands</a> is posted to github.</p>
<h4>A List of Hosts With WP-CLI Pre-Installed</h4>
<p>The project recently updated its github wiki to include a <a href=\"https://github.com/wp-cli/wp-cli/wiki/List-of-hosting-companies\" target=\"_blank\">list of hosting companies</a> that support WP-CLI. This list includes hosts that have WP-CLI installed by default for their customers when they first SSH into their servers, meaning that the <code>wp</code> command is already available. Of course, you can always install it at any host where you have SSH access, but this list includes companies that have it pre-installed:</p>
<ul>
<li>Bluehost</li>
<li>Dreamhost</li>
<li>Synthesis</li>
<li>SiteGround</li>
<li>WordPress.com VIP</li>
</ul>
<p>Several of these hosts have additional resources to help you get started. Dreamhost has a <a href=\"http://wiki.dreamhost.com/WordPress_wp-cli\" target=\"_blank\">wiki for using WP-CLI</a> and SiteGround also has a <a href=\"http://www.siteground.com/tutorials/wordpress/wp-cli.htm\" target=\"_blank\">WP-CLI tutorial</a>. </p>
<p>I&#8217;m surprised that there aren&#8217;t more managed WordPress hosts listed here, as it&#8217;s just one extra little perk for getting developers to sign up. If you represent a host that should be on this list, please edit the <a href=\"https://github.com/wp-cli/wp-cli/wiki/List-of-hosting-companies\" target=\"_blank\">WP-CLI hosting companies</a> wiki page to include your company. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 10 Jan 2014 13:56:40 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"WPTavern: WordPress Adds Per-Ticket Notifications to Trac\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=14352\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:158:\"http://wptavern.com/wordpress-adds-per-ticket-notifications-to-trac?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-adds-per-ticket-notifications-to-trac\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3562:\"<p>Andrew Nacin is on a roll with <a href=\"http://wptavern.com/wordpress-core-trac-gets-a-design-refresh-new-features-and-enhancements\" target=\"_blank\">adding improvements to the WordPress core trac</a>. During the holiday break he worked on a design refresh for tickets, enhancements, bug fixes and more ways to sort tickets. Today he <a href=\"http://make.wordpress.org/core/2014/01/09/new-trac-notifications-feature/\" target=\"_blank\">announced</a> per-ticket notifications, an exciting new feature that will help you stay updated on tickets. This is big news for WordPress core development.</p>
<p>Directly above the &#8220;Add Comment&#8221; box you can now find a <strong>&#8220;Watch This Ticket&#8221;</strong> button with a star. Clicking this button will sign you up for notifications on that particular ticket. </p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/notifications.png\" rel=\"prettyphoto[14352]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/notifications.png\" alt=\"notifications\" width=\"636\" height=\"208\" class=\"aligncenter size-full wp-image-14355\" /></a></p>
<p>Notification sign up is also available at the very top of the ticket.</p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/ticket-star.jpg\" rel=\"prettyphoto[14352]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/ticket-star.jpg\" alt=\"ticket-star\" width=\"828\" height=\"326\" class=\"aligncenter size-full wp-image-14361\" /></a></p>
<h3>WordPress Trac is Becoming More Collaborative</h3>
<p>In addition to notifications, the other exciting thing about the new ticket starring feature is that it opens up two new reports for you to view:  <a href=\"https://core.trac.wordpress.org/report/50\" target=\"_blank\">Open tickets I’m watching</a> and <a href=\"https://core.trac.wordpress.org/report/51\" target=\"_blank\">All tickets I’m watching</a>, essentially providing a centralized place to view your bookmarked tickets. </p>
<p>Nacin also hinted at a few upcoming trac features that he is planning on implementing, including:</p>
<ul>
<li>Watch/unwatch a ticket directly from a report (similar to starring a conversation in Gmail)</li>
<li>Subscribe to entire components and milestones: see image below for preview</li>
<li>Add someone to a ticket using @-mentions</li>
<li>Star count displayed in reports next to the new Comments column so starring a ticket is also similar to favoriting/liking</li>
</ul>
<div id=\"attachment_14365\" class=\"wp-caption aligncenter\"><a href=\"http://wptavern.com/wp-content/uploads/2014/01/subscribe-to-components.png\" rel=\"prettyphoto[14352]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/subscribe-to-components.png\" alt=\"Coming Soon: Ability to subscribe to components\" width=\"738\" height=\"442\" class=\"size-full wp-image-14365\" /></a><p class=\"wp-caption-text\">Coming Soon: Ability to subscribe to components</p></div>
<p>These new features have the potential to create a huge boost in efficiency and collaboration for those who contribute to WordPress core development. Even more awesome is that all of this code is <a href=\"https://meta.trac.wordpress.org/ticket/127#comment:21\" target=\"_blank\">open source</a> and was built to be portable to work on other Tracs. For more technical details on how this all works together, check out Nacin&#8217;s <a href=\"https://meta.trac.wordpress.org/ticket/127#comment:21\" target=\"_blank\">comments</a> on the <a href=\"https://meta.trac.wordpress.org/ticket/127\" target=\"_blank\">original ticket</a> that helped inspire changes for better trac management.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 09 Jan 2014 23:32:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"WPTavern: Cultivating a Culture of Respect in the WordPress Community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=14309\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:182:\"http://wptavern.com/cultivating-a-culture-of-respect-in-the-wordpress-community?utm_source=rss&utm_medium=rss&utm_campaign=cultivating-a-culture-of-respect-in-the-wordpress-community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:12011:\"<div id=\"attachment_14327\" class=\"wp-caption aligncenter\"><a href=\"http://wptavern.com/wp-content/uploads/2014/01/wordcampreno.jpg\" rel=\"prettyphoto[14309]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/wordcampreno.jpg\" alt=\"photo credit: Kristin Stith\" width=\"1024\" height=\"683\" class=\"size-full wp-image-14327\" /></a><p class=\"wp-caption-text\">photo credit: <a href=\"http://kristinmstith.wordpress.com/2013/04/15/wordcamp-makes-its-way-to-reno/\" target=\"_blank\">Kristin Stith</a></p></div>
<p>The WordPress project is going through some growing pains. After 10 years there are millions of people around the world using this software and interacting with one another on a daily basis.  The vast majority of these interactions are positive and respectful and for a long time we haven&#8217;t needed any kind of official code of conduct, but this is changing. </p>
<p>&#8220;Women in WordPress&#8221; is currently a hot button topic and has been for years, with many <a href=\"http://make.wordpress.org/summit/2012/11/16/summary-women-in-wordpress/\" target=\"_blank\">discussions</a> centered around how to make women feel more welcome. </p>
<p>A few incidents of harassment have popped up in our community and other open source communities, prompting a movement to create a Code of Conduct or set of  <a href=\"http://make.wordpress.org/community/2013/09/29/community-expectations/\">Community Expectations</a>. Jen Mylo is currently heading up the Community Expectations team that will create a first draft for everyone to review and send feedback on. In the meantime, how can the community handle situations on the front lines at WordCamps or other events where people are gathering?</p>
<h3>Do We Need A Safety Officer At WordCamps?</h3>
<p>Stephanie Leary posted on the Women of WordPress site concerning <a href=\"http://womenofwp.org/2014/01/how-to-report-harassment-at-wordcamps/\" target=\"_blank\">harassment at WordCamps</a> after speaking with a couple of people who experienced minor harassments at events but hadn&#8217;t reported it. She suggests that WordPress create its own harassment policy and that WordCamp organizers designate a safety officer:</p>
<blockquote><p>Once we get to the after parties, the badges come off and the drunken propositions begin. It’s difficult to remember at that point who’s an organizer and who isn’t. Someone on the WordCamp staff needs to be designated as a Safety officer, and that person needs to be introduced at the opening remarks so everyone knows who it is. That person’s contact information needs to be on the Camp website so people can get in touch with him or her when needed.</p></blockquote>
<p>The question that naturally follows is: What should the safety officer or WordCamp organizer do if someone reports harassment at a WordCamp?  Should they be expected to police attendee behavior off-site?</p>
<p>Even if these officers are in place, will WordCampers report incidents of harassment? What happens from there? If the expectation to handle these situations is placed on WordCamp organizers, they will need training for how to respond in different scenarios. Hopefully procedures will be included in the Community Expectations for how conference staff should respond to reports of harassment. </p>
<h3>Why Harassment Commonly Goes Unreported</h3>
<div id=\"attachment_14339\" class=\"wp-caption aligncenter\"><a href=\"http://wptavern.com/wp-content/uploads/2014/01/medium_8985496669.jpg\" rel=\"prettyphoto[14309]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/medium_8985496669.jpg\" alt=\"photo credit: RebeccaBarray - cc\" width=\"800\" height=\"534\" class=\"size-full wp-image-14339\" /></a><p class=\"wp-caption-text\">photo credit: <a href=\"http://www.flickr.com/photos/rebeccabarray/8985496669/\">RebeccaBarray</a> &#8211; <a href=\"http://creativecommons.org/licenses/by-sa/2.0/\">cc</a></p></div>
<p>When I first started blogging I often received many unprofessional comments on my posts that had nothing to do with the content. I have been harassed in live chat support sessions and on Twitter, but those things rarely happen anymore. These issues have improved over the past five years that I&#8217;ve been involved with WordPress. </p>
<p>Unfortunately, I was harassed at my very first WordCamp by an attendee at an after-party. He was heavily pressuring me to go to his hotel room with him and used some crude phrases not fit for print, mixed in with: <strong>&#8220;C&#8217;mon, I know you want to f*** me.&#8221;</strong>, <strong>&#8220;Your husband doesn&#8217;t have to know.&#8221;</strong> and <strong>&#8220;You know you want it.&#8221;</strong></p>
<p>How could the conversation degrade so quickly from building websites to sexually explicit advances? I politely refused several times so as not to make a scene and then the conversation was dead. He apologized the next morning right before I was scheduled to speak in the BuddyPress track.</p>
<p>As someone who is not a natural public speaker, I was already very nervous about my presentation. In my mind I was thinking, <em>&#8220;These developers know EVERYTHING about WordPress and BuddyPress. What am I even doing here?&#8221;</em>  But on top of that I was nervous that I might see in the audience the face of that guy who had just completely objectified me the night before. Being seen as an object compounded my existing lack of self-confidence and made me feel like a total fraud. I wanted to disappear. </p>
<p>Everyone I spoke to about it afterwards told me there was nothing to be done and to just forget about it. They meant well. </p>
<p>At the time I agreed that there was nothing to be done. The reality is that there was no code of conduct, no expectations for after-party behavior, no boundaries set by the organizers, through no fault of their own.  But even if there had been a safety officer, I don&#8217;t know if I would have reported it. I certainly didn&#8217;t want anyone to lose his job over a mistake for which he apologized.</p>
<p>There are a lot of reasons why women and men choose to stay silent and not report these experiences, a few of which include:</p>
<ol>
<li>They don&#8217;t want to draw attention to themselves. </li>
<li>They don&#8217;t want to appear to be weak or seeking pity.</li>
<li>They&#8217;re afraid that somehow they may have invited the unwanted attention.</li>
<li>They don&#8217;t want to rock the boat.</li>
<li>They don&#8217;t want to be treated like a victim.</li>
<li>They fear retaliation or legal action.</li>
<li>They assume that others have had it much worse and they should just be grateful nothing serious happened.</li>
</ol>
<p>Even with a code of conduct in place and a safety officer on hand, it is often difficult for victims of harassment to find a good reason to report these kinds of incidents, especially if nothing technically criminal took place.  It&#8217;s not an easy problem to solve. To truly change behavior we need to look deeper at fostering a culture of respect.</p>
<h3>Creating A Culture of Respect</h3>
<div id=\"attachment_14342\" class=\"wp-caption aligncenter\"><a href=\"http://wptavern.com/wp-content/uploads/2014/01/kids-hands-holding-plants.jpg\" rel=\"prettyphoto[14309]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/kids-hands-holding-plants.jpg\" alt=\"photo credit: africagreenmedia.co.za\" width=\"1698\" height=\"1131\" class=\"size-full wp-image-14342\" /></a><p class=\"wp-caption-text\">photo credit: africagreenmedia.co.za</p></div>
<p>Community can make or break a project. A set of community expectations is the first step in laying a foundation for respectful behavior. I wish we didn&#8217;t need them, but we do. WordCamp-specific community expectations would also be helpful for communicating those values within the context of that event. Though there are many differing opinions about a WordCamp organizer&#8217;s responsibilities to attendees and speakers, I think we can all agree on doing more to highlight respect as one of our chief values. </p>
<p>Respect means holding each other in high esteem and honoring each other. Giving and receiving respect isn&#8217;t something that anyone wants to have to enforce. Nobody is fond of excessive rules and regulations. It&#8217;s something that needs to be part of our culture. The underlying idea is to always approach people with the attitude of &#8220;<em>I respect you and I appreciate that you&#8217;re here</em>,&#8221; whether that&#8217;s in the forums, on Twitter, in IRC, or at WordCamps.</p>
<p>Respect is a learned behavior. When new people see it modeled they are more likely to perceive it as a cultural value that we hold. We need to learn to give it unconditionally. There shouldn&#8217;t be any <em>&#8220;If you respect me, then I will respect you.&#8221;</em> But rather, the idea is that we respect people. Period.  Not because of anything they&#8217;ve achieved or created or because they know how to spell WordPress with the camel case. Sometimes people are new and they are still learning. That applies to behavior, too. People aren&#8217;t born knowing how to be respectful at a WordCamp so we need to articulate what that means for us.</p>
<h3>How does this translate practically when it comes to harassment?</h3>
<p>I propose the following for WordCamps: </p>
<ol>
<li>Create a clear code of conduct or policy for harassment and make it known at the event. Remind people that they or others will probably be drinking at after-parities but that we can still be professionals.</li>
<li>Educate WordCamp organizers on how to respond to reports of harassment. More in-depth training may be required for this position.</li>
<li>Look out for each other. If someone tells you about something that happened, help them find the appropriate channels for dealing with it.</li>
</ol>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/wcsf.jpg\" rel=\"prettyphoto[14309]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/wcsf-300x191.jpg\" alt=\"photo credit: central.wordcamp.org\" width=\"300\" height=\"191\" class=\"size-medium alignright wp-image-14329\" /></a>I think this is a good starting point for helping attendees and speakers feel more comfortable about attending WordPress-related events. If you&#8217;re one of those who wants more diversity and wants to see <a href=\"http://wptavern.com/encouraging-women-to-speak-at-wordcamps\" target=\"_blank\">more women speakers at WordCamps</a>, then creating a code of conduct for your event might be a big help. Andrea Middleton said that the first WordCamp she was aware of having a code of conduct was WordCamp SF 2011. The <a href=\"http://2011.sf.wordcamp.org/about/code-of-conduct/\" target=\"_blank\">code of conduct</a> for that event was inspired by the OSBridge Conference and provides a good starting place for event organizers to use in setting expectations for community behavior.</p>
<p>It&#8217;s important to note that incidents like this are not representative of the WordPress community as a whole. I have rarely encountered finer, more generous people than those I&#8217;ve met through WordPress. Our community is full of kind, polite, welcoming and friendly people. In most of these minor incidents, it happens because someone didn&#8217;t know our unwritten code of conduct. (Or because somebody got wasted.) We can do a better job of communicating that at events.</p>
<p>In the end, at WordCamps we all just want to laugh and enjoy our time learning from each other. There&#8217;s no way for WordCamp organizers to guarantee attendees and speakers that nobody will harass you or make you feel unwelcome. Embracing the risk of interacting with other human beings is part of being an adult. Organizers can, however, better educate themselves about what procedures they can follow if harassment is reported. Ultimately, they may not be able to do too much more than ask the person to leave, but the message will be loud and clear: </p>
<p><strong>In the WordPress community we treat each other with respect.</strong> </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 09 Jan 2014 20:43:01 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"WordPress.tv: Christine Rondeau: Spearhead Your Career By Contributing To WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wordpress.tv/?p=29130\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:100:\"http://wordpress.tv/2014/01/09/christine-rondeau-spearhead-your-career-by-contributing-to-wordpress/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:715:\"<div id=\"v-2olMlnpk-1\" class=\"video-player\">
</div><br />  <a rel=\"nofollow\" href=\"http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/29130/\"><img alt=\"\" border=\"0\" src=\"http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/29130/\" /></a> <img alt=\"\" border=\"0\" src=\"http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=29130&subd=wptv&ref=&feed=1\" width=\"1\" height=\"1\" /><div><a href=\"http://wordpress.tv/2014/01/09/christine-rondeau-spearhead-your-career-by-contributing-to-wordpress/\"><img alt=\"Christine Rondeau: Spearhead Your Career By Contributing To WordPress\" src=\"http://videos.videopress.com/2olMlnpk/video-67e4ef85f8_std.original.jpg\" width=\"160\" height=\"120\" /></a></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 09 Jan 2014 19:59:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"WordPress.tv\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"WordPress.tv: Scott Bolinger: Lesser Known But Super Hip Responsive Design Tricks\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wordpress.tv/?p=26113\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"http://wordpress.tv/2014/01/09/scott-bolinger-lesser-known-but-super-hip-responsive-design-tricks/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:711:\"<div id=\"v-snB0EHWo-1\" class=\"video-player\">
</div><br />  <a rel=\"nofollow\" href=\"http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/26113/\"><img alt=\"\" border=\"0\" src=\"http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/26113/\" /></a> <img alt=\"\" border=\"0\" src=\"http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=26113&subd=wptv&ref=&feed=1\" width=\"1\" height=\"1\" /><div><a href=\"http://wordpress.tv/2014/01/09/scott-bolinger-lesser-known-but-super-hip-responsive-design-tricks/\"><img alt=\"Scott Bolinger: Lesser Known But Super Hip Responsive Design Tricks\" src=\"http://videos.videopress.com/snB0EHWo/video-46ac1c3db3_std.original.jpg\" width=\"160\" height=\"120\" /></a></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 09 Jan 2014 16:51:05 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"WordPress.tv\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"WPTavern: Encouraging Women To Speak At WordCamps\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=14277\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:142:\"http://wptavern.com/encouraging-women-to-speak-at-wordcamps?utm_source=rss&utm_medium=rss&utm_campaign=encouraging-women-to-speak-at-wordcamps\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5592:\"<p>Jen Mylo has <a title=\"http://make.wordpress.org/community/2014/01/07/women-speakers-at-wordcamps/\" href=\"http://make.wordpress.org/community/2014/01/07/women-speakers-at-wordcamps/\">published some interesting statistics</a> on the WordPress Community blog that show WordCamps still have a long way to go when it comes to women speaking at these events. Between 2012 and 2013, there was only a slight increase in the amount of women speaking at WordCamps. Possibly compounding the issue is that most of the events with dismal numbers had a large number of &#8220;<em>circuit</em>&#8221; speakers who were predominantly male. Circuit speakers are individuals who speak at multiple WordCamps during the year.</p>
<h3>It&#8217;s Difficult Talking About This Subject As A Male</h3>
<p>As a male, I feel like I have no business talking about matters such as these. I love the fact that the WordPress project and WordCamps in general encourage diversity. For example, WordCamp Miami clearly states on their <a title=\"http://2014.miami.wordcamp.org/speakers/speaker-submissions/\" href=\"http://2014.miami.wordcamp.org/speakers/speaker-submissions/\">speaker submission page</a> their desire for a diversified group of presenters: &#8220;<em>Our general policy is that we don&#8217;t consider the race, sex, religion, or any other factor of the speaker to play a part in our selection process.&#8221;&nbsp;</em>If organizers are pressured to start selecting women speakers based on the fact that they are women, it would invalidate policies like the one referenced above.</p>
<h3>Yay Or Ney To WordCamp Circuit Speakers?</h3>
<div id=\"attachment_14281\" class=\"wp-caption alignright\"><a href=\"http://wptavern.com/wp-content/uploads/2014/01/WordPressCircuit.jpg\" rel=\"prettyphoto[14277]\"><img class=\"size-medium wp-image-14281\" alt=\"WordPress Circuit\" src=\"http://wptavern.com/wp-content/uploads/2014/01/WordPressCircuit-300x229.jpg\" width=\"300\" height=\"229\" /></a><p class=\"wp-caption-text\">Image courtesy of <a title=\"http://fuelyourcoding.com/getting-started-writing-wordpress-plugins/\" href=\"http://fuelyourcoding.com/getting-started-writing-wordpress-plugins/\">Fuel Your Coding</a></p></div>
<p>Going back to the topic of circuit speakers which is very touchy, I think it&#8217;s important to remember what WordCamps are truly about. In their simplest form, they are WordPress meetups but on a bigger scale. WordCamps are highly encouraged to be made up of mostly local attendees. Most of these events have a set of dedicated volunteers that record sessions that are uploaded to <a title=\"http://wordpress.tv/\" href=\"http://wordpress.tv/\">WordPress.tv</a> after the event. Thanks to WordPress.tv, one question I have is whether or not individuals should be discouraged from traveling to multiple WordCamps to give the same presentation? If that road is traveled, where does it lead? WordCamp Central placing limits on the amount of WordCamps a presenter can travel to and give the same presentation?</p>
<h3>Starting With The Local WordPress Meetup</h3>
<div id=\"attachment_14284\" class=\"wp-caption aligncenter\"><a href=\"http://wptavern.com/wp-content/uploads/2014/01/LocalWordPressMeetup.jpg\" rel=\"prettyphoto[14277]\"><img class=\"size-full wp-image-14284\" alt=\"NEO WordPress Meetup January 24, 2013\" src=\"http://wptavern.com/wp-content/uploads/2014/01/LocalWordPressMeetup.jpg\" width=\"544\" height=\"358\" /></a><p class=\"wp-caption-text\">NEO WordPress Meetup January 24, 2013</p></div>
<p>Since WordCamps are all about local first, that&#8217;s where any initiative encouraging diversity would have the largest and immediate impact. The local meetups I have attended have had almost a 50/50 mix of males to females. The women I&#8217;ve had a pleasure to help are usually brand new to WordPress and its ecosystem. I do my part by helping them out as best I can and then encourage them to be part of the larger community. If they decide to remain quiet and not take an active role in the WordPress community, what am I supposed to do? Push them into it?</p>
<h3>New Study Shows Promising Results</h3>
<p>If you&#8217;re a male WordCamp organizer, consider having one or more women be part of the conference organization group. A <a title=\"http://www.theatlantic.com/technology/archive/2014/01/the-easiest-possible-way-to-increase-female-speakers-at-conferences/282858/\" href=\"http://www.theatlantic.com/technology/archive/2014/01/the-easiest-possible-way-to-increase-female-speakers-at-conferences/282858/\">recent post by The Atlantic</a> highlights a study that shows having just one woman on the organizing committee for a conference greatly increases the likelihood of women appearing at the front of the room.</p>
<h3>More Women Everywhere!</h3>
<p>I&#8217;m all for more women in tech, women in WordPress, women everywhere. I don&#8217;t like how some of them have gone about raising awareness of the issue because it seems more like a war between males and females. But WordPress has done a great job enabling people of any race, religion, etc to contribute to the project. Without forcing diversity on WordCamp organizers, what are they supposed to do if no women submit speaker applications? What if the speaker pool they have to select from are all white males?</p>
<p>The initiatives that Jen Mylo is pioneering with other members of the WordPress community are great. I just hope they remain as initiatives and don&#8217;t end up becoming more WordCamp Central requirements that organizers <strong>HAVE</strong> to follow. WordCamp organizers have enough on their shoulders as it is.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 09 Jan 2014 02:00:17 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"Jeffro\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"WPTavern: New Plugin Adds Persian Calendar and Language Support to WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=14275\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:196:\"http://wptavern.com/new-plugin-adds-persian-calendar-and-language-support-to-wordpress?utm_source=rss&utm_medium=rss&utm_campaign=new-plugin-adds-persian-calendar-and-language-support-to-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2989:\"<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/wppersidate.jpg\" rel=\"prettyphoto[14275]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/wppersidate.jpg\" alt=\"wppersidate\" width=\"800\" height=\"259\" class=\"aligncenter size-full wp-image-14295\" /></a></p>
<p>WordPress is available in <a href=\"http://codex.wordpress.org/WordPress_in_Your_Language\" target=\"_blank\">more than 80 different languages</a>, due in large part to the many community volunteers who have submitted translations. Translating WordPress into a new language makes it possible for people around the world to take advantage of this open source publishing platform to make their voices heard. In addition to translations, some languages and cultures have different requirements for <a href=\"https://codex.wordpress.org/Post_Meta_Data_Section\" target=\"_blank\">post meta data</a>.</p>
<p><a href=\"http://wordpress.org/plugins/wp-parsidate/\" target=\"_blank\">WP-parsidate</a> is a relatively new plugin that was created to be a Persian package builder for WordPress. This plugin adds support for the Shamsi or Jalali Calendar, which is the traditional <a href=\"http://en.wikipedia.org/wiki/Iranian_calendar\" target=\"_blank\">Persian calendar</a> based on the sun. It rewrites dates in posts, comments, pages, archives, search, and categories to utilize the Shamsi calendar. WP-Parsidate also features the following:</p>
<ul>
<li>Shamsi (Jalali) date in Posts, comments, pages, archives, search, categories</li>
<li>Shamsi (Jalali) date in Permalinks</li>
<li>Shamsi (Jalali) date in admin sections such as posts lists, comments lists, pages lists</li>
<li>Shamsi (Jalali) date in post quick edit, comment quick edit, page quick edit of admin panel</li>
<li>Shamsi (Jalali) archive widget</li>
<li>RTL and fixed tinymce editor</li>
<li>Poweful and fast function for fixing Arabic (ي , ك) to Persian (ی , ک)</li>
<li>Poweful and fast function for Persian numbers</li>
</ul>
<p>Essentially, this plugin provides a better Persian language experience with WordPress. It has already received many five star ratings and positive reviews. I installed it just for fun and it&#8217;s amazing how it completely transforms the WordPress frontend and backend. This screenshot is from a test site where I didn&#8217;t even have the Persian translation active:</p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/wp-persidate.jpg\" rel=\"prettyphoto[14275]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/wp-persidate.jpg\" alt=\"wp-persidate\" width=\"1059\" height=\"461\" class=\"aligncenter size-full wp-image-14292\" /></a></p>
<p>Though Persian-speakers may be a small portion of worldwide WordPress users, it&#8217;s quite inspirational to see a plugin that changes WordPress to present content in a better way for their language. If you have friends who blog in Persian, make sure to share the <a href=\"http://wordpress.org/plugins/wp-parsidate/\" target=\"_blank\">WP-parsidate</a> plugin with them.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 09 Jan 2014 01:38:05 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"WPTavern: Theme Friendly Helps You Find the Perfect WordPress Theme\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=14224\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:178:\"http://wptavern.com/theme-friendly-helps-you-find-the-perfect-wordpress-theme?utm_source=rss&utm_medium=rss&utm_campaign=theme-friendly-helps-you-find-the-perfect-wordpress-theme\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3420:\"<p>Hunting for a new WordPress theme can be an overwhelming task, given the sheer number of theme providers out there. With tens of thousands of WordPress themes in the wild, it&#8217;s not always easy to narrow it down or to know which themes are high quality.</p>
<p><a href=\"http://themefriendly.com/find-themes/\" target=\"_blank\">Theme Friendly</a> aims to solve this problem by providing a sortable list of professionally-reviewed WordPress themes. <a href=\"https://twitter.com/alexmansfield\" target=\"_blank\">Alex Mansfield</a> launched his new Theme Friendly concept today with 35 theme reviews from nine different commercial theme shops. </p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/theme-friendly.jpg\" rel=\"prettyphoto[14224]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/theme-friendly.jpg\" alt=\"theme-friendly\" width=\"1532\" height=\"690\" class=\"aligncenter size-full wp-image-14252\" /></a></p>
<h3>Theme Friendly Sorts Themes Based On Quality Score</h3>
<p>Theme Friendly solicits donated copies of themes from WordPress theme authors. Mansfield then uses a subset of the <a href=\"http://make.wordpress.org/themes/guidelines/\" target=\"_blank\">WordPress theme review team guideline checks</a> when reviewing the themes in order to generate a quality score. He documents exactly how the theme got its score and records any additional information that might be useful for sorting, ie. theme type, feature support, layout options, plugin support, page templates available, translated languages, etc. This results in an excellent, detailed list of sorting options in the sidebar.</p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/example-review.jpg\" rel=\"prettyphoto[14224]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/example-review.jpg\" alt=\"example-review\" width=\"1210\" height=\"687\" class=\"aligncenter size-full wp-image-14254\" /></a></p>
<p>Visitors of the site can search themes by their own requirements and then read up on the quality score. Searching the site returns results sorted by quality score, rather than most recent submissions. The idea is that anyone shopping for a WordPress theme can make a more informed decision as a consumer, based on the review provided by Theme Friendly.</p>
<p>Mansfield manually reviews each theme by the same criteria. He disclosed that he does in fact use affiliate links but that they do not in any way influence the theme reviews. If you&#8217;d like to learn more about his process in creating the site and the technical details behind it, check out his series on <a href=\"http://alexmansfield.com/projects/wordpress-theme-review-site-day-4\" target=\"_blank\">Creating a Commercial WordPress Theme Review Site</a>.</p>
<p>The <a href=\"http://themefriendly.com/find-themes/\" target=\"_blank\">Theme Friendly</a> concept provides another helpful way for consumers to explore and purchase WordPress themes. If you like the idea of having a site where you can find professionally-reviewed themes, there are a few things you can do to help Mansfield expand his library. Drop him a note on his <a href=\"http://themefriendly.com/contact/\" target=\"_blank\">contact form</a> to let him know what is the most frustrating part of shopping for WordPress themes. If you&#8217;re a WordPress theme developer, you can also get in touch with him to request a review of your theme and its addition to the Theme Friendly library.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 08 Jan 2014 21:12:01 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"WPTavern: WordPress School Is About To Be In Session\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=14192\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:148:\"http://wptavern.com/wordpress-school-is-about-to-be-in-session?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-school-is-about-to-be-in-session\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2612:\"<p>If you love WordPress, keep an eye on your calendar for Valentines day 2014 as that&#8217;s when <a title=\"http://wpschool.org\" href=\"http://wpschool.org\">WP School</a> is scheduled to launch. WP School is an initiative started by Pooria Asteraky with the goal of bringing WordPress education to the masses. Classified as a (<strong>MOOC</strong>) or massive open online course, the site will be dedicated to WordPress education and online courses in a variety of different languages for people to use across the world.</p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/WpSchoolFrontPage.jpg\" rel=\"prettyphoto[14192]\"><img class=\"aligncenter size-large wp-image-14202\" alt=\"WP School Front Page\" src=\"http://wptavern.com/wp-content/uploads/2014/01/WpSchoolFrontPage-500x243.jpg\" width=\"500\" height=\"243\" /></a></p>
<p>The start-up is currently within the funding stage. Pooria is using indiegogo to power the <a title=\"http://www.indiegogo.com/projects/wordpress-school-mooc\" href=\"http://www.indiegogo.com/projects/wordpress-school-mooc\">WP School campaign</a>. The campaign contains a number of perks for those that contribute funds ranging from discounts to early access to course material. With <strong>33 days</strong> left to go, the campaign has raised <strong>$1,029</strong> of the <strong>$25,000 goal</strong>. According to the campaign description, the money would be used to purchase servers, provide an ad free experience, and provide a period of time to allow revenues to be generated to take the place of the initial campaign funds.</p>
<blockquote><p>We have already made the main investment. Over the last two years we have been doing extensive research and development to plan this project. We have defined the education roadmap, skill levels and all the related knowledge and expertise. We have also developed many courses that will be offered from the first release.</p></blockquote>
<p>Pooria points out in the campaign text: &#8220;<em>Education is the wisest investment for any person or society</em>&#8220;. I couldn&#8217;t agree more. However, with sites like <a title=\"http://wpsessions.com/\" href=\"http://wpsessions.com/\">WPSessions.com</a>, <a title=\"http://wpmentor.org/\" href=\"http://wpmentor.org/\">WPMentor.org</a> and others, there seems to be no end to the amount of resources that are available for self-motivated learners to learn WordPress. Can something like WPSchool.org succeed in an online world where so much WordPress information is available for free? In my opinion, the more WordPress learning resources that exist, the better it is for everyone!</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 08 Jan 2014 19:43:01 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"Jeffro\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"WPTavern: 10 Free Chrome Extensions for WordPress Users\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=13520\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:154:\"http://wptavern.com/10-free-chrome-extensions-for-wordpress-users?utm_source=rss&utm_medium=rss&utm_campaign=10-free-chrome-extensions-for-wordpress-users\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:9136:\"<p>In December of 2013, <a href=\"http://www.w3schools.com/browsers/browsers_stats.asp\" target=\"_blank\">w3schools reported</a> that Chrome has captured 55.8 % of the global market share of top web browsers, with Firefox at 26.8% and IE coming in at 9.0%. With Chrome usage on the rise and now dominating the web, we&#8217;d like to highlight a few tools that will help WordPress users detect the software on websites as well as publish content directly from Chrome.</p>
<h2>WordPress.com Extension</h2>
<p><a href=\"https://chrome.google.com/webstore/detail/wordpresscom-extension/pnbbfhcegldppmibabepjfjloachnmjb\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/wpcom.png\" alt=\"wpcom\" width=\"1280\" height=\"798\" class=\"aligncenter size-full wp-image-14114\" /></a></p>
<p>The <a href=\"https://chrome.google.com/webstore/detail/wordpresscom-extension/pnbbfhcegldppmibabepjfjloachnmjb\" target=\"_blank\">WordPress.com Extension</a> is a free tool created by WordPress.com. It brings features from WordPress.com into your browser, including notifications, the ability to follow sites and start new blog posts instantly from your browser toolbar.</p>
<p>The latest version of the extension displays notifications like other native notifications in Chrome. These can be configured in the extension&#8217;s preferences to show notifications that are the most useful to you and hide the others.</p>
<h2>WordPress.org Plugins SVN Link</h2>
<p><a href=\"https://chrome.google.com/webstore/detail/wordpressorg-plugins-svn/nfhpbeacfmdhhlhmolfcdlknnmalnled\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/svn-link.png\" alt=\"svn-link\" width=\"1278\" height=\"793\" class=\"aligncenter size-full wp-image-14116\" /></a></p>
<p>The <a href=\"https://chrome.google.com/webstore/detail/wordpressorg-plugins-svn/nfhpbeacfmdhhlhmolfcdlknnmalnled\" target=\"_blank\">WordPress.org Plugins SVN Link</a> fits in seamlessly with plugin pages. It&#8217;s something I use so often that I forget that it has been added by my browser. This extension does one simple thing: It adds a button linking to the plugin&#8217;s SVN repo under the .zip file download button on WordPress.org. This makes it super easy to explore the code of a plugin before you decide to install it.</p>
<h2>WordPress Version Check</h2>
<p><a href=\"https://chrome.google.com/webstore/detail/wordpress-version-check/hbeikkjblcogpkdnchpffgefhkilodnn\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/version-checker.png\" alt=\"version-checker\" width=\"1280\" height=\"729\" class=\"aligncenter size-full wp-image-14118\" /></a></p>
<p><a href=\"https://chrome.google.com/webstore/detail/wordpress-version-check/hbeikkjblcogpkdnchpffgefhkilodnn\" target=\"_blank\">WordPress Version Check</a> provides a quick way to see what version of WordPress a site is running. First, it checks to see if the site is running WordPress and then displays whether it&#8217;s current or outdated. This extension is available in a <a href=\"https://addons.mozilla.org/firefox/addon/wordpress-version-check/\" target=\"_blank\">Firefox version</a>. </p>
<h2>Quick Switch for WordPress Accounts</h2>
<p><a href=\"https://chrome.google.com/webstore/detail/quick-switch-for-wordpres/nmdiilgiakfmmipnolamomicpaeddhpk/related\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/account-switcher.png\" alt=\"account-switcher\" width=\"1282\" height=\"796\" class=\"aligncenter size-full wp-image-14120\" /></a></p>
<p><a href=\"https://chrome.google.com/webstore/detail/quick-switch-for-wordpres/nmdiilgiakfmmipnolamomicpaeddhpk/related\" target=\"_blank\">Quick Switch</a> for WordPress Accounts is a handy extension that lets you easily switch between accounts on your WordPress sites. If you have sites you maintain regularly where you&#8217;re always signing in and out of accounts, this extension could be a huge time saver for you.</p>
<h2>Theme Sniffer</h2>
<p><a href=\"https://chrome.google.com/webstore/detail/theme-sniffer/kihhefcbenhkjgjhchanjfhhflaojldn\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/theme-sniffer.png\" alt=\"theme-sniffer\" width=\"1400\" height=\"752\" class=\"aligncenter size-full wp-image-14122\" /></a></p>
<p><a href=\"https://chrome.google.com/webstore/detail/theme-sniffer/kihhefcbenhkjgjhchanjfhhflaojldn\" target=\"_blank\">Theme Sniffer</a> is a handy little extension that will tell you what theme a WordPress or Joomla site is using. During my tests, I found that it isn&#8217;t able to detect child themes. It will, however, correctly display the parent theme in use.</p>
<h2>WP Write</h2>
<p><a href=\"https://chrome.google.com/webstore/detail/wp-write/ccihbopoacphplchahdeliepepbhjpbe\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/wpwrite.png\" alt=\"wpwrite\" width=\"1747\" height=\"1222\" class=\"aligncenter size-full wp-image-14124\" /></a></p>
<p><a href=\"https://chrome.google.com/webstore/detail/wp-write/ccihbopoacphplchahdeliepepbhjpbe\" target=\"_blank\">WP Write</a> is a simple, browser-based client for WordPress. It uses XML-RPC to post to your WordPress site directly from Chrome, without you having to log into the admin. The extension supports WordPress.com blogs and self-hosted WordPress sites. It&#8217;s very handy for quickly saving ideas for posts as drafts while browsing but can also be used to format and publish posts.</p>
<h2>Chrome Sniffer</h2>
<p><a href=\"https://chrome.google.com/webstore/detail/chrome-sniffer/homgcnaoacgigpkkljjjekpignblkeae<br />
\"><br />
\"><br />
\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/chrome-sniffer.png\" alt=\"chrome-sniffer\" width=\"1791\" height=\"1039\" class=\"aligncenter size-full wp-image-14126\" /></a></p>
<p><a href=\"https://chrome.google.com/webstore/detail/chrome-sniffer/homgcnaoacgigpkkljjjekpignblkeae\" target=\"_blank\">Chrome Sniffer</a> is a useful extension if you often find yourself wondering what CMS a site is running. It inspects the web framework / CMS and javascript library on the site you&#8217;re browsing and displays icons in the address bar indicating the detected framework. Chrome Sniffer currently detects more than 100 popular CMS and Javascript libraries and is in the process of adding version detection to the extension.</p>
<h2>WordPress Admin Bar Control</h2>
<p><a href=\"https://chrome.google.com/webstore/detail/wordpress-admin-bar-contr/joldejophkhmeajgjenfnfdpfjkalckn\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/admin-bar-control.png\" alt=\"admin-bar-control\" width=\"1600\" height=\"978\" class=\"aligncenter size-full wp-image-14128\" /></a></p>
<p><a href=\"https://chrome.google.com/webstore/detail/wordpress-admin-bar-contr/joldejophkhmeajgjenfnfdpfjkalckn\" target=\"_blank\">WordPress Admin Bar Control</a> is a simple extension that lets you easily turn on/off the WordPress admin bar on any site you are viewing. The extension also remembers your choice between pageloads and browser sessions. If you want the admin bar back, simply click the button again to restore it.</p>
<h2>WordPress Site Manager</h2>
<p><a href=\"https://chrome.google.com/webstore/detail/wordpress-site-manager/allgackcccfpminjnninimgkmclmoafe\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/sitemanager.png\" alt=\"sitemanager\" width=\"1600\" height=\"888\" class=\"aligncenter size-full wp-image-14130\" /></a></p>
<p><a href=\"https://chrome.google.com/webstore/detail/wordpress-site-manager/allgackcccfpminjnninimgkmclmoafe\" target=\"_blank\">WordPress Site Manager</a> is an extension that stores WordPress site information for multiple sites and gives you quick access to important pages. It also changes the WordPress theme editor into a <a href=\"http://codemirror.net/\" target=\"_blank\">CodeMirror</a> editor. </p>
<h2>MultiPress</h2>
<p><a href=\"https://chrome.google.com/webstore/detail/multipress/gjboaoikjenhgjhnkbgiaodijpbidekl\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/multipress.png\" alt=\"multipress\" width=\"1539\" height=\"937\" class=\"aligncenter size-full wp-image-14132\" /></a></p>
<p>The <a href=\"https://chrome.google.com/webstore/detail/multipress/gjboaoikjenhgjhnkbgiaodijpbidekl\" target=\"_blank\">MultiPress</a> extension adds WordPress&#8217; Press This interface to Chrome. The latest version of this extension opens in a new tab instead of a popup. You can add up to five WordPress sites to the settings, allowing you to quickly post to any of your favorite sites.</p>
<h3>Something To Consider</h3>
<p>If you install multiple WordPress-related Chrome extensions, please be advised that the developers quite often use the WordPress logo in the toolbar. In some cases you may have two or three WordPress logos in your toolbar with no distinction between them for what extension it launches. It&#8217;s best to select the extensions that will be the most useful for you instead of going crazy installing all of them. If you&#8217;re a Chrome extension developer who creates WordPress-related extensions, please consider using a more unique button design. </p>
<p><strong>Which extensions are the most useful for your WordPress workflow? Do you use any other WordPress-related Chrome extensions not listed here? Let us know in the comments.</strong></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 08 Jan 2014 19:12:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"Alex King: More on The Value of Blogging\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://alexking.org/?p=19188\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"http://alexking.org/blog/2014/01/08/more-on-the-value-of-blogging\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:706:\"<p>Matt recently wrote about the <a href=\"http://ma.tt/2014/01/intrinsic-blogging/\">value of blogging</a>. I&#8217;d been working on some notes in this area as well, but from a different approach.</p>
<p>The part of blogging I find particularly interesting and valuable is the format it provides to be thoughtful about things. Notice something. Think about it. Write about it. The process of exploring something can often lead to interesting places and intersections.</p>
<p>I&#8217;ve been blogging here since <a href=\"http://alexking.org/blog/2002/10\">October of 2002</a>. It&#8217;s given me a place to think, publish, and get useful feedback.</p>
<p><a href=\"http://wordpress.org/\">Recommended</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 08 Jan 2014 17:36:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Alex\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"WordPress.tv: Morten Rand-Hendriksen: Can WordPress Really Do That? Take 2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wordpress.tv/?p=24214\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"http://wordpress.tv/2014/01/08/morten-rand-hendriksen-can-wordpress-really-do-that-take-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:696:\"<div id=\"v-4KN3sEa4-1\" class=\"video-player\">
</div><br />  <a rel=\"nofollow\" href=\"http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24214/\"><img alt=\"\" border=\"0\" src=\"http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24214/\" /></a> <img alt=\"\" border=\"0\" src=\"http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24214&subd=wptv&ref=&feed=1\" width=\"1\" height=\"1\" /><div><a href=\"http://wordpress.tv/2014/01/08/morten-rand-hendriksen-can-wordpress-really-do-that-take-2/\"><img alt=\"Morten Rand-Hendriksen: Can WordPress Really Do That? Take 2\" src=\"http://videos.videopress.com/4KN3sEa4/video-4934e731a4_std.original.jpg\" width=\"160\" height=\"120\" /></a></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 08 Jan 2014 15:51:19 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"WordPress.tv\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"WordPress.tv: Matt Medeiros: Land Bigger Clients While Working From An Island\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wordpress.tv/?p=23205\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:94:\"http://wordpress.tv/2014/01/08/matt-medeiros-land-bigger-clients-while-working-from-an-island/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:703:\"<div id=\"v-HUbCGZvq-1\" class=\"video-player\">
</div><br />  <a rel=\"nofollow\" href=\"http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/23205/\"><img alt=\"\" border=\"0\" src=\"http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/23205/\" /></a> <img alt=\"\" border=\"0\" src=\"http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=23205&subd=wptv&ref=&feed=1\" width=\"1\" height=\"1\" /><div><a href=\"http://wordpress.tv/2014/01/08/matt-medeiros-land-bigger-clients-while-working-from-an-island/\"><img alt=\"Matt Medeiros: Land Bigger Clients While Working From An Island\" src=\"http://videos.videopress.com/HUbCGZvq/video-49242e7c76_std.original.jpg\" width=\"160\" height=\"120\" /></a></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 08 Jan 2014 14:54:54 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"WordPress.tv\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"WPTavern: Industry Night #5 – David Cramer, My Shortcodes and Caldera Engine\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=14174\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:188:\"http://wptavern.com/industry-night-5-david-cramer-my-shortcodes-and-caldera-engine?utm_source=rss&utm_medium=rss&utm_campaign=industry-night-5-david-cramer-my-shortcodes-and-caldera-engine\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2193:\"<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/IndustryNight_albumart_2d.jpg\" rel=\"prettyphoto[14174]\"><img class=\"alignleft size-medium wp-image-14203\" alt=\"IndustryNight_albumart_2d\" src=\"http://wptavern.com/wp-content/uploads/2014/01/IndustryNight_albumart_2d-300x300.jpg\" width=\"300\" height=\"300\" /></a>Tonight we are engaged in conversation with <a title=\"David Cramer\" href=\"http://profiles.wordpress.org/desertsnowman/\" target=\"_blank\">David Cramer</a>, the creator of <a title=\"My Shortcodes\" href=\"http://wordpress.org/plugins/my-shortcodes/\" target=\"_blank\">My Shortcodes</a> and <a title=\"Caldera Engine Pro Version\" href=\"http://myshortcodes.cramer.co.za/pro-version/\" target=\"_blank\">Caldera Engine</a>.</p>
<p>I identify David&#8217;s persona and engineering specialty as an &#8220;Engine Creator&#8221;. Behind every amazing race car win you ever saw, there was a team of engineers and grease monkeys behind the scenes that fine-tuned the engine of the car to amazing precision and performance. Driving the efficiency beyond what the original manufacturers ever thought was possible. That&#8217;s what David Cramer can do with WordPress and the plugins he has created. </p>
<p>He&#8217;s taken the stock 4 cylinder engine in your typical WordPress installation and given you the ability to drop in a super vortex V8 that can do things with shortcodes that you never thought were possible. We&#8217;re talking shortcodes within shortcodes here. The Tony Stark ARC reactor of aftermarket WordPress mods and the best part is, that Caldera Engine is a plugin that exports other plugins. It&#8217;s literally a <strong>Plugin Construction Kit</strong>.</p>
<p>David is also an active contributor in the <a title=\"PODS Plugin\" href=\"http://wordpress.org/plugins/pods/\" target=\"_blank\">PODS plugin</a>, which we will talk with him about on another night. You can read up about it in the meantime and even help to contribute to the beta-testing phase. So pull up a chair, grab a cold one and join me in my conversation with David Cramer.</p>
<p>Industry Night is produced and hosted by <a title=\"Marcus Couch\" href=\"http://marcuscouch.com\">Marcus Couch</a> for WPTavern.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 08 Jan 2014 01:01:08 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Marcus Couch\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"WPTavern: Help Shape BuddyPress Development in 2014\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=14169\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:146:\"http://wptavern.com/help-shape-buddypress-development-in-2014?utm_source=rss&utm_medium=rss&utm_campaign=help-shape-buddypress-development-in-2014\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2977:\"<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/bp-2014.jpg\" rel=\"prettyphoto[14169]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/bp-2014.jpg\" alt=\"bp-2014\" width=\"1023\" height=\"472\" class=\"aligncenter size-full wp-image-14181\" /></a></p>
<p><a href=\"http://buddypress.org/\" target=\"_blank\">BuddyPress</a> is about to enter development for the 2.0 release and the core team is seeking input from the community on what to prioritize for 2014 development. John James Jacoby posted on the BuddyPress blog to invite all users, developers and interested parties to weigh in on BuddyPress in the <a href=\"http://buddypress.org/2014/01/2014-buddypress-survey/\" target=\"_blank\">2014 Survey</a>. </p>
<p>Questions in the survey range from how many BuddyPress sites you&#8217;ve built to what kind of hosting you opt for, WordPress and BuddyPress versions in use on your sites, and plugins that you&#8217;re using with social network. The survey also delves deeper into user opinions on the best features of BuddyPress and how it can be improved.</p>
<h3>A Plea For Reliable Spam Protection</h3>
<p>One question in the survey asks what features you think should be added to BuddyPress. I found this one to be difficult to answer, given how robust the plugin already is for quickly launching a full-featured social network. BuddyPress already covers all the basics and it&#8217;s not easy to think of something that could be added that wouldn&#8217;t be better left to the realm of plugins. </p>
<p>If I were to nail it down to the most pressing issue for the vast majority of BuddyPress users, then better spam protection built into the core is at the top of my wishlist. Better core support for combating spam or an officially supported plugin would make a world of difference to BuddyPress community administrators. There are several plugin options available for curbing spam signups, but the effectiveness for most of them is pretty much hit or miss. </p>
<p>In addition to a reliable option for stopping spam users at the door, it would also be nice to be able to display trending or popular content more easily, based on favorites or most-commented activity. This feature would be beneficial for more active BuddyPress communities and would help to increase interaction on the most important activity items. Then again, something like this might be better left to plugin territory. </p>
<p>Everyone has an opinion about BuddyPress. Will you make yours count? It only takes a few minutes to complete the survey. Don&#8217;t miss your chance to help shape BuddyPress core development in 2014. Your participation will help this software better serve the many communities it powers across the web. Results will be posted soon to the <a href=\"http://bpdevel.wordpress.com\" target=\"_blank\">BuddyPress Development blog</a>, so <a href=\"http://buddypress.org/2014/01/2014-buddypress-survey/\" target=\"_blank\">take the survey now</a> while it&#8217;s still active.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 07 Jan 2014 22:54:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"Matt: Hire by Auditions, Not Resumes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=43435\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"http://ma.tt/2014/01/hire-by-auditions-not-resumes/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:179:\"<p>I have a guest article on the Harvard Business Review blogs called <a href=\"http://blogs.hbr.org/2014/01/hire-by-auditions-not-resumes/\">Hire by Auditions, Not Resumes</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 07 Jan 2014 21:54:43 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:30;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"BuddyPress: 2014 BuddyPress Survey\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"http://buddypress.org/?p=176550\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"http://buddypress.org/2014/01/2014-buddypress-survey/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1433:\"<p>BuddyPress 1.0 launched just over 5 years ago, and it&#8217;s quite a different piece of software today than it was back then. We&#8217;ve added (and retired) several components, reinvented the way it integrates into WordPress&#8217;s themes, and even changed our logo color (from orange to red.)</p>
<p>BuddyPress wouldn&#8217;t be what it is without the feedback of the community. While the core leadership team has a vision, how we ultimately prioritize features and releases is determined from a cocktail of wants, needs, desires, trends, availability, and is also largely influenced by WordPress too.</p>
<p>We want to start this year off at least facing the right direction, so Merci Me was kind enough to put together a survey based on some questions that we have for you. The answers to these questions will help us build a better BuddyPress by ensuring we&#8217;re still creating what you still want to use, and help us determine if any course corrections are necessary.</p>
<p>If you&#8217;re reading this post, you&#8217;re exactly the person we want to take this survey. Users; developers; even interested parties have opinions and expectations, and we want to hear all of them. You will find the survey embedded below.</p>
<div class=\"pd-embed\" type=\"type\"></div>
<p></p>
<p>Thanks for taking the time to help us out. We really appreciate it, and we&#8217;ll post the results of this survey in the next few weeks.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 07 Jan 2014 20:30:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"John James Jacoby\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:31;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"WPTavern: AppPresser Launches First Mobile App Development Framework For WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=14136\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:208:\"http://wptavern.com/apppresser-launches-first-mobile-app-development-framework-for-wordpress?utm_source=rss&utm_medium=rss&utm_campaign=apppresser-launches-first-mobile-app-development-framework-for-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4836:\"<p><a href=\"http://wptavern.com/wp-content/uploads/2013/12/apppresser.jpg\" rel=\"prettyphoto[14136]\"><img src=\"http://wptavern.com/wp-content/uploads/2013/12/apppresser.jpg\" alt=\"apppresser\" width=\"1100\" height=\"450\" class=\"aligncenter size-full wp-image-12507\" /></a></p>
<p>The <a href=\"http://webdevstudios.com/\" target=\"_blank\">WebDevStudios</a> development team was one of the first agencies to pioneer WordPress-powered apps. They originally launched into the space by privately creating apps for high profile clients like the <a href=\"http://www.ymcanyc.org/association/pages/y-mvp\" target=\"_blank\">YMCA</a> and <a href=\"http://www.dallasmuseumofart.org/Visit/Friends/\" target=\"_blank\">Dallas Museum of Art</a>. Last year these apps were showcased by WordPress co-founder Matt Mullenweg, who predicts that WordPress as an application platform will become the dominant development focus during the next few years.</p>
<p>Today <a href=\"http://apppresser.com/\" target=\"_blank\">AppPresser</a> officially launched the very first mobile app development framework for WordPress. This <a href=\"http://apppresser.com/about/\" target=\"_blank\">team</a>, made up of many of the core folks from WebDevStudios, decided to go far beyond their previous work of creating a few apps for private clients. They set out to do something truly disruptive and formed AppPresser with the goal of putting the power of app creation into the hands of your average WordPress user.</p>
<p>Traditionally, app building has been limited to a select few developers who have the skills to program apps for the various mobile platforms. AppPresser turns this upside down by making it easy for anyone to build a native mobile app with WordPress, the publishing platform that is well-known for its user friendliness.</p>
<h3>How AppPresser Works</h3>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/create-publish-with-apppresser.jpg\" rel=\"prettyphoto[14136]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/create-publish-with-apppresser.jpg\" alt=\"create-publish-with-apppresser\" width=\"2204\" height=\"846\" class=\"aligncenter size-full wp-image-14151\" /></a></p>
<p>The <a href=\"http://wordpress.org/plugins/apppresser/\" target=\"_blank\">AppPresser Core Plugin</a> is free and available on WordPress.org. This plugin provides a foundation for creating native iOS and Android apps by integrating the following:</p>
<ul>
<li>Integrates Phonegap with WordPress, which exposes the <a href=\"http://docs.phonegap.com/en/3.2.0/index.html\" target=\"_blank\">Phonegap API</a></li>
<li>Allows you to use javascript (using the Phonegap API) to use native device features</li>
<li>Allows you to use other AppPresser plugins and themes to create an app</li>
<li>Adds a settings page with app-only homepage, menus, and theme settings</li>
</ul>
<p>However, it&#8217;s important to note that the plugin by itself does not build the app for you. From here you will need to add AppPresser themes or extensions to create your app. Then you&#8217;d require a <a href=\"http://apppresser.com/extensions/appbuild/\" target=\"_blank\">build service</a>, offered by AppPresser or Phonegap, before you can distribute your app to the iOS/Android app stores.</p>
<p><a href=\"http://apppresser.com/extensions/\" target=\"_blank\">Themes and extensions</a> make it possible for you to tap into device hardware, ie. camera, contacts, geolocation, and notifications. AppPresser is launching with an e-commerce bundle that turns a WordPress and WooCommerce-powered store into a native app. Single app licenses start at $249. Another option is the Agency bundle, priced at $499, which includes all AppPresser themes and extensions.</p>
<h3>The Future of WordPress-Powered App Creation</h3>
<p>The launch of AppPresser further demonstrates that WordPress is moving more towards becoming an application platform. The architecture underneath native app creation with WordPress is only now in its infancy and there are many more uncharted waters for developers to explore. A recent <a href=\"http://taptappress.com/\" target=\"_blank\">TapTapPress</a> article discusses opportunities for developers to go <a href=\"http://taptappress.com/apppresser-beyond-theme-switching/\" target=\"_blank\">beyond theme switching</a>, the method employed by AppPresser, and utilize template switching instead. It will be interesting to see how others approach WordPress-powered app creation.</p>
<p><a href=\"http://apppresser.com/\" target=\"_blank\">AppPresser</a> is making history by being the first to put native mobile app creation into the hands of your average WordPress user with no coding skills required. It has opened wide a new niche market in the WordPress ecosystem. The future is bright for developers who want to build and sell custom apps and app-creation services that are built around WordPress. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 07 Jan 2014 20:19:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:32;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"WPTavern: #ChatWP – Twitter Chat Devoted Exclusively To WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=14104\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:168:\"http://wptavern.com/chatwp-twitter-chat-devoted-exclusively-to-wordpress?utm_source=rss&utm_medium=rss&utm_campaign=chatwp-twitter-chat-devoted-exclusively-to-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1507:\"<p>On <strong>Tuesday January 14th, at 3:00PM</strong> Eastern <a title=\"http://www.chatwp.org/\" href=\"http://www.chatwp.org/\">ChatWP</a> will be hosting the first ever Twitter chat dedicated to WordPress. Twitter chats are structured conversations centered around a hashtag. This enables anyone who uses Twitter the chance to participate in the conversation. The first chat will be with special guest Jason Coleman, author of &#8220;<a title=\"http://shop.oreilly.com/product/0636920029380.do\" href=\"http://shop.oreilly.com/product/0636920029380.do\">Building Web Apps for WordPress</a>&#8221; and the developer of the &#8220;<a title=\"http://www.paidmembershipspro.com/\" href=\"http://www.paidmembershipspro.com/\">Paid Memberships Pro</a>&#8221; plugin.</p>
<blockquote class=\"twitter-tweet\" width=\"550\"><p>.<a href=\"https://twitter.com/jason_coleman\">@Jason_Coleman</a> will be sharing his experience developing membership sites, plugins, and more. Get your questions ready!</p>
<p>&mdash; chatwp (@chatwp) <a href=\"https://twitter.com/chatwp/statuses/419198259840561152\">January 3, 2014</a></p></blockquote>
<p></p>
<p>If you&#8217;re using Tweetdeck, you can create a new column to specifically search for tweets containing the <strong>#chatwp</strong> hashtag. This will make it easy to follow and participate in the conversation. Each month will feature a new special guest or topic. Chris Van Patten tells me that all future chats will take place at the same time on the 3rd Tuesday of every month.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 07 Jan 2014 18:38:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"Jeffro\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:33;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"WordPress.tv: Panel Discussion: WordPress Business Owners\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wordpress.tv/?p=28711\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"http://wordpress.tv/2014/01/07/panel-discussion-wordpress-business-owners/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:663:\"<div id=\"v-f8NdvNJK-1\" class=\"video-player\">
</div><br />  <a rel=\"nofollow\" href=\"http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/28711/\"><img alt=\"\" border=\"0\" src=\"http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/28711/\" /></a> <img alt=\"\" border=\"0\" src=\"http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=28711&subd=wptv&ref=&feed=1\" width=\"1\" height=\"1\" /><div><a href=\"http://wordpress.tv/2014/01/07/panel-discussion-wordpress-business-owners/\"><img alt=\"Panel Discussion: WordPress Business Owners\" src=\"http://videos.videopress.com/f8NdvNJK/video-a5cda6f700_std.original.jpg\" width=\"160\" height=\"120\" /></a></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 07 Jan 2014 14:32:17 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"WordPress.tv\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:34;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:92:\"WordPress.tv: Lisa Sabin-Wilson: Scoping Projects To Reduce Stress, Headaches and Angry Mobs\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wordpress.tv/?p=28707\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:108:\"http://wordpress.tv/2014/01/07/lisa-sabin-wilson-scoping-projects-to-reduce-stress-headaches-and-angry-mobs/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:738:\"<div id=\"v-lR4jSubr-1\" class=\"video-player\">
</div><br />  <a rel=\"nofollow\" href=\"http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/28707/\"><img alt=\"\" border=\"0\" src=\"http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/28707/\" /></a> <img alt=\"\" border=\"0\" src=\"http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=28707&subd=wptv&ref=&feed=1\" width=\"1\" height=\"1\" /><div><a href=\"http://wordpress.tv/2014/01/07/lisa-sabin-wilson-scoping-projects-to-reduce-stress-headaches-and-angry-mobs/\"><img alt=\"Lisa Sabin-Wilson: Scoping Projects To Reduce Stress, Headaches and Angry Mobs\" src=\"http://videos.videopress.com/lR4jSubr/video-cb90f227e4_scruberthumbnail_0.jpg\" width=\"160\" height=\"120\" /></a></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 07 Jan 2014 13:21:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"WordPress.tv\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:35;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"WPTavern: Mentor Others In The WordPress Community With WPMentor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=14070\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"http://wptavern.com/mentor-others-in-the-wordpress-community-with-wpmentor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3616:\"<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/WPMentorLogo.jpg\" rel=\"prettyphoto[14070]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/WPMentorLogo.jpg\" alt=\"WPMentor Logo\" width=\"339\" height=\"77\" class=\"alignright size-full wp-image-14096\" /></a>While WordPress has been around for over a decade, companies that are successfully making a business out of it are still very young. Companies like <a href=\"http://ithemes.com/\" title=\"http://ithemes.com/\">iThemes</a>, <a href=\"http://www.studiopress.com/\" title=\"http://www.studiopress.com/\">StudioPress</a>, <a href=\"http://headwaythemes.com/\" title=\"http://headwaythemes.com/\">HeadwayThemes</a>, and <a href=\"http://www.rocketgenius.com/\" title=\"http://www.rocketgenius.com/\">RocketGenius</a> are some of the few that come to mind when I think of successful, veteran WordPress companies. </p>
<p>Every day, there are individuals and groups working to become the next generation of successful WordPress businesses. It would be great if those new to this world of WordPress had a resource to tap into, a mentor so to speak to get advice on making the next step. Matt Medeiros of <a href=\"http://mattreport.com\" title=\"http://mattreport.com\">Mattreport.com</a> has launched a new website called <a href=\"http://wpmentor.org/\" title=\"http://wpmentor.org/\">WPMentor.org</a> that brings mentors and mentees together. </p>
<h3>For The Teacher and The Student</h3>
<p>Matt received so much positive feedback from <a href=\"http://mattreport.com/become-a-mentor/\" title=\"http://mattreport.com/become-a-mentor/\">his post about becoming a mentor</a> that he created an entire site dedicated to those who wanted to volunteer their time to help others. WP Mentor is for two types of people, mentors and mentees. The site works in a similar fashion to a jobs board. Mentors publish posts on the job board explaining what skills or situations they can help people with. Mentees interested in the job posting simply click the <strong>Apply For Job</strong> button and get in touch with the mentor. Mentees can also create a new job listing.</p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/WPMentorJobPosting.jpg\" rel=\"prettyphoto[14070]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/WPMentorJobPosting-500x425.jpg\" alt=\"WPMentor Job Posting\" width=\"500\" height=\"425\" class=\"aligncenter size-large wp-image-14082\" /></a> </p>
<p>There are no hard and fast rules in which both parties exchange communications or how best to work with one another. Those decisions have intentionally been left up to both individuals. The job board is powered by Mike Jolley&#8217;s <a href=\"http://mikejolley.com/projects/wp-job-manager/\" title=\"http://mikejolley.com/projects/wp-job-manager/\">WP Job Manager</a> plugin in case you&#8217;re looking to create a similar site. Once a job posting is published, Matt explains all you&#8217;ll have to do is log back in and see that the job is filled.</p>
<blockquote><p>Once you&#8217;re satisfied with your posting, you can log back in and say that the job is “filled”. Feel free to fill out as much or as little as the info needed per listing.</p></blockquote>
<h3>Interested To See Where This Goes</h3>
<p>The WordPress community definitely has its share of mentors and while we usually concentrate on ways to contribute to the WordPress.org project, mentoring a member of the community can have just as much if not more impact. Matt doesn&#8217;t know where his project will end up but I thank him for creating a new resource for those willing to share their specialized knowledge with others. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 06 Jan 2014 23:37:17 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"Jeffro\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:36;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"WPTavern: WordPress Core Trac Gets a Design Refresh, New Features and Enhancements\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=14057\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"http://wptavern.com/wordpress-core-trac-gets-a-design-refresh-new-features-and-enhancements\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4726:\"<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/trac-logo.png\" rel=\"prettyphoto[14057]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/trac-logo-150x150.png\" alt=\"trac-logo\" width=\"150\" height=\"150\" class=\"alignleft size-thumbnail wp-image-14087\" /></a>If you haven&#8217;t been by to visit the <a href=\"https://core.trac.wordpress.org/\" target=\"_blank\">WordPress Core Trac</a> lately, you&#8217;ll be delighted to find that a flurry of updates were made over the holidays. Andrew Nacin took some time to add new features, enhancements, and bug fixes to Trac during his break. This long list of tiny improvements adds up in the end to make WordPress development tools more useful for everyone and more approachable for new contributors.</p>
<h4>Refreshed Ticket Design</h4>
<p>One of the most visible changes is the refreshed ticket design. Nacin added larger Gravatars, more whitespace, a larger font size for the body and he also changed the typeface to Open Sans. </p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/trac-ticket.png\" rel=\"prettyphoto[14057]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/trac-ticket.png\" alt=\"trac-ticket\" width=\"822\" height=\"443\" class=\"aligncenter size-full wp-image-14068\" /></a></p>
<p>The design refresh makes Trac tickets more readable. If you&#8217;re a designer with a few ideas to touch up the ticket design, Nacin invites you to get in touch.</p>
<h4>New Features: Duplicate Ticket Suggestions and Cross-Referencing IRC Ticket Mentions</h4>
<p>In addition to the new design, he also added a new feature to offer duplicate ticket suggestions. When you create a ticket, it will use your title to search for other &#8220;possibly related tickets&#8221; to cut down on duplicates.</p>
<p>Another handy new addition is automatic cross-referencing IRC ticket mentions to track conversations and enhance record keeping:</p>
<blockquote><p>Whenever a ticket is referenced in #wordpress-dev, a link to the channel logs will be posted to the ticket. This ties conversations together and means that a discussion reached “per IRC discussion” is effortlessly documented. (As it is for record-keeping purposes, the comment doesn’t send a needless notification.)</p></blockquote>
<p>Here&#8217;s what that looks like:</p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/irc-mention.png\" rel=\"prettyphoto[14057]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/irc-mention.png\" alt=\"irc-mention\" width=\"558\" height=\"95\" class=\"aligncenter size-full wp-image-14074\" /></a></p>
<p>A quick summary of other exciting improvements includes:</p>
<ul>
<li><strong>Automatic image attachment previews:</strong> Images uploaded to tickets are now embedded inline</li>
<li><strong>No more HTTP authentication:</strong> Jon Cave wrote a Trac plugin that validates existing WordPress.org cookies. Nacin also ported over heartbeat-like authentication checks to Trac, so you won&#8217;t lose your comments if you get logged out.</li>
<li><strong>Comments column on reports:</strong> Main reports now include &#8220;comment count&#8221; as a sortable column.</li>
<li><strong>New “good-first-bug” workflow keyword:</strong> New <a href=\"http://make.wordpress.org/core/handbook/trac/keywords/\" target=\"_blank\">keyword</a> added to help identify tickets that are good starting points for new contributors. Also added the existing <em>ui-focus</em> and <em>docs-feedback</em> keywords to the dropdown.</li>
<li><strong>“Open Tickets With Commits Against Them”:</strong> To be used as a sign of in-progress tickets. Nacin&#8217;s new script finds these tickets and displays them on top of <a href=\"https://core.trac.wordpress.org/report/6\" target=\"_blank\">report 6</a>.</li>
<li><strong>Email address syncing:</strong> Your WordPress.org email address is now automatically synced to Trac for <a href=\"http://make.wordpress.org/core/2014/01/03/the-email-used-for-notifications-on-trac-is/\" target=\"_blank\">notification purposes</a>.</li>
</ul>
<p>Bug fixes mean that Trac RSS feeds are no longer broken. Fixes to the global WordPress.org header/footer make Trac responsive for mobile viewing. </p>
<p>There are quite a few enhancements and bug fixes not mentioned here that Nacin outlines in his <a href=\"http://make.wordpress.org/core/2014/01/06/lots-of-improvements-to-core-trac/\" target=\"_blank\">post</a>. The WordPress community is pretty lucky to have a developer like Andrew Nacin who makes Trac improvements as a form of holiday rest and relaxation. The new features and dropdowns for sorting will help heavy Trac users and beginners alike. Many thanks to Nacin and others who have contributed to improving WordPress Core Trac.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 06 Jan 2014 23:11:54 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:37;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"WPTavern: AcademiaThemes – WordPress Themes Specifically For Academia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=14049\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"http://wptavern.com/academiathemes-wordpress-themes-specifically-for-academia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4879:\"<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/AcademiaThemeslogo.jpg\" rel=\"prettyphoto[14049]\"><img class=\"alignright size-full wp-image-14051\" alt=\"Academia Themes Logo\" src=\"http://wptavern.com/wp-content/uploads/2014/01/AcademiaThemeslogo.jpg\" width=\"147\" height=\"92\" /></a>On January 1st, 2014 a brand new theme shop called <a title=\"http://www.academiathemes.com/\" href=\"http://www.academiathemes.com/\">AcademiaThemes</a> opened its doors for business. The new theme shop is operated by Dumitru Brinzan who also co-founded <a title=\"http://www.wpzoom.com/\" href=\"http://www.wpzoom.com/\">WPZoom.com</a>. This isn&#8217;t the first niche theme shop that he&#8217;s launched. He&#8217;s also the man behind <a title=\"http://www.hermesthemes.com/\" href=\"http://www.hermesthemes.com/\">HermesThemes</a>, a theme shop dedicated to hotels. I reached out to Dumitru to find out more information about his latest business venture.</p>
<p><strong>What inspired you to create a theme company squarely aimed at the academia sector?</strong></p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/AcademiaThemesUniversityTheme.jpg\" rel=\"prettyphoto[14049]\"><img class=\"aligncenter size-large wp-image-14054\" alt=\"Academia Themes University Theme\" src=\"http://wptavern.com/wp-content/uploads/2014/01/AcademiaThemesUniversityTheme-500x272.jpg\" width=\"500\" height=\"272\" /></a></p>
<p><em>In the past I have designed a couple of education WordPress themes, which customers enjoyed. This made me think that my design and development style could be a good fit for this sector.</em></p>
<p><strong>What lessons have you learned through the launch of HermesThemes that you&#8217;ll apply to AcademiaThemes?</strong></p>
<p><em>HermesThemes taught me a couple of things. The most important one is probably the difference in a customer&#8217;s psychology. The attitude towards a $199 product is much more respectful than towards a $50 product.</em></p>
<p><strong>Why have you decided to do everything on your own instead of tapping into ThemeForest to sell niche themes?</strong></p>
<p><em>ThemeForest doesn&#8217;t let you set your own price, which devalues an individual&#8217;s work. If the creator can&#8217;t price his own merchandise, then you are just an employee. I have added one theme to CreativeMarket though.</em></p>
<p><strong>How did you create the Staff Directory and Course areas found within AcademiaThemes?</strong></p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/AcademiaThemesStaffDirectory.jpg\" rel=\"prettyphoto[14049]\"><img class=\"aligncenter size-large wp-image-14055\" alt=\"Academia Themes Staff Directory\" src=\"http://wptavern.com/wp-content/uploads/2014/01/AcademiaThemesStaffDirectory-500x294.jpg\" width=\"500\" height=\"294\" /></a></p>
<p><em>Those blocks are created using custom page templates combined with custom post types. All of our themes include about 8-10 custom page templates each.</em></p>
<p><strong>Why did you decide to license AcademiaThemes under the GPL?</strong></p>
<p><em>Are there any other license options? :)</em></p>
<p><strong>What sets your themes apart from your competition?</strong></p>
<p><em>My focus is on fast and clear customer support. Just like HermesThemes, support is provided not just via a forum, but by email and Skype as well.</em></p>
<p><em>During regular hours most questions and emails are answered in 5-15 minutes, not many can beat that. Also, I want to try something new with AcademiaThemes: each theme purchase includes one hour of free customization services. So if a customer likes the theme but requires just some minor styling changes, there is no need to hire someone else to do it, everything will be done in-house.</em></p>
<p><strong>How did you come to the fixed price of $199 per theme?</strong></p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/AcademiaThemesPricing.jpg\" rel=\"prettyphoto[14049]\"><img class=\"aligncenter size-large wp-image-14056\" alt=\"Academia Themes Pricing\" src=\"http://wptavern.com/wp-content/uploads/2014/01/AcademiaThemesPricing-500x169.jpg\" width=\"500\" height=\"169\" /></a></p>
<p><em>The price is the same as at HermesThemes. It is not something that will fit everybody, but that is not the objective. With such a price, the themes will remain somewhat exclusive, and you can be sure that they won&#8217;t be used on other 10.000 websites.</em></p>
<p><strong>If there is ONE selling point you&#8217;d like everyone to know about AcademiaThemes, what would it be?</strong></p>
<p><em>I know how important customer support is, so I&#8217;m making sure that it is quick and reliable.</em></p>
<h3>What Do You Think Of His Themes?</h3>
<p>Looking at how Dumitru has set up his theme business, is there anything you see that he could improve upon to help him succeed? What do you think of the three themes available for AcademiaThemes?</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 06 Jan 2014 19:54:47 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"Jeffro\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:38;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"Akismet: Akismet + VaultPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"http://blog.akismet.com/?p=1204\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"http://blog.akismet.com/2014/01/06/akismet-vaultpress/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2018:\"<p>Looking forward to a hitch-free 2014?</p>
<p>Spam protection and loss prevention are on everyone&#8217;s list of must-have WordPress tools. We think they naturally go hand-in-hand &#8212; and today, we&#8217;re excited to announce that you can take care of both these essentials with a single subscription.</p>
<p>We&#8217;re pleased to offer a new bundle subscription that includes both the spam-zapping brilliance of Akismet Professional and the fantastic <a href=\"http://vaultpress.com/plans/\">VaultPress Lite service</a>, with its  daily backups, 30-day archive, and one-click automated restores.</p>
<p>Along with the uncompromising spam protection that Akismet provides, you can now guarantee the safety of all your WordPress content, from database tables and plugins to themes and uploads &#8212; with VaultPress, your entire WordPress installation is safe and sound. You can choose a monthly subscription (<strong>$9 per month</strong>), or save $15/year by opting for an annual subscription (<strong>$99</strong>). Separately, the subscriptions would run you $10 per month or $114 per year.</p>
<p>The signup and activation process is simple and seamless. Make it your New Year&#8217;s resolution to grab the bundle, and stop worrying about annoying spam, asteroid strikes, extraterrestrial attacks, or unintentional mistakes after those long nights of blogging. You can sign up on our <a href=\"http://akismet.com/plans/\">plans page</a>.</p>
<p>If you have any questions about the bundle, please feel free to get in touch with us via <a href=\"http://akismet.com/contact\">akismet.com/contact</a>. We&#8217;re always ready and happy to help.</p><br />  <a rel=\"nofollow\" href=\"http://feeds.wordpress.com/1.0/gocomments/akismet.wordpress.com/1204/\"><img alt=\"\" border=\"0\" src=\"http://feeds.wordpress.com/1.0/comments/akismet.wordpress.com/1204/\" /></a> <img alt=\"\" border=\"0\" src=\"http://stats.wordpress.com/b.gif?host=blog.akismet.com&blog=116920&post=1204&subd=akismet&ref=&feed=1\" width=\"1\" height=\"1\" />\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 06 Jan 2014 19:47:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Anthony\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:39;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"WPTavern: Aesop Story Engine: An Open Source WordPress Plugin For Storytelling\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=14003\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"http://wptavern.com/aesop-story-engine-an-open-source-wordpress-plugin-for-storytelling\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6470:\"<p>The <a href=\"http://aesopstories.com/story-engine/\" target=\"_blank\">Aesop Story Engine</a> is one of the most beautiful tools for WordPress that I&#8217;ve seen in a long time. Named for Aesop, the master story teller whose fables are woven into our cultural consciousness, this engine provides a powerful suite of multimedia storytelling tools. The Aesop Story Engine plugin was created to be a foundation for building feature-rich, interactive, long-form storytelling themes for WordPress. </p>
<p>The engine powers the <a href=\"http://aesopstories.com/\" target=\"_blank\">Aesop Hosted Storytelling</a> site where users can create stories for free. The Aesop development team has released it as an open source WordPress plugin, making it possible for you to add the same storytelling capabilities to your own website.</p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/story.png\" rel=\"prettyphoto[14003]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/story.png\" alt=\"story\" width=\"1600\" height=\"993\" class=\"aligncenter size-full wp-image-14014\" /></a></p>
<h3>12 Interactive Storytelling Components:</h3>
<p>Aesop Story Engine includes 12 Story Telling components for adding interactive elements to your content:</p>
<ul>
<li><strong>Audio</strong> &#8211; Display an audio player with support for MP3</li>
<li><strong>Video</strong> &#8211; Fullscreen video with support for Kickstarter, Viddler, YouTube, Vimeo, Daily Motion, and Blip.TV</li>
<li><strong>Content</strong> &#8211; Display a background image, background color, or can split the content into multiple magazine type columns</li>
<li><strong>Character</strong> &#8211; Display a character avatar, title, and small bio to help remind readers of key story characters</li>
<li><strong>Galleries</strong> &#8211; Create and manage unlimited story galleries displayed as a grid, a thumbnail gallery, or a stacked type gallery, with caption support</li>
<li><strong>Image</strong> &#8211; Displays an image and caption, with optional lightbox and optoinal offset so it hangs outside of the content column</li>
<li><strong>Locations</strong> &#8211; Showcase character travels with a map, add markers with custom messages</li>
<li><strong>Parallax</strong> &#8211; A fullwidth image component with caption and lightbox</li>
<li><strong>Quote</strong> &#8211; Display a fullwidth quote with large text, control the color and background</li>
<li><strong>Timeline</strong> &#8211; Create a story with a timeline that sticks to the bottom, works a bit like chapters</li>
<li><strong>Collections</strong> &#8211; Upload a PDF or image, that is shown to the user once they click the component</li>
<li><strong>Document Viewer</strong> &#8211; Meant to be used on a page of your site, and allows you to display stories from a specific collection (category)</li>
</ul>
<p>Each story is unique. Therefore, these components can be used multiple times and configured differently for each element. Check out the <a href=\"http://playground.aesopstories.com/\" target=\"_blank\">demo page</a> for multiple examples of the storytelling components in action.</p>
<h3>How Aesop Story Engine Works:</h3>
<p>The story engine plugin loads two files, a CSS file for basic styles and a JS file to power the interactive components. These two files are the core of the plugin and have a combined weight of just 33kb. Once you install the plugin, you&#8217;ll find a new &#8220;Add Component&#8221; button in the WordPress post editor. This launches a modal window where you can select and configure each component.</p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/ase-screenshot.png\" rel=\"prettyphoto[14003]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/ase-screenshot.png\" alt=\"ase-screenshot\" width=\"1200\" height=\"779\" class=\"aligncenter size-full wp-image-14008\" /></a></p>
<p>Configuration options continue further down the page for each element, all of which have a vast array of customization options such as text color, background color or image, alignment, width, height, captions and more.</p>
<p>This video demo gives a brief overview of the engine:</p>
<p><span class=\"embed-youtube\"></span></p>
<h3>A Beautiful Way to Tell a Story with WordPress</h3>
<p>As a child, your experience of reading fables was more probably more colorful and visceral than it likely is today. The Aesop Story Engine helps you to recreate a more vibrant story reading experience for your readers by enabling you to quickly build a captivating story with visual and multimedia components. Instead of one long block of text, your story can be brought to life with fullscreen  backgrounds, colorful images, characters, audio clips, maps and more. Essentially, the story telling engine gives you the ability to write with all of your senses.</p>
<p>Aesop Story Engine can be implemented with any WordPress theme. However, please be advised that your theme will dictate much of how these story elements are displayed. The plugin provides the functionality that adds and formats the basic components within your current theme. The story engine looks best when the theme has been designed with the components in mind. That said, there are probably very few themes that could match up with the demos. The team plans to make a sample WordPress child theme available soon, which will make working with the story engine a reality for more users.</p>
<p><a href=\"https://twitter.com/nphaskins\" target=\"_blank\">Nick Haskins</a>, the engine&#8217;s creator, was formerly the lead developer of <a href=\"http://modernfarmer.com/\" target=\"_blank\">ModernFarmer.com</a> where he integrated storytelling features to create big, visual posts. He created Aesop Story Engine to make it easy for anyone to build beautiful stories without having to know any code. The plugin is a fully functional beta and Haskins wants to know if there is any interest. </p>
<p>I think he&#8217;s on right track for providing an exciting new tool that will become indispensible for publishers. The New York Times recently showcased a beautiful collection of this trend in <a href=\"http://www.nytimes.com/newsgraphics/2013/12/30/year-in-interactive-storytelling/\" target=\"_blank\">2013: The Year in Interactive Storytelling</a>. Do you think it&#8217;s likely to continue in 2014? Would you be interested to use <a href=\"http://aesopstories.com/story-engine/\" target=\"_blank\">Aesop Story Engine</a> on your own site or in a client project?</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 06 Jan 2014 18:38:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:40;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"WordPress.tv: Bradley Jacobs: Composer: An Introduction To PHP Depedency Management\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wordpress.tv/?p=28326\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:99:\"http://wordpress.tv/2014/01/06/bradley-jacobs-composer-an-introduction-to-php-depedency-management/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:714:\"<div id=\"v-fH8M2FfK-1\" class=\"video-player\">
</div><br />  <a rel=\"nofollow\" href=\"http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/28326/\"><img alt=\"\" border=\"0\" src=\"http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/28326/\" /></a> <img alt=\"\" border=\"0\" src=\"http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=28326&subd=wptv&ref=&feed=1\" width=\"1\" height=\"1\" /><div><a href=\"http://wordpress.tv/2014/01/06/bradley-jacobs-composer-an-introduction-to-php-depedency-management/\"><img alt=\"Bradley Jacobs: Composer: An Introduction To PHP Depedency Management\" src=\"http://videos.videopress.com/fH8M2FfK/video-5c34aad92f_std.original.jpg\" width=\"160\" height=\"120\" /></a></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 06 Jan 2014 18:05:12 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"WordPress.tv\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:41;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"WordPress.tv: Sakin Shrestha: How To Get Your Theme On Top 15 Most Popular Downloads at WordPress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wordpress.tv/?p=28617\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:118:\"http://wordpress.tv/2014/01/06/sakin-shrestha-how-to-get-your-theme-on-top-15-most-popular-downloads-at-wordpress-org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:751:\"<div id=\"v-ttH1AkPS-1\" class=\"video-player\">
</div><br />  <a rel=\"nofollow\" href=\"http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/28617/\"><img alt=\"\" border=\"0\" src=\"http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/28617/\" /></a> <img alt=\"\" border=\"0\" src=\"http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=28617&subd=wptv&ref=&feed=1\" width=\"1\" height=\"1\" /><div><a href=\"http://wordpress.tv/2014/01/06/sakin-shrestha-how-to-get-your-theme-on-top-15-most-popular-downloads-at-wordpress-org/\"><img alt=\"Sakin Shrestha: How To Get Your Theme On Top 15 Most Popular Downloads at WordPress.org\" src=\"http://videos.videopress.com/ttH1AkPS/video-ad922da32d_std.original.jpg\" width=\"160\" height=\"120\" /></a></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 06 Jan 2014 14:55:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"WordPress.tv\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:42;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"WordPress.tv: John Eckman: Beyond Posts And Pages: Getting Chunky With WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wordpress.tv/?p=28252\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:96:\"http://wordpress.tv/2014/01/05/john-eckman-beyond-posts-and-pages-getting-chunky-with-wordpress/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:708:\"<div id=\"v-SIU8LUCE-1\" class=\"video-player\">
</div><br />  <a rel=\"nofollow\" href=\"http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/28252/\"><img alt=\"\" border=\"0\" src=\"http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/28252/\" /></a> <img alt=\"\" border=\"0\" src=\"http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=28252&subd=wptv&ref=&feed=1\" width=\"1\" height=\"1\" /><div><a href=\"http://wordpress.tv/2014/01/05/john-eckman-beyond-posts-and-pages-getting-chunky-with-wordpress/\"><img alt=\"John Eckman: Beyond Posts And Pages: Getting Chunky With WordPress\" src=\"http://videos.videopress.com/SIU8LUCE/video-f3f9b3f512_std.original.jpg\" width=\"160\" height=\"120\" /></a></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 05 Jan 2014 21:35:17 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"WordPress.tv\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:43;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:37:\"Matt: The Intrinsic Value of Blogging\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=43431\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"http://ma.tt/2014/01/intrinsic-blogging/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2983:\"<p>Blogging is harder than it used to be. We&#8217;ve gotten better at counting and worse at paying attention to what really counts. Every time I press Publish the post is <a href=\"http://jetpack.me/support/publicize/\">publicized</a> to Facebook, Twitter, LinkedIn, Path, and Google+, each with their own mechanisms for enumerating how much people like it.</p>
<p><img class=\"alignright size-full wp-image-43433\" src=\"http://i0.wp.com/s.ma.tt/files/2014/01/path.jpg?resize=189%2C44\" alt=\"path\" />None of those services except Path have a clickable way to dislike something, so if something isn&#8217;t great it&#8217;s usually met with silence. But sometimes something that is great is met with silence too if it doesn&#8217;t drop at the right time, have the right headline, or have the right tone to invite interaction. There is no predictable connection to the effort and thought you put into something and the response it receives, and every experienced blogger has a story of something they spend a few minutes on and <a href=\"https://twitter.com/photomatt/status/5257204277977089\">toss out casually</a> going viral, a one-hit wonder that makes your stats in future months and years puny in comparison.</p>
<p>Stats systems, <a href=\"http://jetpack.me/\">like Jetpack&#8217;s</a>, have gotten very good at telling me which post got how many visitors and where they came from, but it&#8217;s all anonymous and the numbers don&#8217;t really mean anything to me anymore. This is very discouraging, and at its most insidious causes people to deconstruct the elements of what makes something sharable and attempt to <a href=\"http://www.viralnova.com/\">artificially construct these information carbohydrates over and over</a>. (Visit that site and try not to click through any headlines — it&#8217;s tough.)</p>
<p>The antidote I’ve found for this is to write for only two people. First, write for yourself, both your present self whose thinking will be clarified by distilling an idea through writing and editing, and your future self who will be able to look back on these words and be reminded of the context in which they were written.</p>
<p>Second, write for a single person who you have in mind as the perfect person to read what you write, almost like a letter, even if they never will, or a person who you’re sure will read it because of a connection you have to them (hi Mom!). Even <a href=\"http://matt.wordpress.com/\">on my moblog</a> I have a frequent commenter who I’ll often keep in mind when posting a photo, curious to see her reaction.</p>
<p>This post might be ephemerally tweeted by dozens of avatars I might or might not recognize, accumulate a number in a database that represents the &#8220;hits&#8221; it had, and if I&#8217;m lucky might even get some comments, but when I get caught up in that the randomness of what becomes popular or generates commentary and what doesn&#8217;t it invariably leads me to write less. So blog just for two people.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 05 Jan 2014 20:03:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:44;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"WordPress.tv: Mohammad Jangda: Caching For Fun And Profit\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wordpress.tv/?p=28274\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"http://wordpress.tv/2014/01/05/mohammad-jangda-caching-for-fun-and-profit/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:663:\"<div id=\"v-QLiAogt7-1\" class=\"video-player\">
</div><br />  <a rel=\"nofollow\" href=\"http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/28274/\"><img alt=\"\" border=\"0\" src=\"http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/28274/\" /></a> <img alt=\"\" border=\"0\" src=\"http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=28274&subd=wptv&ref=&feed=1\" width=\"1\" height=\"1\" /><div><a href=\"http://wordpress.tv/2014/01/05/mohammad-jangda-caching-for-fun-and-profit/\"><img alt=\"Mohammad Jangda: Caching For Fun And Profit\" src=\"http://videos.videopress.com/QLiAogt7/video-b16109b75e_std.original.jpg\" width=\"160\" height=\"120\" /></a></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 05 Jan 2014 14:59:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"WordPress.tv\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:45;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"WordPress.tv: Dan Stolts: Blogging For Reach\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wordpress.tv/?p=28247\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"http://wordpress.tv/2014/01/04/dan-stolts-blogging-for-reach/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:637:\"<div id=\"v-7yJDqMVU-1\" class=\"video-player\">
</div><br />  <a rel=\"nofollow\" href=\"http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/28247/\"><img alt=\"\" border=\"0\" src=\"http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/28247/\" /></a> <img alt=\"\" border=\"0\" src=\"http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=28247&subd=wptv&ref=&feed=1\" width=\"1\" height=\"1\" /><div><a href=\"http://wordpress.tv/2014/01/04/dan-stolts-blogging-for-reach/\"><img alt=\"Dan Stolts: Blogging For Reach\" src=\"http://videos.videopress.com/7yJDqMVU/video-ac2f97693b_std.original.jpg\" width=\"160\" height=\"120\" /></a></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 04 Jan 2014 20:28:08 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"WordPress.tv\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:46;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"WordPress.tv: Brennen Byrne: Anatomy Of A WordPress Hack\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wordpress.tv/?p=28240\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"http://wordpress.tv/2014/01/04/brennen-byrne-anatomy-of-a-wordpress-hack/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:661:\"<div id=\"v-tIgBHrHn-1\" class=\"video-player\">
</div><br />  <a rel=\"nofollow\" href=\"http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/28240/\"><img alt=\"\" border=\"0\" src=\"http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/28240/\" /></a> <img alt=\"\" border=\"0\" src=\"http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=28240&subd=wptv&ref=&feed=1\" width=\"1\" height=\"1\" /><div><a href=\"http://wordpress.tv/2014/01/04/brennen-byrne-anatomy-of-a-wordpress-hack/\"><img alt=\"Brennen Byrne: Anatomy Of A WordPress Hack\" src=\"http://videos.videopress.com/tIgBHrHn/video-a42324773a_std.original.jpg\" width=\"160\" height=\"120\" /></a></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 04 Jan 2014 20:07:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"WordPress.tv\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:47;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"WPTavern: Cloudup Makes File Sharing Incredibly Easy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=13952\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"http://wptavern.com/cloudup-makes-file-sharing-incredibly-easy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7418:\"<p>Cloudup is a file sharing service that was acquired by Automattic on <strong>September 25th, 2013</strong>. Their goal is to make file sharing “<a title=\"https://cloudup.com/blog/cloudup-automattic\" href=\"https://cloudup.com/blog/cloudup-automattic\">simple and beautiful.</a>” Not having any experience with <a title=\"https://www.dropbox.com/\" href=\"https://www.dropbox.com/\">Dropbox</a>, Cloudup was amazingly easy to set up and start using. In the past, I used FTP to upload images I wanted to share to a folder I had access to. This was a cumbersome approach to file sharing but it worked.</p>
<h3>Installation Of The Cloudup App</h3>
<p>Cloudup supports Mac and Windows for the desktop while iOS and Android apps are available for mobile devices. The installer is 28MB in size which makes for a quick download. Once installed, you&#8217;ll need to link the app to your Cloudup account. </p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/CloudupApp.jpg\" rel=\"prettyphoto[13952]\"><img class=\"aligncenter size-full wp-image-13981\" alt=\"Cloudup After Account Has Been Linked\" src=\"http://wptavern.com/wp-content/uploads/2014/01/CloudupApp.jpg\" width=\"265\" height=\"238\" /></a></p>
<p>After the account has been linked, you can access the dashboard and preferences by clicking on the small Cloudup icon located within the Taskbar.</p>
<h3>Using Cloudup</h3>
<p>There are two primary ways to upload content. You can either drag files to the taskbar icon or click on the icon, then select <strong>Upload/Browse</strong>. When a file is uploaded, the app will automatically open the file in a new browser window and copy the unique URL to the clipboard for easy sharing. From within this browser window, you can choose whether the image is public or private, edit the image title, or add a password.</p>
<div id=\"attachment_13982\" class=\"wp-caption aligncenter\"><a href=\"http://wptavern.com/wp-content/uploads/2014/01/CloudupEditing.jpg\" rel=\"prettyphoto[13952]\"><img class=\"size-large wp-image-13982\" alt=\"Cloudup Editor After Uploading A File\" src=\"http://wptavern.com/wp-content/uploads/2014/01/CloudupEditing-500x494.jpg\" width=\"500\" height=\"494\" /></a><p class=\"wp-caption-text\">Cloudup Editor After Uploading A File</p></div>
<p>In its simplest form, it only takes two steps to share a file. The first is to upload it. The second is to paste the URL to whomever you want to have access to the file. Also, users don&#8217;t have to wait until the entire file is uploaded before sharing the URL.</p>
<h3>Free Accounts Limited To 1,000 Items</h3>
<div id=\"attachment_13983\" class=\"wp-caption aligncenter\"><a href=\"http://wptavern.com/wp-content/uploads/2014/01/CloudupFreeTier.jpg\" rel=\"prettyphoto[13952]\"><img class=\"size-large wp-image-13983\" alt=\"Cloudup Free Users Limited To 1,000 Items\" src=\"http://wptavern.com/wp-content/uploads/2014/01/CloudupFreeTier-500x341.jpg\" width=\"500\" height=\"341\" /></a><p class=\"wp-caption-text\">Cloudup Free Users Limited To 1,000 Items</p></div>
<p>New users are automatically placed into the free tier. This tier is the only one available at the moment and gives users 1,000 items. According to Matt Mullenweg in a <a title=\"http://techcrunch.com/2013/09/25/automattic-acquires-file-sharing-service-cloudup-to-build-faster-media-library-and-enable-co-editing/\" href=\"http://techcrunch.com/2013/09/25/automattic-acquires-file-sharing-service-cloudup-to-build-faster-media-library-and-enable-co-editing/\">Techcrunch article covering the acquisition</a>, there are no plans to monetize the service.</p>
<blockquote><p>We think Cloudup is something intrinsically useful to have in the world, and Automattic’s core businesses in WordPress.com, VIP, VaultPress, and Akismet are doing more than well enough for us as a company.</p></blockquote>
<p>Each item has a maximum size limit of 200MB. Depending on what you&#8217;re streaming, this is equal to 200GB of free space. This amount is incredibly generous.</p>
<h3>WordPress Media Library Improvements</h3>
<p>One of the most exciting things to come out of the <a title=\"http://en.blog.wordpress.com/2013/09/25/cloudup-joins-the-automattic-family/\" href=\"http://en.blog.wordpress.com/2013/09/25/cloudup-joins-the-automattic-family/\">acquisition announcement</a> was the fact that the WordPress media library would be improved by leaps and bounds thanks to Cloudup&#8217;s technology. One of the major improvements the team would be focusing on is collaborative editing. Similar to how Google docs functions, two authors would be able to work together on a single blog post at the same time using the visual editor.</p>
<h3>First WordPress.com Then Jetpack</h3>
<p>Users of WordPress.com will be the first to reap the benefits of any WordPress media library improvements. However, thanks to Jetpack, self-hosted WordPress users won&#8217;t be far behind. If you don&#8217;t use Jetpack, Cloudup can still be used by multiple devices without requiring WordPress.</p>
<h3>Will Cloudup Replace The WordPress Media Library?</h3>
<p>It&#8217;s hard for me to picture WordPress without the media library we&#8217;ve used for years. Replacing the media library on WordPress.com with Cloudup makes a lot of sense but I wonder how that change would translate to the self hosted version of WordPress. I asked Matt Mullenweg if Cloudup is something he can see replacing the WordPress media library or would there always be a need to keep things local? His response: &#8220;<em>I could see it replacing it</em>&#8220;.</p>
<p>What it means to replace the library and how it would work is still unknown. However, when I asked WPTavern Twitter followers what they thought about the idea of replacing the library with something hosted in the cloud, here are a few of their responses:</p>
<blockquote class=\"twitter-tweet\" width=\"550\"><p><a href=\"https://twitter.com/wptavern\">@wptavern</a> Do not want. Own your data = it\'s all on *your* server, not someone else\'s.</p>
<p>&mdash; Kim Parsell (@kimparsell) <a href=\"https://twitter.com/kimparsell/statuses/419265973275742209\">January 4, 2014</a></p></blockquote>
<p></p>
<blockquote class=\"twitter-tweet\" width=\"550\"><p><a href=\"https://twitter.com/wptavern\">@wptavern</a> sounds great especially if you ever need to move/migrate site</p>
<p>&mdash; Forge (@djforge) <a href=\"https://twitter.com/djforge/statuses/419264044298940416\">January 4, 2014</a></p></blockquote>
<p></p>
<blockquote class=\"twitter-tweet\" width=\"550\"><p><a href=\"https://twitter.com/wptavern\">@wptavern</a> Isn\'t this essentially a simple CDN? OK as an option/plugin, but not default.</p>
<p>&mdash; TJ List (@TJList) <a href=\"https://twitter.com/TJList/statuses/419266157263077377\">January 4, 2014</a></p></blockquote>
<p></p>
<p>Matt has been a vocal supporter of the idea to <em>own your own data</em>. It&#8217;s one of the many reasons so many people use WordPress so I doubt any media library replacement would go against that ethos.</p>
<h3>Conclusion</h3>
<p>Cloudup is awesome. It&#8217;s the simplest way to share files I&#8217;ve come across. It&#8217;s also lightning fast. After gaining access, consider installing the <a title=\"http://wptavern.com/new-plugin-adds-cloudup-oembed-support-for-wordpress\" href=\"http://wptavern.com/new-plugin-adds-cloudup-oembed-support-for-wordpress\">Cloudup oEmbed plugin</a> to show Cloudup hosted files within a post without using any special embed code.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 04 Jan 2014 01:44:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"Jeffro\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:48;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"WPTavern: Help Solve My WordPress Archive Conundrum\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=13958\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"http://wptavern.com/help-solve-my-wordpress-archive-conundrum\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2805:\"<p>During the past few days, I&#8217;ve been experimenting with a variety of WordPress plugins that specifically deal with the archiving of posts. Most allow archives to be generated via short code on a page while others are simply widgets with different configuration options. Some of the plugins I tested displayed every post ever published which not only inundated visitors, but was a bad use of resources on the server. I eventually found a plugin that had what I was looking for but since installing it, I&#8217;ve been faced with a conundrum.</p>
<h3>A Simple Way To Display Archives With Compact Archives Plugin</h3>
<p>I initially wanted to create an archive page so that all of our previous content would be easy to find. To me, WPTavern is a continuously updated archive of WordPress information. Making it easy to find all of the previous knowledge that&#8217;s been published within the past six years is important, especially since it&#8217;s all tied to one specific subject. For displaying the archive, I settled on the <a title=\"http://wordpress.org/plugins/compact-archives/\" href=\"http://wordpress.org/plugins/compact-archives/\">Compact Archives</a> plugin by Syed Balkhi and Noumaan Yaqoob. I like this plugin because it provides a few different ways via shortcode to display the entire archive of posts. The display is not pretty and doesn&#8217;t include images but then again, the main goal is to make it easy to browse the history of WordPress Tavern.</p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/CompactArchivesOnWPTavern.jpg\" rel=\"prettyphoto[13958]\"><img class=\"aligncenter size-large wp-image-13963\" alt=\"Compact Archive Plugin On WPTavern\" src=\"http://wptavern.com/wp-content/uploads/2014/01/CompactArchivesOnWPTavern-500x193.jpg\" width=\"500\" height=\"193\" /></a></p>
<h3>Search Box or Dedicated Archive Page</h3>
<p>Once I completed the archive page, I questioned whether or not the work was all for nothing. If you think about it, the search function of WordPress should be able to handle finding previously published content. As long as the search functionality provided relevant results, it would be the only form of archive retrieval needed. I decided to browse around to see how other large WordPress centric sites are archiving their content. Most of them don&#8217;t contain a dedicated archive page and handle everything through their search box.</p>
<h3>What Would You Do?</h3>
<p>So this is the conundrum I&#8217;m in, whether to create a dedicated archive page or just have visitors use the search box. I could use both methods but then they become a another page and plugin that needs to be maintained. There are two questions I have. The first is what would you do? The second, how do you archive a WordPress powered site with years of posts?</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 03 Jan 2014 22:30:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"Jeffro\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:49;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"WPTavern: WP Caregiver: 30+ WordPress Tweaks in 1 Convenient Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=13960\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"http://wptavern.com/wp-caregiver-30-wordpress-tweaks-in-1-convenient-plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3547:\"<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/onoff.jpg\" rel=\"prettyphoto[13960]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/onoff.jpg\" alt=\"onoff\" width=\"961\" height=\"291\" class=\"aligncenter size-full wp-image-13972\" /></a><a href=\"http://wordpress.org/plugins/wp-caregiver/\" target=\"_blank\">WP Caregiver</a> is a hidden gem of a plugin that arrived in the WordPress repository nearly six months ago. The plugin was recently featured on <a href=\"http://tidyrepo.com/\" target=\"_blank\">Tidy Repo</a>, a site dedicated to testing and curating WordPress plugins. Surprisingly, it has only received a handful of downloads, though it has the potential to replace multiple plugins that you may already have in place to handle small WordPress tweaks.</p>
<p>WP Caregiver is essentially a long list of light switches for core WordPress features and functions. It provides an organized way to turn these on or off at will and is separated into three tabbed categories: Frontend Features, Backend Features and System Information.</p>
<h4>System Information</h4>
<p>System Information lets you quickly view your server time, memory usage and SQL queries. It also gives you a quick and easy way to delete all of your post revisions and calculate the disc usage for your site.</p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/systeminformation.gif\" rel=\"prettyphoto[13960]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/systeminformation.gif\" alt=\"systeminformation\" width=\"771\" height=\"297\" class=\"aligncenter size-full wp-image-13961\" /></a></p>
<h4>Frontend Features</h4>
<p>The Frontend tweaks include the ability to easily remove a bunch of extras that many WordPress users don&#8217;t use, such as post relational links, website URL field in the comment form, the admin bar, and more. This screen also contains the ability to quickly enable the Open Graph tags generator. One really useful feature is the option to easily enable &#8220;Quick Maintenance Mode&#8221; with a checkbox. No need to install a separate plugin for creating a maintenance page. </p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/frontend.gif\" rel=\"prettyphoto[13960]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/frontend.gif\" alt=\"frontend\" width=\"771\" height=\"598\" class=\"aligncenter size-full wp-image-13964\" /></a></p>
<h4>Backend Features</h4>
<p>Backend tweaks include the ability to turn off update notifications, hide login error messages, enable excerpt field for pages, enable TinyMCE Editor for excerpt, enable categories for pages and many more handy little changes. The ability to customize the WordPress mail name and address from this screen is a convenient little addition.</p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2014/01/backend.gif\" rel=\"prettyphoto[13960]\"><img src=\"http://wptavern.com/wp-content/uploads/2014/01/backend.gif\" alt=\"backend\" width=\"771\" height=\"642\" class=\"aligncenter size-full wp-image-13965\" /></a></p>
<p>WordPress was made to be customized. Removing extras in the core features can help to make your custom WordPress installation leaner. The 30+ options offered in WP Caregiver cover many of the most commonly applied WordPress tweaks. Many thanks to the folks at <a href=\"http://blintdesign.hu/\" target=\"_blank\">Blint Design</a> for putting this handy collection of tweaks into one convenient plugin. Download <a href=\"http://wordpress.org/plugins/wp-caregiver/\" target=\"_blank\">WP Caregiver</a> for free from the WordPress plugin repository.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 03 Jan 2014 21:46:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";a:9:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Tue, 14 Jan 2014 14:35:33 GMT\";s:12:\"content-type\";s:8:\"text/xml\";s:14:\"content-length\";s:6:\"175747\";s:10:\"connection\";s:5:\"close\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:13:\"last-modified\";s:29:\"Tue, 14 Jan 2014 14:15:15 GMT\";s:4:\"x-nc\";s:11:\"HIT lax 249\";s:13:\"accept-ranges\";s:5:\"bytes\";}s:5:\"build\";s:14:\"20140110102336\";}","no");
INSERT INTO `wp_options` VALUES("375","rewrite_rules","a:73:{s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:20:\"(.?.+?)(/[0-9]+)?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:31:\".+?/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:41:\".+?/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:61:\".+?/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\".+?/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\".+?/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:26:\"(.+?)/([^/]+)/trackback/?$\";s:57:\"index.php?category_name=$matches[1]&name=$matches[2]&tb=1\";s:46:\"(.+?)/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:69:\"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]\";s:41:\"(.+?)/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:69:\"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]\";s:34:\"(.+?)/([^/]+)/page/?([0-9]{1,})/?$\";s:70:\"index.php?category_name=$matches[1]&name=$matches[2]&paged=$matches[3]\";s:41:\"(.+?)/([^/]+)/comment-page-([0-9]{1,})/?$\";s:70:\"index.php?category_name=$matches[1]&name=$matches[2]&cpage=$matches[3]\";s:26:\"(.+?)/([^/]+)(/[0-9]+)?/?$\";s:69:\"index.php?category_name=$matches[1]&name=$matches[2]&page=$matches[3]\";s:20:\".+?/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:30:\".+?/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:50:\".+?/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:45:\".+?/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:45:\".+?/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:38:\"(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:33:\"(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:26:\"(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:33:\"(.+?)/comment-page-([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&cpage=$matches[2]\";s:8:\"(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";}","yes");
INSERT INTO `wp_options` VALUES("317","_site_transient_timeout_browser_2a45585bf6fbca9e24972054edb9a714","1390161038","yes");
INSERT INTO `wp_options` VALUES("318","_site_transient_browser_2a45585bf6fbca9e24972054edb9a714","a:9:{s:8:\"platform\";s:7:\"Windows\";s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"31.0.1650.63\";s:10:\"update_url\";s:28:\"http://www.google.com/chrome\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/chrome.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/chrome.png\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("513","_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109","1389753333","no");
INSERT INTO `wp_options` VALUES("514","_transient_feed_b9388c83948825c1edaef0d856b7b109","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"
	
\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:72:\"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"WordPress Plugins » View: Most Popular\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"http://wordpress.org/plugins/browse/popular/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"WordPress Plugins » View: Most Popular\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 14 Jan 2014 14:28:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"http://bbpress.org/?v=1.1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:15:{i:0;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"WordPress SEO by Yoast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"http://wordpress.org/plugins/wordpress-seo/#post-8321\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 01 Jan 2009 20:34:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"8321@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:131:\"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using the WordPress SEO plugin by Yoast.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Joost de Valk\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"All in One SEO Pack\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"http://wordpress.org/plugins/all-in-one-seo-pack/#post-753\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 30 Mar 2007 20:08:18 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"753@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:126:\"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your Wordpress blog for Search Engines such as Google.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"uberdose\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Contact Form 7\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"http://wordpress.org/plugins/contact-form-7/#post-2141\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Aug 2007 12:45:03 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"2141@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"Just another contact form plugin. Simple but flexible.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Takayuki Miyoshi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"Jetpack by WordPress.com\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"http://wordpress.org/plugins/jetpack/#post-23862\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 20 Jan 2011 02:21:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"23862@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:104:\"Supercharge your WordPress site with powerful features previously only available to WordPress.com users.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Tim Moore\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Google XML Sitemaps\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"http://wordpress.org/plugins/google-sitemap-generator/#post-132\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2007 22:31:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"132@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:105:\"This plugin will generate a special XML sitemap which will help search engines to better index your blog.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"Arnee\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"WordPress Importer\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"http://wordpress.org/plugins/wordpress-importer/#post-18101\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 20 May 2010 17:42:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"18101@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Brian Colinger\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Akismet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"http://wordpress.org/plugins/akismet/#post-15\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2007 22:11:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"15@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"Akismet checks your comments against the Akismet web service to see if they look like spam or not.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"Advanced Custom Fields\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"http://wordpress.org/plugins/advanced-custom-fields/#post-25254\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 17 Mar 2011 04:07:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"25254@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:150:\"Fully customise WordPress edit screens with powerful fields. Boasting a professional interface and a powerfull API, it’s a must have for any web dev\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"elliotcondon\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Better WP Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"http://wordpress.org/plugins/better-wp-security/#post-21738\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 22 Oct 2010 22:06:05 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"21738@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:107:\"The easiest, most effective way to secure WordPress. Improve the security of any WordPress site in seconds.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Chris Wiegman\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"WP-Optimize\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"http://wordpress.org/plugins/wp-optimize/#post-8691\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 21 Jan 2009 04:28:48 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"8691@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:115:\"This simple but effective plugin allows you to clean up your WordPress database and optimize it without phpMyAdmin.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"ruhanirabin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Google Analyticator\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"http://wordpress.org/plugins/google-analyticator/#post-130\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2007 22:31:18 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"130@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:107:\"Adds the necessary JavaScript code to enable Google Analytics. Includes widgets for Analytics data display.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"cavemonkey50\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"WP-PageNavi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"http://wordpress.org/plugins/wp-pagenavi/#post-363\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2007 23:17:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"363@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"Adds a more advanced paging navigation interface.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Lester Chan\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"NextGEN Gallery\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"http://wordpress.org/plugins/nextgen-gallery/#post-1169\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 23 Apr 2007 20:08:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"1169@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:122:\"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 7.5 million downloads.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Alex Rabe\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"WooCommerce - excelling eCommerce\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"http://wordpress.org/plugins/woocommerce/#post-29860\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 05 Sep 2011 08:13:36 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"29860@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:97:\"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"WooThemes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"TinyMCE Advanced\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"http://wordpress.org/plugins/tinymce-advanced/#post-2082\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 27 Jun 2007 15:00:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"2082@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"Enables the advanced features of TinyMCE, the WordPress WYSIWYG editor.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Andrew Ozz\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:45:\"http://wordpress.org/plugins/rss/view/popular\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";a:7:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Tue, 14 Jan 2014 14:35:34 GMT\";s:12:\"content-type\";s:23:\"text/xml; charset=UTF-8\";s:10:\"connection\";s:5:\"close\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:13:\"last-modified\";s:29:\"Thu, 01 Jan 2009 20:34:44 GMT\";s:4:\"x-nc\";s:11:\"HIT lax 249\";}s:5:\"build\";s:14:\"20140110102336\";}","no");
INSERT INTO `wp_options` VALUES("489","_transient_timeout_plugin_slugs","1389798291","no");
INSERT INTO `wp_options` VALUES("490","_transient_plugin_slugs","a:10:{i:0;s:25:\"404-plugin/404-plugin.php\";i:1;s:19:\"akismet/akismet.php\";i:2;s:43:\"all-in-one-seo-pack/all_in_one_seo_pack.php\";i:3;s:41:\"better-wp-security/better-wp-security.php\";i:4;s:36:\"contact-form-7/wp-contact-form-7.php\";i:5;s:36:\"google-sitemap-generator/sitemap.php\";i:6;s:9:\"hello.php\";i:7;s:33:\"seo-automatic-links/seo-links.php\";i:8;s:52:\"wordpress-backup-to-dropbox/wp-backup-to-dropbox.php\";i:9;s:41:\"wordpress-importer/wordpress-importer.php\";}","no");
INSERT INTO `wp_options` VALUES("515","_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109","1389753333","no");
INSERT INTO `wp_options` VALUES("516","_transient_feed_mod_b9388c83948825c1edaef0d856b7b109","1389710133","no");
INSERT INTO `wp_options` VALUES("517","_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51","1389753333","no");
INSERT INTO `wp_options` VALUES("518","_transient_dash_4077549d03da2e451c8b5f002294ff51","<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'http://wordpress.org/news/2013/12/parker/\' title=\'Version 3.8 of WordPress, named “Parker” in honor of Charlie Parker, bebop innovator, is available for download or update in your WordPress dashboard. We hope you’ll think this is the most beautiful update yet. Introducing a modern new design WordPress has gotten a facelift. 3.8 brings a fresh new look to the entire admin dashboard. […]\'>WordPress 3.8 “Parker”</a> <span class=\"rss-date\">December 12, 2013</span><div class=\'rssSummary\'>Version 3.8 of WordPress, named “Parker” in honor of Charlie Parker, bebop innovator, is available for download or update in your WordPress dashboard. We hope you’ll think this is the most beautiful update yet. Introducing a modern new design WordPress has gotten a facelift. 3.8 brings a fresh new look to the entire admin dashboard. […]</div></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'http://wptavern.com/wp-updates-settings-an-admin-ui-for-configuring-wordpress-updates?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=wp-updates-settings-an-admin-ui-for-configuring-wordpress-updates\' title=\' One of the most exciting features in WordPress 3.7 was the ability for WordPress to stay up to date through automatic background updates. However, WordPress provides no easy way to change your update settings in the admin. Update settings require manual configuration in your wp-config.php file. WP Updates Settings is a new plugin released today, just in time for users to experiment using it with the upcoming WordPress 3.8.1 release. It provides a user interface for configuring update settings within the WordPress admin at Settings &gt;&gt; Updates.  The WP Updates Settings plugin includes a comprehensive list of update options, including translation files, as well as a few other extras such as contextual help:  Show/hide Updates notification Use default WordPress behaviors Enable/Disable Updates capabilities to Administrator users Set Major Core Automatic Background Updates Set Minor Core Automatic Background Updates Set Plugin Automatic Background Updates Set Theme Automatic Background Updates Set Translation files Automatic Background Updates Contextual Help Translation MO/PO files Clean uninstall  This plugin provides a good option for WordPress users who want to change some extra settings, such as adding in automatic theme updates, but are intimidated by editing the wp-config.php file.  If you try the plugin for awhile but want to uninstall it later, the default update settings are restored (core updates for minor versions). I’ve got it installed on a WordPress site to fully test whether my update settings are correctly recorded and implemented when WordPress 3.8.1 is released.  I’ll report back here when it is complete.  WP Updates Settings is the first plugin to provide a comprehensive UI for the most common selections users would otherwise define in wp-config.php. Download it for free from the WordPress plugin repository.\'>WPTavern: WP Updates Settings: An Admin UI For Configuring WordPress Updates</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/rant-on-wordpress-photography-themes-raises-concerns-for-consumers?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=rant-on-wordpress-photography-themes-raises-concerns-for-consumers\' title=\'Peter Adams who runs the site WP Photog has published a rant against Photography based WordPress themes that is filled with interesting things to consider, especially for consumers. The rant covers a lot of familiar territory such as themes using Custom Post Types instead of built-in functionality, using plugins for functionality instead of building it into the theme and finally, bypassing the gallery shortcode generated by the core of WordPress. There are a lot of reasons that these photography oriented Themes are so messed up. I could point to the fact that many Theme designers are web designers and not software engineers or to the fact that the incentive of premium theme designers is to lure buyers in with a good demo and not low long-term ownership costs. Or maybe it’s just ignorance on the part of Theme designers as to how WordPress really works and what the trade-offs really are. However, what I think is really going on here is that many of the proprietary workarounds found in these themes are trying to make up for the usability issues that new users face when starting out with WordPress  Peter says something in his post that I wish all theme designers/developers would get back to doing. “Keep Theme code dedicated to design and layout – not proprietary functionality.“ Many of the complaints against Photography specific themes are similar to the complaints Justin Tadlock mentioned in his ThemeForest experiment. From a consumer standpoint, Justin’s experiment proves how important it is to pick the right theme that won’t lock you in. I can’t imagine the common user knowing about shortcodes, post types, etc and factoring those into their decision on which theme to buy. As has been the case for a long time, choosing themes is like walking down the street looking at each storefront window to see which one looks best. Between all these dependencies with shortcodes, etc. someone could really screw themselves by investing time and money into a theme that does everything wrong. I feel like WordPress themes have gone through a giant cycle. A few years ago, themes contained awesome features that manipulated the display of content. Features that could have existed as plugins but were built into themes. Now we’re on the other side of the cycle where there is demand for theme developers to get rid of all the extra fat found within themes and to get back to the basics of the KISS principle (Keep It Simple, Stupid). While progressing through the cycle the WordPress theme ecosystem has become filled with themes that make a consumers life a living nightmare.  Justin Tadlock is doing his part to change things for the better. He joined the WordPress Theme Review team and is working with other members of the community to help straighten things out. But themes hosted on WordPress.org are just a tiny drop in the bucket compared to the commercial theme market, which doesn’t always follow the same theme guidelines. The WordPress theme world has dug themselves a deep hole that they might not be able to get out of. The unfortunate aspect in all of this is that consumers are the ones who lose the most.\'>WPTavern: Rant On WordPress Photography Themes Raises Concerns For Consumers</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/matt-mullenweg-takes-on-new-role-as-ceo-of-automattic?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=matt-mullenweg-takes-on-new-role-as-ceo-of-automattic\' title=\'photo credit: LeWeb 2010 After celebrating his 30th birthday this weekend, Matt Mullenweg announced that he has accepted a new role as CEO of Automattic.  Toni Schneider joined Automattic as CEO eight years ago in January 2006 and has helped to expand Automattic’s reach to close to a billion people each month. But Schneider isn’t saying goodbye. He’s swapping roles with Matt who will now become the new CEO, as Matt announced in his post this morning: Today we’re announcing publicly that Toni and I are switching jobs — he’s going to focus on some of Automattic’s new products, and I’m going to take on the role of CEO. Internally this isn’t a big change as our roles have always been quite fluid I asked Matt if the new role would change his relationship and involvement with WordPress.org, but it turns out that it won’t bring too big of a change to his day-to-day. He replied, “No major changes planned, as things are working very well already.”  The business of Automattic, which was started to help make WordPress simple to setup and host, is entirely separate from the open source project. Its growth has mirrored the success of the open source software, with WordPress currently powering 21.2% of the web.  Congrats to both Matt Mullenweg and Toni Schneider on their new positions in Automattic. With their flagship product WordPress.com now ranked 8th for traffic in the US, I’d say the two are working together quite successfully. \'>WPTavern: Matt Mullenweg Takes On New Role As CEO of Automattic</a></li></ul></div><div class=\"rss-widget\"><ul><li class=\'dashboard-news-plugin\'><span>Popular Plugin:</span> <a href=\'http://wordpress.org/plugins/better-wp-security/\' class=\'dashboard-news-plugin-link\'>Better WP Security</a></h5>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=better-wp-security&amp;_wpnonce=ee40d8e786&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'Better WP Security\'>Install</a>)</span></li></ul></div>","no");
INSERT INTO `wp_options` VALUES("249","_transient_random_seed","b870f1311e6b7e09d99c686d57999c88","yes");
INSERT INTO `wp_options` VALUES("167","theme_mods_twentyfourteen","a:1:{s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1389355530;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}","yes");
INSERT INTO `wp_options` VALUES("129","current_theme","Twenty Ten/KWMassage","yes");
INSERT INTO `wp_options` VALUES("130","theme_mods_twentytwelve","a:2:{i:0;b:0;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1389360639;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}","yes");
INSERT INTO `wp_options` VALUES("131","theme_switched","","yes");
INSERT INTO `wp_options` VALUES("132","recently_activated","a:1:{s:26:\"php-text-widget/plugin.php\";i:1389466337;}","yes");
INSERT INTO `wp_options` VALUES("133","_site_transient_timeout_wporg_theme_feature_list","1389362387","yes");
INSERT INTO `wp_options` VALUES("134","_site_transient_wporg_theme_feature_list","a:5:{s:6:\"Colors\";a:15:{i:0;s:5:\"black\";i:1;s:4:\"blue\";i:2;s:5:\"brown\";i:3;s:4:\"gray\";i:4;s:5:\"green\";i:5;s:6:\"orange\";i:6;s:4:\"pink\";i:7;s:6:\"purple\";i:8;s:3:\"red\";i:9;s:6:\"silver\";i:10;s:3:\"tan\";i:11;s:5:\"white\";i:12;s:6:\"yellow\";i:13;s:4:\"dark\";i:14;s:5:\"light\";}s:7:\"Columns\";a:6:{i:0;s:10:\"one-column\";i:1;s:11:\"two-columns\";i:2;s:13:\"three-columns\";i:3;s:12:\"four-columns\";i:4;s:12:\"left-sidebar\";i:5;s:13:\"right-sidebar\";}s:6:\"Layout\";a:3:{i:0;s:12:\"fixed-layout\";i:1;s:12:\"fluid-layout\";i:2;s:17:\"responsive-layout\";}s:8:\"Features\";a:20:{i:0;s:19:\"accessibility-ready\";i:1;s:8:\"blavatar\";i:2;s:10:\"buddypress\";i:3;s:17:\"custom-background\";i:4;s:13:\"custom-colors\";i:5;s:13:\"custom-header\";i:6;s:11:\"custom-menu\";i:7;s:12:\"editor-style\";i:8;s:21:\"featured-image-header\";i:9;s:15:\"featured-images\";i:10;s:15:\"flexible-header\";i:11;s:20:\"front-page-post-form\";i:12;s:19:\"full-width-template\";i:13;s:12:\"microformats\";i:14;s:12:\"post-formats\";i:15;s:20:\"rtl-language-support\";i:16;s:11:\"sticky-post\";i:17;s:13:\"theme-options\";i:18;s:17:\"threaded-comments\";i:19;s:17:\"translation-ready\";}s:7:\"Subject\";a:3:{i:0;s:7:\"holiday\";i:1;s:13:\"photoblogging\";i:2;s:8:\"seasonal\";}}","yes");
INSERT INTO `wp_options` VALUES("519","_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a","1389721005","yes");
INSERT INTO `wp_options` VALUES("520","_site_transient_poptags_40cd750bba9870f18aada2478b24840a","a:40:{s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";s:4:\"3898\";}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"Post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";s:4:\"2456\";}s:6:\"plugin\";a:3:{s:4:\"name\";s:6:\"plugin\";s:4:\"slug\";s:6:\"plugin\";s:5:\"count\";s:4:\"2344\";}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";s:4:\"1930\";}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";s:4:\"1856\";}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";s:4:\"1583\";}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";s:4:\"1329\";}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";s:4:\"1325\";}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";s:4:\"1310\";}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";s:4:\"1260\";}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";s:4:\"1225\";}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";s:4:\"1121\";}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";s:4:\"1000\";}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"Facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";s:3:\"982\";}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";s:3:\"974\";}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";s:3:\"950\";}s:9:\"wordpress\";a:3:{s:4:\"name\";s:9:\"wordpress\";s:4:\"slug\";s:9:\"wordpress\";s:5:\"count\";s:3:\"844\";}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";s:3:\"821\";}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";s:3:\"780\";}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";s:3:\"722\";}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";s:3:\"686\";}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";s:3:\"681\";}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";s:3:\"678\";}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";s:3:\"623\";}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"AJAX\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";s:3:\"615\";}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";s:3:\"595\";}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";s:3:\"572\";}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";s:3:\"570\";}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";s:3:\"541\";}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";s:3:\"539\";}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";s:3:\"530\";}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";s:3:\"522\";}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";s:3:\"506\";}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";s:3:\"505\";}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";s:3:\"471\";}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";s:3:\"458\";}s:5:\"stats\";a:3:{s:4:\"name\";s:5:\"stats\";s:4:\"slug\";s:5:\"stats\";s:5:\"count\";s:3:\"453\";}s:8:\"category\";a:3:{s:4:\"name\";s:8:\"category\";s:4:\"slug\";s:8:\"category\";s:5:\"count\";s:3:\"452\";}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";s:3:\"436\";}s:7:\"comment\";a:3:{s:4:\"name\";s:7:\"comment\";s:4:\"slug\";s:7:\"comment\";s:5:\"count\";s:3:\"432\";}}","yes");
INSERT INTO `wp_options` VALUES("138","aiosp_404_title_format","","yes");
INSERT INTO `wp_options` VALUES("531","_site_transient_update_plugins","O:8:\"stdClass\":3:{s:12:\"last_checked\";i:1389716375;s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}","yes");
INSERT INTO `wp_options` VALUES("140","aioseop_options","a:72:{s:9:\"aiosp_can\";s:2:\"on\";s:12:\"aiosp_donate\";s:0:\"\";s:16:\"aiosp_home_title\";s:0:\"\";s:22:\"aiosp_home_description\";s:0:\"\";s:19:\"aiosp_home_keywords\";s:0:\"\";s:23:\"aiosp_max_words_excerpt\";N;s:20:\"aiosp_rewrite_titles\";s:1:\"1\";s:23:\"aiosp_post_title_format\";s:27:\"%post_title% | %blog_title%\";s:23:\"aiosp_page_title_format\";s:27:\"%page_title% | %blog_title%\";s:27:\"aiosp_category_title_format\";s:31:\"%category_title% | %blog_title%\";s:26:\"aiosp_archive_title_format\";s:21:\"%date% | %blog_title%\";s:22:\"aiosp_tag_title_format\";s:20:\"%tag% | %blog_title%\";s:25:\"aiosp_search_title_format\";s:23:\"%search% | %blog_title%\";s:24:\"aiosp_description_format\";s:13:\"%description%\";s:22:\"aiosp_404_title_format\";s:33:\"Nothing found for %request_words%\";s:18:\"aiosp_paged_format\";s:14:\" - Part %page%\";s:20:\"aiosp_use_categories\";s:0:\"\";s:32:\"aiosp_dynamic_postspage_keywords\";s:2:\"on\";s:22:\"aiosp_category_noindex\";s:2:\"on\";s:18:\"aiosp_tags_noindex\";s:0:\"\";s:14:\"aiosp_cap_cats\";s:2:\"on\";s:27:\"aiosp_generate_descriptions\";s:2:\"on\";s:16:\"aiosp_debug_info\";N;s:20:\"aiosp_post_meta_tags\";s:0:\"\";s:20:\"aiosp_page_meta_tags\";s:0:\"\";s:20:\"aiosp_home_meta_tags\";s:0:\"\";s:13:\"aiosp_enabled\";s:1:\"1\";s:17:\"aiosp_enablecpost\";s:0:\"\";s:26:\"aiosp_use_tags_as_keywords\";s:2:\"on\";s:16:\"aiosp_seopostcol\";N;s:18:\"aiosp_seocustptcol\";N;s:21:\"aiosp_posttypecolumns\";a:2:{i:0;s:4:\"post\";i:1;s:4:\"page\";}s:12:\"aiosp_do_log\";s:0:\"\";s:14:\"aiosp_ex_pages\";s:0:\"\";s:28:\"aiosp_archive_author_noindex\";s:2:\"on\";s:26:\"aiosp_archive_date_noindex\";s:2:\"on\";s:11:\"aiosp_token\";s:30:\"4/XSsqxzpb0C_PprLQiZAZPEqVB0hZ\";s:12:\"aiosp_secret\";s:24:\"E-TL6mgLMWbadS1xgBbsddl4\";s:18:\"aiosp_access_token\";a:2:{s:11:\"oauth_token\";s:45:\"1/fsqDmkVlhGwCWbkfcFDMQLdS-3l_XPe1xP5qUwGGg3s\";s:18:\"oauth_token_secret\";s:24:\"QhqENpCnUn6TRUz5l0-rmSUW\";}s:14:\"aiosp_ga_token\";s:45:\"1/fsqDmkVlhGwCWbkfcFDMQLdS-3l_XPe1xP5qUwGGg3s\";s:19:\"aiosp_account_cache\";a:2:{s:2:\"ua\";a:1:{s:49:\"Google Analytics View (Profile) www.kwmassage.com\";a:1:{s:12:\"UA-6095192-5\";s:12:\"UA-6095192-5\";}}s:8:\"profiles\";a:1:{s:12:\"UA-6095192-5\";s:8:\"37322815\";}}s:20:\"aiosp_togglekeywords\";s:1:\"0\";s:20:\"aiosp_force_rewrites\";s:1:\"1\";s:24:\"aiosp_use_original_title\";s:1:\"0\";s:16:\"aiosp_cap_titles\";s:2:\"on\";s:25:\"aiosp_author_title_format\";s:23:\"%author% | %blog_title%\";s:19:\"aiosp_cpostadvanced\";s:1:\"0\";s:17:\"aiosp_cpostactive\";a:2:{i:0;s:4:\"post\";i:1;s:4:\"page\";}s:18:\"aiosp_cpostnoindex\";s:0:\"\";s:19:\"aiosp_cpostnofollow\";s:0:\"\";s:17:\"aiosp_cposttitles\";s:0:\"\";s:15:\"aiosp_admin_bar\";s:2:\"on\";s:23:\"aiosp_custom_menu_order\";s:2:\"on\";s:19:\"aiosp_google_verify\";s:0:\"\";s:17:\"aiosp_bing_verify\";s:0:\"\";s:22:\"aiosp_pinterest_verify\";s:0:\"\";s:22:\"aiosp_google_publisher\";s:34:\"https://plus.google.com/+Kwmassage\";s:28:\"aiosp_google_disable_profile\";s:0:\"\";s:20:\"aiosp_google_connect\";s:0:\"\";s:25:\"aiosp_google_analytics_id\";s:12:\"UA-6095192-5\";s:32:\"aiosp_ga_use_universal_analytics\";s:0:\"\";s:15:\"aiosp_ga_domain\";s:0:\"\";s:21:\"aiosp_ga_multi_domain\";s:0:\"\";s:28:\"aiosp_ga_display_advertising\";s:0:\"\";s:22:\"aiosp_ga_exclude_users\";s:0:\"\";s:29:\"aiosp_ga_track_outbound_links\";s:0:\"\";s:20:\"aiosp_search_noindex\";s:0:\"\";s:33:\"aiosp_hide_paginated_descriptions\";s:0:\"\";s:20:\"aiosp_unprotect_meta\";s:0:\"\";s:21:\"aiosp_front_meta_tags\";s:0:\"\";s:29:\"aiosp_attachment_title_format\";s:27:\"%post_title% | %blog_title%\";s:37:\"aiosp_wpcf7_contact_form_title_format\";s:27:\"%post_title% | %blog_title%\";}","yes");
INSERT INTO `wp_options` VALUES("168","SEOLinks","a:29:{s:4:\"post\";s:2:\"on\";s:8:\"postself\";s:0:\"\";s:4:\"page\";s:2:\"on\";s:8:\"pageself\";s:0:\"\";s:7:\"comment\";s:0:\"\";s:14:\"excludeheading\";s:2:\"on\";s:6:\"lposts\";s:2:\"on\";s:6:\"lpages\";s:2:\"on\";s:5:\"lcats\";s:0:\"\";s:5:\"ltags\";s:0:\"\";s:6:\"ignore\";s:6:\"about,\";s:10:\"ignorepost\";s:7:\"contact\";s:8:\"maxlinks\";i:3;s:9:\"maxsingle\";i:1;s:8:\"minusage\";i:1;s:9:\"customkey\";s:0:\"\";s:30:\"customkey_preventduplicatelink\";b:0;s:13:\"customkey_url\";s:0:\"\";s:19:\"customkey_url_value\";s:0:\"\";s:22:\"customkey_url_datetime\";s:0:\"\";s:6:\"nofoln\";s:0:\"\";s:6:\"nofolo\";s:0:\"\";s:6:\"blankn\";s:0:\"\";s:6:\"blanko\";s:0:\"\";s:10:\"onlysingle\";s:2:\"on\";s:8:\"casesens\";s:0:\"\";s:9:\"allowfeed\";s:0:\"\";s:12:\"maxsingleurl\";s:1:\"1\";s:6:\"notice\";i:0;}","yes");
INSERT INTO `wp_options` VALUES("232","_transient_timeout_aioseop_oauth_current","1389425089","no");
INSERT INTO `wp_options` VALUES("233","_transient_aioseop_oauth_current","1","no");
INSERT INTO `wp_options` VALUES("144","wpcf7","a:1:{s:7:\"version\";s:3:\"3.6\";}","yes");
INSERT INTO `wp_options` VALUES("214","_site_transient_browser_6d44eab61dcf5b1f0e6fa8f6595ee1bc","a:9:{s:8:\"platform\";s:7:\"Windows\";s:4:\"name\";N;s:7:\"version\";N;s:10:\"update_url\";s:0:\"\";s:7:\"img_src\";s:0:\"\";s:11:\"img_src_ssl\";s:0:\"\";s:15:\"current_version\";s:0:\"\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("150","_site_transient_timeout_popular_importers_en_US","1389526700","yes");
INSERT INTO `wp_options` VALUES("151","_site_transient_popular_importers_en_US","a:2:{s:9:\"importers\";a:8:{s:7:\"blogger\";a:4:{s:4:\"name\";s:7:\"Blogger\";s:11:\"description\";s:86:\"Install the Blogger importer to import posts, comments, and users from a Blogger blog.\";s:11:\"plugin-slug\";s:16:\"blogger-importer\";s:11:\"importer-id\";s:7:\"blogger\";}s:9:\"wpcat2tag\";a:4:{s:4:\"name\";s:29:\"Categories and Tags Converter\";s:11:\"description\";s:109:\"Install the category/tag converter to convert existing categories to tags or tags to categories, selectively.\";s:11:\"plugin-slug\";s:18:\"wpcat2tag-importer\";s:11:\"importer-id\";s:9:\"wpcat2tag\";}s:11:\"livejournal\";a:4:{s:4:\"name\";s:11:\"LiveJournal\";s:11:\"description\";s:82:\"Install the LiveJournal importer to import posts from LiveJournal using their API.\";s:11:\"plugin-slug\";s:20:\"livejournal-importer\";s:11:\"importer-id\";s:11:\"livejournal\";}s:11:\"movabletype\";a:4:{s:4:\"name\";s:24:\"Movable Type and TypePad\";s:11:\"description\";s:99:\"Install the Movable Type importer to import posts and comments from a Movable Type or TypePad blog.\";s:11:\"plugin-slug\";s:20:\"movabletype-importer\";s:11:\"importer-id\";s:2:\"mt\";}s:4:\"opml\";a:4:{s:4:\"name\";s:8:\"Blogroll\";s:11:\"description\";s:61:\"Install the blogroll importer to import links in OPML format.\";s:11:\"plugin-slug\";s:13:\"opml-importer\";s:11:\"importer-id\";s:4:\"opml\";}s:3:\"rss\";a:4:{s:4:\"name\";s:3:\"RSS\";s:11:\"description\";s:58:\"Install the RSS importer to import posts from an RSS feed.\";s:11:\"plugin-slug\";s:12:\"rss-importer\";s:11:\"importer-id\";s:3:\"rss\";}s:6:\"tumblr\";a:4:{s:4:\"name\";s:6:\"Tumblr\";s:11:\"description\";s:84:\"Install the Tumblr importer to import posts &amp; media from Tumblr using their API.\";s:11:\"plugin-slug\";s:15:\"tumblr-importer\";s:11:\"importer-id\";s:6:\"tumblr\";}s:9:\"wordpress\";a:4:{s:4:\"name\";s:9:\"WordPress\";s:11:\"description\";s:130:\"Install the WordPress importer to import posts, pages, comments, custom fields, categories, and tags from a WordPress export file.\";s:11:\"plugin-slug\";s:18:\"wordpress-importer\";s:11:\"importer-id\";s:9:\"wordpress\";}}s:10:\"translated\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("439","category_children","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("159","sm_options","a:58:{s:18:\"sm_b_prio_provider\";s:41:\"GoogleSitemapGeneratorPrioByCountProvider\";s:13:\"sm_b_filename\";s:11:\"sitemap.xml\";s:10:\"sm_b_debug\";b:1;s:8:\"sm_b_xml\";b:1;s:9:\"sm_b_gzip\";b:1;s:9:\"sm_b_ping\";b:1;s:14:\"sm_b_pingyahoo\";b:0;s:13:\"sm_b_yahookey\";s:0:\"\";s:12:\"sm_b_pingask\";b:1;s:12:\"sm_b_pingmsn\";b:1;s:19:\"sm_b_manual_enabled\";b:0;s:17:\"sm_b_auto_enabled\";b:1;s:15:\"sm_b_auto_delay\";b:1;s:15:\"sm_b_manual_key\";s:32:\"399b1e9c18b13f5ca05164e9aac2787d\";s:11:\"sm_b_memory\";s:0:\"\";s:9:\"sm_b_time\";i:-1;s:14:\"sm_b_max_posts\";i:-1;s:13:\"sm_b_safemode\";b:0;s:18:\"sm_b_style_default\";b:1;s:10:\"sm_b_style\";s:0:\"\";s:11:\"sm_b_robots\";b:1;s:12:\"sm_b_exclude\";a:0:{}s:17:\"sm_b_exclude_cats\";a:0:{}s:18:\"sm_b_location_mode\";s:4:\"auto\";s:20:\"sm_b_filename_manual\";s:0:\"\";s:19:\"sm_b_fileurl_manual\";s:0:\"\";s:10:\"sm_in_home\";b:1;s:11:\"sm_in_posts\";b:1;s:15:\"sm_in_posts_sub\";b:0;s:11:\"sm_in_pages\";b:1;s:10:\"sm_in_cats\";b:0;s:10:\"sm_in_arch\";b:0;s:10:\"sm_in_auth\";b:0;s:10:\"sm_in_tags\";b:0;s:9:\"sm_in_tax\";a:0:{}s:13:\"sm_in_lastmod\";b:1;s:10:\"sm_cf_home\";s:5:\"daily\";s:11:\"sm_cf_posts\";s:7:\"monthly\";s:11:\"sm_cf_pages\";s:6:\"weekly\";s:10:\"sm_cf_cats\";s:6:\"weekly\";s:10:\"sm_cf_auth\";s:6:\"weekly\";s:15:\"sm_cf_arch_curr\";s:5:\"daily\";s:14:\"sm_cf_arch_old\";s:6:\"yearly\";s:10:\"sm_cf_tags\";s:6:\"weekly\";s:10:\"sm_pr_home\";d:1;s:11:\"sm_pr_posts\";d:0.59999999999999997779553950749686919152736663818359375;s:15:\"sm_pr_posts_min\";d:0.200000000000000011102230246251565404236316680908203125;s:11:\"sm_pr_pages\";d:0.59999999999999997779553950749686919152736663818359375;s:10:\"sm_pr_cats\";d:0.299999999999999988897769753748434595763683319091796875;s:10:\"sm_pr_arch\";d:0.299999999999999988897769753748434595763683319091796875;s:10:\"sm_pr_auth\";d:0.299999999999999988897769753748434595763683319091796875;s:10:\"sm_pr_tags\";d:0.299999999999999988897769753748434595763683319091796875;s:12:\"sm_i_donated\";b:0;s:17:\"sm_i_hide_donated\";b:0;s:17:\"sm_i_install_date\";i:1389354503;s:14:\"sm_i_hide_note\";b:0;s:15:\"sm_i_hide_works\";b:0;s:16:\"sm_i_hide_donors\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("164","sm_status","O:28:\"GoogleSitemapGeneratorStatus\":24:{s:10:\"_startTime\";d:1389644709.6902630329132080078125;s:8:\"_endTime\";d:1389644710.1265599727630615234375;s:11:\"_hasChanged\";b:1;s:12:\"_memoryUsage\";i:27000832;s:9:\"_lastPost\";i:15;s:9:\"_lastTime\";d:1389644709.7945690155029296875;s:8:\"_usedXml\";b:1;s:11:\"_xmlSuccess\";b:1;s:8:\"_xmlPath\";s:38:\"/home/kwma2903/public_html/sitemap.xml\";s:7:\"_xmlUrl\";s:36:\"http://www.kwmassage.com/sitemap.xml\";s:8:\"_usedZip\";b:1;s:11:\"_zipSuccess\";b:1;s:8:\"_zipPath\";s:41:\"/home/kwma2903/public_html/sitemap.xml.gz\";s:7:\"_zipUrl\";s:39:\"http://www.kwmassage.com/sitemap.xml.gz\";s:11:\"_usedGoogle\";b:1;s:10:\"_googleUrl\";s:102:\"http://www.google.com/webmasters/sitemaps/ping?sitemap=http%3A%2F%2Fwww.kwmassage.com%2Fsitemap.xml.gz\";s:15:\"_gooogleSuccess\";b:1;s:16:\"_googleStartTime\";d:1389644709.796555042266845703125;s:14:\"_googleEndTime\";d:1389644710.0167310237884521484375;s:8:\"_usedMsn\";b:1;s:7:\"_msnUrl\";s:95:\"http://www.bing.com/webmaster/ping.aspx?siteMap=http%3A%2F%2Fwww.kwmassage.com%2Fsitemap.xml.gz\";s:11:\"_msnSuccess\";b:1;s:13:\"_msnStartTime\";d:1389644710.0175650119781494140625;s:11:\"_msnEndTime\";d:1389644710.1257650852203369140625;}","no");
INSERT INTO `wp_options` VALUES("202","_site_transient_browser_043122d71f0e1c9aa31b4150c975ea1b","a:9:{s:8:\"platform\";s:7:\"Windows\";s:4:\"name\";s:7:\"Firefox\";s:7:\"version\";s:4:\"26.0\";s:10:\"update_url\";s:23:\"http://www.firefox.com/\";s:7:\"img_src\";s:50:\"http://s.wordpress.org/images/browsers/firefox.png\";s:11:\"img_src_ssl\";s:49:\"https://wordpress.org/images/browsers/firefox.png\";s:15:\"current_version\";s:2:\"16\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("165","theme_mods_KWMassage","a:7:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:0;}s:16:\"background_color\";s:0:\"\";s:16:\"background_image\";s:0:\"\";s:17:\"background_repeat\";s:6:\"repeat\";s:21:\"background_position_x\";s:4:\"left\";s:21:\"background_attachment\";s:5:\"fixed\";}","yes");
INSERT INTO `wp_options` VALUES("183","nav_menu_options","a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}","yes");
INSERT INTO `wp_options` VALUES("201","_site_transient_timeout_browser_043122d71f0e1c9aa31b4150c975ea1b","1389986451","yes");
INSERT INTO `wp_options` VALUES("166","theme_mods_twentythirteen","a:2:{i:0;b:0;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1389355503;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}}}}","yes");
INSERT INTO `wp_options` VALUES("213","_site_transient_timeout_browser_6d44eab61dcf5b1f0e6fa8f6595ee1bc","1390025542","yes");
INSERT INTO `wp_options` VALUES("171","theme_mods_6261","a:2:{i:0;b:0;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1389356085;s:4:\"data\";a:7:{s:19:\"wp_inactive_widgets\";a:0:{}s:19:\"primary-widget-area\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:21:\"secondary-widget-area\";a:0:{}s:24:\"first-footer-widget-area\";a:0:{}s:25:\"second-footer-widget-area\";N;s:24:\"third-footer-widget-area\";N;s:25:\"fourth-footer-widget-area\";N;}}}","yes");
INSERT INTO `wp_options` VALUES("174","theme_mods_kwmassage-newone","a:2:{i:0;b:0;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1389360671;s:4:\"data\";a:7:{s:19:\"wp_inactive_widgets\";a:0:{}s:19:\"primary-widget-area\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:21:\"secondary-widget-area\";a:0:{}s:24:\"first-footer-widget-area\";a:0:{}s:25:\"second-footer-widget-area\";N;s:24:\"third-footer-widget-area\";N;s:25:\"fourth-footer-widget-area\";N;}}}","yes");
INSERT INTO `wp_options` VALUES("524","wpb2d-init-errors","","no");
INSERT INTO `wp_options` VALUES("525","wpb2d-premium-extensions","a:0:{}","no");
INSERT INTO `wp_options` VALUES("526","wordpress_api_key","a2a142a16371","yes");
INSERT INTO `wp_options` VALUES("527","akismet_discard_month","true","yes");
INSERT INTO `wp_options` VALUES("528","akismet_show_user_comments_approved","true","yes");
INSERT INTO `wp_options` VALUES("529","akismet_available_servers","a:4:{s:12:\"192.0.80.246\";b:1;s:12:\"66.135.58.61\";b:1;s:12:\"66.135.58.62\";b:1;s:12:\"192.0.80.244\";b:1;}","yes");
INSERT INTO `wp_options` VALUES("530","akismet_connectivity_time","1389710546","yes");
INSERT INTO `wp_options` VALUES("532","bit51_bwps_data","a:2:{s:7:\"version\";s:4:\"3064\";s:13:\"activatestamp\";i:1389711890;}","yes");
INSERT INTO `wp_options` VALUES("533","bit51_bwps","a:74:{s:10:\"bu_banlist\";s:1:\"
\";s:12:\"id_whitelist\";s:0:\"\";s:13:\"st_writefiles\";i:1;s:17:\"initial_filewrite\";i:1;s:14:\"ssl_forcelogin\";s:1:\"0\";s:14:\"ssl_forceadmin\";s:1:\"0\";s:12:\"ssl_frontend\";i:1;s:14:\"initial_backup\";i:1;s:10:\"am_enabled\";s:1:\"0\";s:7:\"am_type\";s:1:\"0\";s:12:\"am_startdate\";s:1:\"1\";s:10:\"am_enddate\";s:1:\"1\";s:12:\"am_starttime\";s:1:\"1\";s:10:\"am_endtime\";s:1:\"1\";s:12:\"backup_email\";s:1:\"1\";s:19:\"backup_emailaddress\";s:0:\"\";s:11:\"backup_time\";s:1:\"1\";s:15:\"backup_interval\";s:1:\"1\";s:14:\"backup_enabled\";s:1:\"0\";s:11:\"backup_last\";i:1389716386;s:11:\"backup_next\";s:0:\"\";s:17:\"backups_to_retain\";s:2:\"10\";s:10:\"bu_enabled\";s:1:\"0\";s:11:\"bu_banagent\";s:0:\"\";s:12:\"bu_blacklist\";i:1;s:10:\"hb_enabled\";s:1:\"0\";s:8:\"hb_login\";s:5:\"login\";s:11:\"hb_register\";s:8:\"register\";s:8:\"hb_admin\";s:5:\"admin\";s:6:\"hb_key\";s:0:\"\";s:10:\"ll_enabled\";i:1;s:18:\"ll_maxattemptshost\";s:1:\"5\";s:18:\"ll_maxattemptsuser\";s:2:\"10\";s:16:\"ll_checkinterval\";s:1:\"5\";s:12:\"ll_banperiod\";s:2:\"15\";s:14:\"ll_blacklistip\";s:1:\"1\";s:23:\"ll_blacklistipthreshold\";s:1:\"3\";s:14:\"ll_emailnotify\";s:1:\"1\";s:15:\"ll_emailaddress\";s:0:\"\";s:10:\"id_enabled\";i:1;s:14:\"id_emailnotify\";s:1:\"1\";s:16:\"id_checkinterval\";s:1:\"5\";s:12:\"id_threshold\";s:2:\"20\";s:12:\"id_banperiod\";s:2:\"15\";s:14:\"id_blacklistip\";s:1:\"0\";s:23:\"id_blacklistipthreshold\";s:1:\"3\";s:15:\"id_emailaddress\";s:0:\"\";s:14:\"id_fileenabled\";s:1:\"0\";s:18:\"id_fileemailnotify\";s:1:\"1\";s:19:\"id_filedisplayerror\";s:1:\"1\";s:19:\"id_fileemailaddress\";s:0:\"\";s:14:\"id_specialfile\";s:0:\"\";s:12:\"id_fileincex\";s:1:\"1\";s:16:\"id_filechecktime\";s:0:\"\";s:11:\"st_ht_files\";i:1;s:14:\"st_ht_browsing\";i:1;s:13:\"st_ht_request\";i:1;s:11:\"st_ht_query\";i:1;s:13:\"st_ht_foreign\";i:1;s:12:\"st_generator\";i:1;s:11:\"st_manifest\";i:1;s:10:\"st_edituri\";i:0;s:11:\"st_themenot\";i:1;s:12:\"st_pluginnot\";i:1;s:10:\"st_corenot\";i:1;s:17:\"st_enablepassword\";i:1;s:11:\"st_passrole\";s:6:\"author\";s:13:\"st_loginerror\";i:1;s:11:\"st_fileperm\";i:1;s:10:\"st_comment\";i:1;s:16:\"st_randomversion\";i:1;s:10:\"st_longurl\";i:1;s:11:\"st_fileedit\";i:0;s:14:\"oneclickchosen\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("535","_transient_timeout_feed_761bc2b7ca033de73fa7b3a5a0ffb39a","1389755098","no");
INSERT INTO `wp_options` VALUES("536","_transient_feed_761bc2b7ca033de73fa7b3a5a0ffb39a","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:50:\"
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"iThemes » WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"http://ithemes.com\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"Your one-stop shop for WordPress themes, plugins and training.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 13 Jan 2014 23:31:29 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"Hide Member Content With Shortcodes – New in Exchange Membership Add-on\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"http://ithemes.com/2014/01/08/hide-wordpress-member-content-shortcodes-in-exchange/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:92:\"http://ithemes.com/2014/01/08/hide-wordpress-member-content-shortcodes-in-exchange/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 08 Jan 2014 21:49:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:8:\"Exchange\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:19:\"WordPress Ecommerce\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:20:\"WordPress Membership\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"http://ithemes.com/?p=21056\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:621:\"<p>The latest version of the Exchange Membership Add-on (our WordPress Membership plugin) now includes a new feature — the ability to display member and non-member content on the same WordPress page or post. By using new built-in (and easy-to-add) shortcodes, you now have the option to have both protected and non-protected content on the same post or [&#8230;]</p><p>The post <a href=\"http://ithemes.com/2014/01/08/hide-wordpress-member-content-shortcodes-in-exchange/\">Hide Member Content With Shortcodes &#8211; New in Exchange Membership Add-on</a> appeared first on <a href=\"http://ithemes.com\">iThemes</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Kristen Wright\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4235:\"<p>The latest version of the Exchange Membership Add-on (our <a href=\"http://ithemes.com/purchase/membership-add-on/\">WordPress Membership plugin</a>) now includes a new feature — the ability to display member and non-member content on the same WordPress page or post. By using new built-in (and easy-to-add) shortcodes, you now have the option to have both protected and non-protected content on the same post or page, so you can show certain portions of your content and hide other parts from non-members.</p>
<h2>How to Use Member Content Shortcodes to Hide Your WordPress Member Content</h2>
<p>1. After updating to v. 1.0.18 of the Exchange Membership Add-on, you&#8217;ll see the new <strong>Member Content</strong> button above the post and page editor.</p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-21066\" style=\"margin-top: 30px; margin-bottom: 30px;\" alt=\"member-content-button\" src=\"http://ithemes.com/wp-content/uploads/2014/01/member-content-button.png\" width=\"1127\" height=\"864\" /></p>
<p>2. To hide a certain portion of the content from non-members, <strong>highlight the text you&#8217;d like to make members only</strong>, and click the <strong>Member Content</strong> button. You&#8217;ll now see a dialogue box to select the membership levels you’d like to give access to the content.</p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-21068\" style=\"margin-top: 30px; margin-bottom: 30px;\" alt=\"member-content-box\" src=\"http://ithemes.com/wp-content/uploads/2014/01/member-content-box.png\" width=\"1116\" height=\"786\" /></p>
<p>3. Select the membership level and click <strong>Insert Shortcode</strong>. The shortcode will then automatically be added to the content area around the highlighted text.</p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-21069\" style=\"margin-top: 30px; margin-bottom: 30px;\" alt=\"membership-shortcode\" src=\"http://ithemes.com/wp-content/uploads/2014/01/membership-shortcode.png\" width=\"1122\" height=\"695\" /></p>
<p>Double-check that the shortcode is &#8220;around&#8221; the members only text. It should be formatted like this:</p>
<p style=\"text-align: center;\"><a href=\"http://ithemes.com/2014/01/08/hide-wordpress-member-content-with-shortcodes/screen-shot-2014-01-08-at-3-01-35-pm/\" rel=\"attachment wp-att-21070\"><img class=\"aligncenter size-full wp-image-21070\" style=\"margin-top: 30px; margin-bottom: 30px;\" alt=\"Screen Shot 2014-01-08 at 3.01.35 PM\" src=\"http://ithemes.com/wp-content/uploads/2014/01/Screen-Shot-2014-01-08-at-3.01.35-PM.png\" width=\"449\" height=\"151\" /></a></p>
<p>On the front end of your site, members of the selected level will be able to see this content, while this section will be hidden from non-members.</p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-21073\" style=\"margin-top: 30px; margin-bottom: 30px;\" alt=\"Screen Shot 2014-01-08 at 3.13.11 PM\" src=\"http://ithemes.com/wp-content/uploads/2014/01/Screen-Shot-2014-01-08-at-3.13.11-PM.png\" width=\"975\" height=\"482\" /></p>
<h2 style=\"margin-top: 40px;\">Start Your WordPress Membership Site</h2>
<p>To start your WordPress membership site, get the <a href=\"http://ithemes.com/purchase/membership-add-on/\">Membership Add-on for iThemes Exchange</a>. With the Membership Add-on for Exchange, it’s easy to:</p>
<ul>
<li>Sell multiple membership levels from your WordPress site</li>
<li>Protect page and post content based on membership level</li>
<li>Delay (drip) individual content items to members</li>
<li>Add members-only digital downloads</li>
</ul>
<p>For more info on getting your membership site set up, check out <a href=\"http://ithemes.com/2013/10/09/start-a-membership-site-with-ithemes-exchange/\">Start a WordPress Membership Site with iThemes Exchange</a>.</p>
<div class=\"content-callout green\">All current Membership Add-on, Exchange Pro Pack, Plugin Dev Suite and Toolkit members can now update to v. 1.0.18 of the Exchange Membership Add-on.</div>
<p>The post <a href=\"http://ithemes.com/2014/01/08/hide-wordpress-member-content-shortcodes-in-exchange/\">Hide Member Content With Shortcodes &#8211; New in Exchange Membership Add-on</a> appeared first on <a href=\"http://ithemes.com\">iThemes</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:88:\"http://ithemes.com/2014/01/08/hide-wordpress-member-content-shortcodes-in-exchange/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:42:\"
		
		
		
		
		
				

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"New Features and Improvements in BackupBuddy 4.2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"http://ithemes.com/2014/01/07/new-features-improvements-backupbuddy-4-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"http://ithemes.com/2014/01/07/new-features-improvements-backupbuddy-4-2/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 07 Jan 2014 22:16:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"BackupBuddy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"http://ithemes.com/?p=21019\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:600:\"<p>The latest version of BackupBuddy includes a ton of new features and improvements for the user interface, backup and restore/migrate, backup profiles and more. Here&#8217;s a recap of the updates included in BackupBuddy 4.2: User Interface Updated entire BackupBuddy user interface to support WordPress 3.8&#8242;s new MP6 styling, look, and feel. Contextual help has been [&#8230;]</p><p>The post <a href=\"http://ithemes.com/2014/01/07/new-features-improvements-backupbuddy-4-2/\">New Features and Improvements in BackupBuddy 4.2</a> appeared first on <a href=\"http://ithemes.com\">iThemes</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Kristen Wright\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:9290:\"<p>The latest version of <a href=\"http://ithemes.com/backupbuddy\">BackupBuddy</a> includes a ton of new features and improvements for the user interface, backup and restore/migrate, backup profiles and more.</p>
<p><strong>Here&#8217;s a recap of the updates included in BackupBuddy 4.2:</strong></p>
<h2 style=\"margin-top: 40px;\">User Interface</h2>
<ul>
<li>Updated entire BackupBuddy user interface to support WordPress 3.8&#8242;s new MP6 styling, look, and feel.<a href=\"http://ithemes.com/2014/01/07/new-features-improvements-backupbuddy-4-2/screen-shot-2014-01-07-at-3-01-18-pm/\" rel=\"attachment wp-att-21022\"><img class=\"aligncenter  wp-image-21022\" style=\"margin-top: 20px; margin-bottom: 40px;\" alt=\"BackupBuddy-dashboard\" src=\"http://ithemes.com/wp-content/uploads/2014/01/Screen-Shot-2014-01-07-at-3.01.18-PM.png\" width=\"982\" height=\"590\" /></a></li>
</ul>
<ul>
<li>Contextual help has been added to all BackupBuddy pages. Check out the <strong>Help</strong> tab on the upper right of BackupBuddy pages to display additional help and information, including links to BackupBuddy Support and Knowledge Base.<a href=\"http://ithemes.com/2014/01/07/new-features-improvements-backupbuddy-4-2/backupbuddy-help-dashboard/\" rel=\"attachment wp-att-21025\"><img class=\"aligncenter  wp-image-21025\" style=\"margin-top: 20px; margin-bottom: 40px;\" alt=\"backupBuddy-help-dashboard\" src=\"http://ithemes.com/wp-content/uploads/2014/01/backupBuddy-help-dashboard.png\" width=\"941\" height=\"703\" /></a></li>
</ul>
<ul>
<li>Simplified the BackupBuddy WordPress dashboard menu by removing the Getting Started page (now available from the Backup page).<a href=\"http://ithemes.com/2014/01/07/new-features-improvements-backupbuddy-4-2/screen-shot-2014-01-07-at-2-59-06-pm-2/\" rel=\"attachment wp-att-21024\"><img class=\"aligncenter  wp-image-21024\" style=\"margin-top: 20px; margin-bottom: 40px;\" alt=\"Backup Getting Started\" src=\"http://ithemes.com/wp-content/uploads/2014/01/Screen-Shot-2014-01-07-at-2.59.06-PM1.png\" width=\"940\" height=\"879\" /></a></li>
</ul>
<ul>
<li>Schedules page updated for better usability, including a new <em>Twice Weekly</em> backup interval option.<a href=\"http://ithemes.com/2014/01/07/new-features-improvements-backupbuddy-4-2/backupbuddy-scheduling/\" rel=\"attachment wp-att-21026\"><img class=\"aligncenter  wp-image-21026\" style=\"margin-top: 20px; margin-bottom: 50px;\" alt=\"backupbuddy-scheduling\" src=\"http://ithemes.com/wp-content/uploads/2014/01/backupbuddy-scheduling.png\" width=\"969\" height=\"849\" /></a></li>
</ul>
<h2 style=\"margin-top: 50px; margin-bottom: 20px;\">Backup &amp; Restore/Migrate</h2>
<p style=\"text-align: center;\"><a href=\"http://ithemes.com/2014/01/07/new-features-improvements-backupbuddy-4-2/screen-shot-2014-01-07-at-3-27-49-pm/\" rel=\"attachment wp-att-21030\"><img class=\"aligncenter  wp-image-21030\" style=\"margin-top: 20px; margin-bottom: 30px;\" alt=\"Screen Shot 2014-01-07 at 3.27.49 PM\" src=\"http://ithemes.com/wp-content/uploads/2014/01/Screen-Shot-2014-01-07-at-3.27.49-PM.png\" width=\"1185\" height=\"727\" /></a></p>
<ul>
<li>Simplified backup listing using backup date &amp; time as primary listing criteria.</li>
<li>Backup details now displays start and finish times of the overall backup process.</li>
<li>Added <em>File Size</em> to Recent Backups listing.</li>
<li>Improved instructions on Restore / Migrate page.</li>
</ul>
<h2 style=\"margin-top: 50px; margin-bottom: 20px;\">Profiles</h2>
<p style=\"text-align: center;\"><a href=\"http://ithemes.com/2014/01/07/new-features-improvements-backupbuddy-4-2/backup-profiles-2/\" rel=\"attachment wp-att-21038\"><img class=\"aligncenter  wp-image-21038\" style=\"margin-top: 20px; margin-bottom: 30px;\" alt=\"backup-profiles\" src=\"http://ithemes.com/wp-content/uploads/2014/01/backup-profiles.png\" width=\"1090\" height=\"712\" /></a></p>
<ul>
<li>Profiles are now configured on the Backups page instead of the Settings page for easier configuration.</li>
<li>Profiles allow customization of what is backed up when each backup type is run. This is useful for backing up smaller sections of the site at once or backing up frequently changed files or database contents more often without having to back up everything each time.</li>
<li>New beta backup profile type of <em>Files Only</em> for more easily backing up specific sections of files.</li>
</ul>
<h2 style=\"margin-top: 50px; margin-bottom: 20px;\">Server Tools Page</h2>
<p><a href=\"http://ithemes.com/2014/01/07/new-features-improvements-backupbuddy-4-2/backup-logs/\" rel=\"attachment wp-att-21042\"><img class=\"aligncenter size-full wp-image-21042\" alt=\"backup-logs\" src=\"http://ithemes.com/wp-content/uploads/2014/01/backup-logs.png\" width=\"987\" height=\"713\" /></a></p>
<ul>
<li>Added BackupBuddy directories (backup storage, logs, temp directory) to Server Tools URLs &amp; Paths page.</li>
<li>Mass Database Text Replace Tool now available on the Server Tools Database tab for mass replacing text such as URLs in the database.</li>
</ul>
<h2 style=\"margin-top: 50px; margin-bottom: 20px;\">Settings</h2>
<p><a href=\"http://ithemes.com/2014/01/07/new-features-improvements-backupbuddy-4-2/screen-shot-2014-01-07-at-3-29-54-pm/\" rel=\"attachment wp-att-21031\"><img class=\"aligncenter  wp-image-21031\" style=\"margin-top: 20px; margin-bottom: 40px;\" alt=\"Screen Shot 2014-01-07 at 3.29.54 PM\" src=\"http://ithemes.com/wp-content/uploads/2014/01/Screen-Shot-2014-01-07-at-3.29.54-PM.png\" width=\"1115\" height=\"852\" /></a></p>
<ul>
<li>Setting <em>Default base database tables to backup</em> now include a new <em>None</em> option.</li>
<li>Backup mode (Modern vs Classic) setting now applies to both manual and scheduled backups for enhanced server compatibility.</li>
<li>Added additional checks and warnings for verifying exclusions of database tables, paths, and files do not get accidentally excluded without notification.</li>
</ul>
<h2 style=\"margin-top: 50px; margin-bottom: 20px;\">ImportBuddy</h2>
<ul>
<li>Enhanced scanning of potential problems on import such as incompatible configuration files such as custom php.ini configurations.</li>
<li>Ability to view a CRC hash of backup files to verify they are not corrupt added.</li>
<li>Mass database text replacement tool now available in ImportBuddy via the top menu bar for mass text replacements on existing WordPress installations, such as updating URLs within the database.</li>
</ul>
<h2 style=\"margin-top: 50px; margin-bottom: 20px;\">Remote Destinations</h2>
<ul>
<li>Amazon S3 library updated for better performance when sending to Amazon S3.</li>
<li>Amazon S3 now supports setting the geographical region for any new buckets that are created by BackupBuddy.</li>
<li>Amazon S3 destination now supported Reduced Redundancy storage class for cheaper storage.</li>
<li>Backups stored on Amazon S3 may be copied back to the site or directly downloaded to your computer from the S3 management page.</li>
<li>FTP Destination path browser added for easily browsing remote FTP paths for easier setting up of an FTP destination.</li>
<li>Emails sent to an Email destination now include the site URL in the subject of the email for convenience.</li>
<li>From the Remote Destinations page you may hover over each existing destination &amp; select to manage remote files at the destination.</li>
<li>Stash option added to limit number of backups of the Files Only type.</li>
</ul>
<h2 style=\"margin-top: 50px; margin-bottom: 20px;\">Misc</h2>
<ul>
<li>Added <em>Quick Release Updates</em> setting to the bottom of the licensing page. Enabling this option allows the site to receive automatic update notices for product quick releases (releases that do not have automatic update support by default).</li>
<li>Added command line support via WP-CLI &lt; http://wp-cli.org &gt; for initiating backups via the command line or other automated means.</li>
<li>More strings localized for better translations.</li>
</ul>
<h2 style=\"margin-top: 50px; margin-bottom: 20px;\">How to Update to BackupBuddy 4.2</h2>
<p>All current BackupBuddy customers will find the BackupBuddy 4.2 update available for download from the <a href=\"http://ithemes.com/member\">iThemes Member Panel </a>for manual updates. For faster and easier updates, we recommend <a href=\"http://ithemes.com/codex/page/BackupBuddy:_Licensing\">licensing BackupBuddy for automatic updates</a> straight from the WordPress dashboard.</p>
<p>To save even more time (and from logging into each site individually), update all your BackupBuddy sites from one place by using <a href=\"http://ithemes.com/member/panel/sync.php\">Sync — free for 10 sites for all current BackupBuddy customers</a>.</p>
<p><a href=\"http://ithemes.com/2014/01/07/new-features-improvements-backupbuddy-4-2/sync-backupbuddy-update/\" rel=\"attachment wp-att-21047\"><img class=\"aligncenter size-full wp-image-21047\" alt=\"sync-backupbuddy-update\" src=\"http://ithemes.com/wp-content/uploads/2014/01/sync-backupbuddy-update.png\" width=\"1044\" height=\"880\" /></a></p>
<p><a class=\"btn green\" href=\"http://ithemes.com/member/panel/sync.php\">Update BackupBuddy using Sync</a></p>
<p>The post <a href=\"http://ithemes.com/2014/01/07/new-features-improvements-backupbuddy-4-2/\">New Features and Improvements in BackupBuddy 4.2</a> appeared first on <a href=\"http://ithemes.com\">iThemes</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"http://ithemes.com/2014/01/07/new-features-improvements-backupbuddy-4-2/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"Add bbPress Members Only Forums to Your WordPress Membership Site\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:88:\"http://ithemes.com/2014/01/06/add-bbpress-members-only-forums-wordpress-membership-site/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:97:\"http://ithemes.com/2014/01/06/add-bbpress-members-only-forums-wordpress-membership-site/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 06 Jan 2014 22:16:09 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:8:\"Exchange\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:19:\"WordPress Ecommerce\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"http://ithemes.com/?p=20972\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:626:\"<p>With the new bbPress Membership Add-on for Exchange, you can now enable members only forums for the bbPress plugin, the free forum software that allows you to set up discussion forums inside your WordPress site. With this new Exchange add-on, you can restrict bbPress forums, topics and replies to require certain membership levels sold from your Exchange-powered [&#8230;]</p><p>The post <a href=\"http://ithemes.com/2014/01/06/add-bbpress-members-only-forums-wordpress-membership-site/\">Add bbPress Members Only Forums to Your WordPress Membership Site</a> appeared first on <a href=\"http://ithemes.com\">iThemes</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Kristen Wright\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:10591:\"<p>With the new <a href=\" http://ithemes.com/purchase/bbpress-membership-add-on/\">bbPress Membership Add-on for Exchange</a>, you can now enable members only forums for the <a href=\"http://bbpress.org/\">bbPress plugin</a>, the free forum software that allows you to set up discussion forums inside your WordPress site.</p>
<p>With this new Exchange add-on, you can restrict bbPress forums, topics and replies to require certain membership levels sold from your Exchange-powered WordPress membership site. Once you set up these restrictions, a user will have to be a current customer of a certain membership product to be able to have access to the forum, topic or reply.</p>
<h2 style=\"margin-top: 40px;\">Why Add Members Only Forums?</h2>
<p>Creating protected membership forums can be helpful if you run a membership site and want to allow your members to participate in topic-driven discussions outside of the built-in WordPress comments functionality for posts and pages.</p>
<p>For example, if you&#8217;re a health coach and run a membership site, you could create discussion forums that allow members to share their progress and success. Or, if you run an educational or curriculum-driven site with <a href=\"http://ithemes.com/codex/page/Exchange_Product_Types:_Memberships#Content_Access\">drip (or delayed) content</a>, you could set up membership forums with corresponding delayed access for each lesson or course as members progress through the material.</p>
<h2 style=\"margin-top: 40px;\">Getting Started</h2>
<p>The Exchange bbPress Membership Add-on works together with the <a href=\"http://ithemes.com/purchase/membership-add-on/\">Exchange Membership Add-on</a>. With the Exchange Membership Add-on, you can sell membership access to your WordPress site with members only posts, pages and digital downloads.</p>
<p>The bbPress Membership Add-on adds a <strong>Membership Access</strong> box to the Forum creator/editor screen where you can assign the details of your membership protection to the forum. Once you&#8217;ve created a membership product for your store, you&#8217;ll see it available from the drop-down as well as an option to delay access to this forum for the selected membership level.</p>
<p><a href=\"http://ithemes.com/2014/01/06/add-bbpress-members-only-forums-wordpress-membership-site/bbpress-membership-access/\" rel=\"attachment wp-att-20974\"><img class=\"aligncenter size-full wp-image-20974\" alt=\"bbpress-membership-access\" src=\"http://ithemes.com/wp-content/uploads/2014/01/bbpress-membership-access.png\" width=\"1134\" height=\"805\" /></a></p>
<h2 style=\"margin-top: 40px;\">Step 1: Install Plugins</h2>
<p>To get started creating members only forums, you&#8217;ll need install 4 plugins:</p>
<ul>
<li><a href=\"http://ithemes.com/exchange/\">Exchange 1.7.12</a> (or higher)</li>
<li><a href=\"http://bbpress.org/\">bbPress 2.5.2</a> (or higher)</li>
<li><a href=\"http://ithemes.com/purchase/membership-add-on/\">Exchange Membership Add-on 1.0.18</a> (or higher)</li>
<li><a href=\" http://ithemes.com/purchase/bbpress-membership-add-on/\">Exchange bbPress Membership Add-on</a></li>
</ul>
<h2 style=\"margin-top: 40px;\">Step 2: Create a Membership Product</h2>
<p>After uploading and activating the plugins above (<a href=\"http://ithemes.com/exchange\">Exchange</a>, <a href=\"http://bbpress.org\">bbPress</a>, <a href=\"http://ithemes.com/purchase/membership-add-on/\">Exchange Membership Add-on</a> and <a href=\"http://ithemes.com/2014/01/06/add-bbpress-members-only-forums-wordpress-membership-site/\">Exchange bbPress Membership Add-on</a>), you&#8217;ll see the <strong>Add Membership</strong> option in your Exchange menu from the WordPress dashboard.</p>
<p><a href=\"http://ithemes.com/2014/01/06/add-bbpress-members-only-forums-wordpress-membership-site/screen-shot-2014-01-06-at-11-03-47-am/\" rel=\"attachment wp-att-20979\"><img class=\"aligncenter size-full wp-image-20979\" alt=\"Screen Shot 2014-01-06 at 11.03.47 AM\" src=\"http://ithemes.com/wp-content/uploads/2014/01/Screen-Shot-2014-01-06-at-11.03.47-AM.png\" width=\"295\" height=\"264\" /></a></p>
<p>From the <strong>Add New Membership</strong> page, fill out your membership product details. For more information on setting up an Exchange membership product, check out this post: <a href=\"http://ithemes.com/2013/10/09/start-a-membership-site-with-ithemes-exchange/\">How to Start a WordPress Membership Site with Exchange</a>.</p>
<p><a href=\"http://ithemes.com/2014/01/06/add-bbpress-members-only-forums-wordpress-membership-site/screen-shot-2014-01-06-at-11-05-53-am/\" rel=\"attachment wp-att-20980\"><img class=\"aligncenter size-full wp-image-20980\" alt=\"Screen Shot 2014-01-06 at 11.05.53 AM\" src=\"http://ithemes.com/wp-content/uploads/2014/01/Screen-Shot-2014-01-06-at-11.05.53-AM.png\" width=\"1203\" height=\"863\" /></a></p>
<p>Click <strong>Publish</strong> once you&#8217;re ready to make this membership available for purchase from your store.</p>
<h2 style=\"margin-top: 40px;\">Step 3: Create a bbPress Forum (and Topic)</h2>
<p>Next up, you&#8217;ll want to get started creating a bbPress forum that will have access limits based on a user&#8217;s membership level. From the WordPress dashboard, visit <strong>Forums &gt; New Forums</strong>. For more information on setting up a new bbPress forum, visit this <a href=\"http://codex.bbpress.org/step-by-step-guide-to-setting-up-a-bbpress-forum/\">Step by Step Guide to Setting Up a bbPress Forum</a>.</p>
<p><a href=\"http://ithemes.com/2014/01/06/add-bbpress-members-only-forums-wordpress-membership-site/screen-shot-2014-01-03-at-4-47-26-pm/\" rel=\"attachment wp-att-20973\"><img class=\"aligncenter size-medium wp-image-20973\" alt=\"Exchange-bbPress-Membership-Add-on\" src=\"http://ithemes.com/wp-content/uploads/2014/01/Screen-Shot-2014-01-03-at-4.47.26-PM-540x383.png\" width=\"540\" height=\"383\" /></a></p>
<p>Before you finalize and publish your new forum, visit the <strong>Membership Access</strong> box to add your forum membership access rules. From here, you can select your new membership product from the drop-down and, if you want, add the number of days, weeks, months or years to delay forum access for that membership level (this can be helpful if you&#8217;re already providing corresponding drip content that relates to this discussion forum).</p>
<p>bbPress<strong> Topics</strong> can also be protected by membership level, so add a new topic to your new forum. Click to expand the Topics menu and click New Topic.</p>
<p><a href=\"http://ithemes.com/2014/01/06/add-bbpress-members-only-forums-wordpress-membership-site/screen-shot-2014-01-06-at-2-29-32-pm/\" rel=\"attachment wp-att-20985\"><img class=\"aligncenter size-full wp-image-20985\" alt=\"Screen Shot 2014-01-06 at 2.29.32 PM\" src=\"http://ithemes.com/wp-content/uploads/2014/01/Screen-Shot-2014-01-06-at-2.29.32-PM.png\" width=\"1242\" height=\"1041\" /></a></p>
<p>For this topic, I selected the Members Only Forum in the Topic Attributes, so this topic will be added to my new members only forum. Again, in the Membership Access box, select the membership product and the delay access time frame.</p>
<h2>Member/Non-Member View of Protected Forum &amp; Topics</h2>
<p>Now, on the front end of the site, non-members will see the restricted content message.</p>
<p><a href=\"http://ithemes.com/2014/01/06/add-bbpress-members-only-forums-wordpress-membership-site/screen-shot-2014-01-06-at-2-32-50-pm/\" rel=\"attachment wp-att-20986\"><img class=\"aligncenter size-full wp-image-20986\" alt=\"Screen Shot 2014-01-06 at 2.32.50 PM\" src=\"http://ithemes.com/wp-content/uploads/2014/01/Screen-Shot-2014-01-06-at-2.32.50-PM.png\" width=\"934\" height=\"531\" /></a></p>
<p>This message can be customized by clicking the settings gear next to the Membership Add-on in add-ons list of the<strong> Exchange &gt; Add-ons</strong> page. You can edit this message to add sales copy or a login link for members.</p>
<p><a href=\"http://ithemes.com/2014/01/06/add-bbpress-members-only-forums-wordpress-membership-site/screen-shot-2014-01-06-at-2-34-27-pm/\" rel=\"attachment wp-att-20987\"><img class=\"aligncenter size-full wp-image-20987\" alt=\"Screen Shot 2014-01-06 at 2.34.27 PM\" src=\"http://ithemes.com/wp-content/uploads/2014/01/Screen-Shot-2014-01-06-at-2.34.27-PM.png\" width=\"1168\" height=\"1035\" /></a></p>
<p><strong>Member&#8217;s Forum View</strong></p>
<p>Members will have full access to your forums, topics and replies (based on your membership access settings).</p>
<p style=\"text-align: center;\"><a href=\"http://ithemes.com/2014/01/06/add-bbpress-members-only-forums-wordpress-membership-site/screen-shot-2014-01-06-at-2-41-36-pm/\" rel=\"attachment wp-att-20988\"><img class=\"aligncenter  wp-image-20988\" style=\"margin-top: 20px; margin-bottom: 20px;\" alt=\"Screen Shot 2014-01-06 at 2.41.36 PM\" src=\"http://ithemes.com/wp-content/uploads/2014/01/Screen-Shot-2014-01-06-at-2.41.36-PM.png\" width=\"980\" height=\"500\" /></a></p>
<p><strong>Member&#8217;s Topic View</strong></p>
<p style=\"text-align: center;\"><a href=\"http://ithemes.com/2014/01/06/add-bbpress-members-only-forums-wordpress-membership-site/screen-shot-2014-01-06-at-2-42-33-pm/\" rel=\"attachment wp-att-20989\"><img class=\"aligncenter  wp-image-20989\" style=\"margin-top: 20px; margin-bottom: 20px;\" alt=\"Screen Shot 2014-01-06 at 2.42.33 PM\" src=\"http://ithemes.com/wp-content/uploads/2014/01/Screen-Shot-2014-01-06-at-2.42.33-PM.png\" width=\"988\" height=\"757\" /></a></p>
<h2 style=\"margin-top: 40px;\">Download and Purchase Info</h2>
<div class=\"content-callout green\">All current customers of the Exchange Membership Add-on, Exchange Pro Pack, Plugin Dev Suite and Toolkit will find the bbPress Membership Add-on available for download in their <a href=\"http://ithemes.com/member\" target=\"_blank\">Member Panel</a>.</div>
<p>The <a href=\"http://ithemes.com/purchase/bbpress-membership-add-on/\">bbPress Membership Add-on</a> is available for purchase as part of the <a href=\"http://ithemes.com/purchase/membership-add-on/\">Exchange Membership Add-on</a>, the <a href=\"http://ithemes.com/exchange/#pricing\">Exchange Pro Pack</a>, the <a href=\"http://ithemes.com/developer-suite/\">Plugin Developer Suite</a> and the <a href=\"http://ithemes.com/toolkit/\">Toolkit</a>.<br />
<a class=\"btn green\" href=\" http://ithemes.com/purchase/bbpress-membership-add-on/\">Get the Membership Add-on for Exchange</a></p>
<p>The post <a href=\"http://ithemes.com/2014/01/06/add-bbpress-members-only-forums-wordpress-membership-site/\">Add bbPress Members Only Forums to Your WordPress Membership Site</a> appeared first on <a href=\"http://ithemes.com\">iThemes</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:93:\"http://ithemes.com/2014/01/06/add-bbpress-members-only-forums-wordpress-membership-site/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"WordPress Security 101: A Quick Guide to Locking Down Your Site\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"http://ithemes.com/2014/01/03/wordpress-security-101-quick-guide-to-locking-down-your-site/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:100:\"http://ithemes.com/2014/01/03/wordpress-security-101-quick-guide-to-locking-down-your-site/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 03 Jan 2014 16:09:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:8:\"featured\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:18:\"WordPress Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"http://ithemes.com/?p=20929\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:590:\"<p>Security is a big tech topic these days. Sites have been hacked and people are worried. But there’s plenty you can do to secure your site. We’re going to talk briefly about security and WordPress, covering some big picture concepts to help you keep your site safe, including: Preliminary Ideas 3 Kinds of Security Your Site [&#8230;]</p><p>The post <a href=\"http://ithemes.com/2014/01/03/wordpress-security-101-quick-guide-to-locking-down-your-site/\">WordPress Security 101: A Quick Guide to Locking Down Your Site</a> appeared first on <a href=\"http://ithemes.com\">iThemes</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Kevin D. Hendricks\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:8566:\"<p>Security is a big tech topic these days. Sites have been hacked and people are worried. But there’s plenty you can do to secure your site. We’re going to talk briefly about security and WordPress, covering some big picture concepts to help you keep your site safe, including:</p>
<ul>
<li>Preliminary Ideas</li>
<li>3 Kinds of Security Your Site Needs</li>
<li>4 Best Security Practices</li>
<li>More Security Help</li>
</ul>
<p>The easiest thing you can do to keep your site secure is install a plugin such as <a href=\"http://wordpress.org/plugins/better-wp-security/\">Better WP Security</a>. We actually <a href=\"http://ithemes.com/2013/12/04/wp-security-expert-plugin-developer-chris-wiegman-joins-ithemes/\">hired the developer of that plugin, Chris Wiegman</a>, and brought him on our team to update the plugin and make it a part of the <a href=\"http://ithemes.com/toolkit\">iThemes Toolkit</a>.</p>
<p>Security plugins such as Better WP Security can take care of a lot of the practical matters. But here we’re just going to cover some of the conceptual ideas about security. In early 2014, we&#8217;ll be releasing a premium WordPress security plugin — <a href=\"http://ithemes.com/wordpress-security-updates/\">sign up here to be the first to know when it ships</a>.</p>
<h2 style=\"margin-top: 40px;\">First Things First</h2>
<p>Let’s talk about some preliminary ideas first:</p>
<ul>
<li><strong style=\"color: #000000; font-size: medium; font-style: normal;\">There’s Always a Risk:</strong> Your website can never be 100% secure. Hackers are always trying new things and discovering new vulnerabilities to exploit. The online world changes quickly and the same is true of security. Good security is about minimizing risk. If anybody tries to sell you a 100% secure solution, they’re scamming you. You’ll never be completely safe, but there’s a lot you can do to minimize your risk.</li>
</ul>
<ul>
<li><strong style=\"color: #000000; font-size: medium; font-style: normal;\">Don’t Blame WordPress:</strong> The haters like to say that WordPress isn’t secure. That’s not necessarily true—it depends on how you set up and use WordPress. If you’re not keeping it updated or following bad practices, then no, it’s not secure. The reality is that 17% of the world’s websites are using WordPress, which makes it a huge target. So you need to be smart. You need to keep things updated and follow the best practices to lock your site down. Many security issues have little to do with WordPress and more to do with server vulnerabilities, cross-contamination and poor passwords. Bad decisions can undermine your site, and that’s true whether you’re using WordPress or any other solution. So don’t blame your security woes on WordPress.</li>
</ul>
<ul>
<li><strong>Security vs. Usability:</strong> There’s a fine balance between security and usability. Sometimes locking down your site makes it secure, but it’s hard to use. Sometimes making your site easier to use makes it less secure. You’ll have to find the balance.</li>
</ul>
<h2 style=\"margin-top: 40px;\">3 Kinds of Security Your Site Needs</h2>
<p>There are three phases to security: protection, detection and restoration. If you truly want to protect your site, you need to do all three.</p>
<h4>1. Protection</h4>
<p>First and foremost you need to lock down your site and keep it safe. You’ve got to raise the drawbridge, lower the gate, ignite the flammable moat and do whatever else you can to stop attacks before they start. This is the obvious first step and kind of hard to ignore: protect your site.</p>
<h4>2. Detection</h4>
<p>No matter how good your protection is the bad guys might find a way to hurt your site. And you need to know when an attack is happening. The attack won’t always be a full frontal assault that makes it painfully obvious your site has been hacked. Sometimes they’re sneaky and bots will put a bunch of hidden code into your site. It’s no good to have all kinds of protection but then not know when some malicious virus found a weak spot and broke through. Malicious bots and hackers may have already infiltrated your site. You’ll never know without detection.</p>
<p>You need to detect attacks as they happen so you can swing into action.</p>
<h4>3. Recovery</h4>
<p>Finally, you need a plan to get your site up and running again after it’s been knocked down. These things happen. The best protection and detection strategies can still be foiled and you need to be prepared. Why worry about the worst-case scenario when a little preparation will have you covered? Plus, a good backup is important for other reasons besides security. We recommend backing up your site with <a href=\"http://ithemes.com/backupbuddy\">BackupBuddy</a> (which also handles restoring your site if something happens) so you’re prepared for anything</p>
<h2 style=\"margin-top: 40px;\">4 Best Security Practices</h2>
<h4>1. Keep It Current</h4>
<p>One of the biggest security vulnerabilities in WordPress is old software. WordPress is updated fairly often and whenever there’s a new security issue they roll out an update immediately. But that doesn’t do you any good if you’re not keeping your installation up to date. You also need to keep your themes and plugins up to date—they can have security issues as well. Sometimes people put off updates for fear of breaking their site, but you’d rather break your site with an update than risk a break-in.</p>
<p>Also, just because a plugin is deactivated doesn’t mean it’s not a threat. You need to delete the plugin entirely.</p>
<h4>2. Strong Passwords</h4>
<p>Your security is only as good as your password. If you’ve got a simple password, you’ve got a simple site to hack. You need to use strong passwords. Your password should have numbers, capitals, special characters (@, #, *, etc.) and be long and unique. Your WordPress password can even include spaces and be a passphrase.</p>
<p>Don’t use the same password in multiple places. Yes, remembering different passwords for different sites is tough, but a hacked site is worse.</p>
<h4>3. Manage Users</h4>
<p>Your own strong password is useless if another admin has a weak one. You need to manage your users. Not everybody needs admin access. The more people with admin access, the more chances to hack your site. Make sure you’re only giving admin access to the people who truly need it. And make sure those few admins are following good security practices.</p>
<p>Remember to update or remove users when you have staff transitions.</p>
<h4>4. Back It Up</h4>
<p>If anything ever goes wrong with your site, you want to be able to get it back up quickly. That means you need a backup plan. In order for backup to work, it needs to be complete and automatic. Backing up your database isn’t enough. That will save your content, but you’ll still have to rebuild your entire site, including theme tweaks and plugin settings. And if your backup isn’t automatic, you’ll forget about it.</p>
<p>Get a powerful backup tool, such as <a href=\"http://ithemes.com/backupbuddy\">BackupBuddy</a>, to keep your site safely backed up and ready to be restored.</p>
<h2 style=\"margin-top: 40px;\">More Security Help</h2>
<p>This should give you a good overview of security, but it’s just a start. Security is a big deal and you need to take the right precautions.</p>
<p>That’s why we’re rolling out a new security plugin, built by Chris Wiegman on top of his <a href=\"http://wordpress.org/plugins/better-wp-security/\">Better WP Security plugin</a> that’s had nearly 1.4 million downloads.</p>
<p>Learn more by watching the <a href=\"http://ithemes.com/2013/12/30/introduction-wordpress-security-webinar-replay/\">Introduction to WordPress Security webinar</a> with Chris. He offers an overview of the Better WP Security plugin and what you can expect when we take over the plugin and roll out the new iThemes version.</p>
<h2 style=\"margin-top: 40px;\">Download the Free Ebook</h2>
<p>In this primer on WordPress security, learn simple WordPress security tips to keep your site safe—including 3 kinds of security your site needs and 4 best security practices.</p>
<p><a class=\"btn green\" href=\"http://ithemes.com/downloads/WordPress-Security-ebook.pdf\">Download the PDF</a></p>
<p>The post <a href=\"http://ithemes.com/2014/01/03/wordpress-security-101-quick-guide-to-locking-down-your-site/\">WordPress Security 101: A Quick Guide to Locking Down Your Site</a> appeared first on <a href=\"http://ithemes.com\">iThemes</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:96:\"http://ithemes.com/2014/01/03/wordpress-security-101-quick-guide-to-locking-down-your-site/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:42:\"
		
		
		
		
		
				

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Our 2013 Highlights\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"http://ithemes.com/2013/12/31/our-2013-highlights/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"http://ithemes.com/2013/12/31/our-2013-highlights/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 31 Dec 2013 17:57:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"http://ithemes.com/?p=20889\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:536:\"<p>As 2013 draws to a close, we&#8217;d like to thank our customers for supporting us and making it one more incredible year of building awesome WordPress products for you. To celebrate our 2013 highlights, we put together the iThemes 2013 Timeline. Check out our 2013 Timeline Celebrating Our 2013 Highlights From launching our new ecommerce plugin, Exchange, [&#8230;]</p><p>The post <a href=\"http://ithemes.com/2013/12/31/our-2013-highlights/\">Our 2013 Highlights</a> appeared first on <a href=\"http://ithemes.com\">iThemes</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Kristen Wright\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2081:\"<p style=\"text-align: center;\"><img class=\"aligncenter size-full wp-image-20892\" style=\"margin-top: 70px; margin-bottom: 70px;\" alt=\"2013 iThemes\" src=\"http://ithemes.com/wp-content/uploads/2013/12/2013_email_1485ae0.png\" width=\"550\" height=\"187\" /></p>
<p>As 2013 draws to a close, we&#8217;d like to thank our customers for supporting us and making it one more incredible year of building awesome WordPress products for you. To celebrate our 2013 highlights, we put together the <a href=\"http://ithemes.com/timeline\">iThemes 2013 Timeline</a>.</p>
<p><a class=\"btn blue\" href=\"http://ithemes.com/timeline\">Check out our 2013 Timeline</a></p>
<h2 style=\"margin-top: 40px;\">Celebrating Our 2013 Highlights</h2>
<p>From launching our new ecommerce plugin, <a href=\"http://ithemes.com/exchange/\">Exchange</a>, to major version updates like <a href=\"http://ithemes.com/2013/06/11/backupbuddy-4-0-part-1-individual-file-restores/\">BackupBuddy 4.0</a> and <a href=\"http://ithemes.com/2013/08/26/ithemes-builder-5-0-is-here/\">Builder 5.0</a>, to our brand new WordPress management tool, <a href=\"http://ithemes.com/2013/11/11/announcing-ithemes-sync-manage-your-wp-updates-from-one-place-easily/\">Sync</a>, and most recently, the announcement of our future <a href=\"http://ithemes.com/2013/12/04/wp-security-expert-plugin-developer-chris-wiegman-joins-ithemes/\">WordPress security</a> plans—2013 will go down in the record books for us.</p>
<p>Here&#8217;s a quick 2013 recap from our founder, Cory Miller:</p>
<p><iframe src=\"//www.youtube.com/embed/l5djbkGb2nE?rel=0\" height=\"315\" width=\"600\" allowfullscreen=\"\" frameborder=\"0\"></iframe></p>
<p>Again, thanks to all our customers and friends. We&#8217;re excited for 2014 and all of the ways we can help <a href=\"http://ithemes.com/2011/10/11/at-ithemes-making-peoples-lives-awesome-means-web-design-made-easy/\" target=\"_blank\">make people&#8217;s lives awesome</a>!</p>
<p>The post <a href=\"http://ithemes.com/2013/12/31/our-2013-highlights/\">Our 2013 Highlights</a> appeared first on <a href=\"http://ithemes.com\">iThemes</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"http://ithemes.com/2013/12/31/our-2013-highlights/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"Introduction to WordPress Security – Webinar Replay\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"http://ithemes.com/2013/12/30/introduction-wordpress-security-webinar-replay/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"http://ithemes.com/2013/12/30/introduction-wordpress-security-webinar-replay/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 30 Dec 2013 16:40:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:18:\"WordPress Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:18:\"Better WP Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"http://ithemes.com/?p=20870\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:519:\"<p>If you missed Chris Wiegman&#8217;s recent Intro to WordPress Security webinar, here&#8217;s the replay. During this 59-minute webinar, Chris offers a walkthrough of the Better WP Security plugin and what you can expect when we take over the plugin and roll out the new iThemes version.</p><p>The post <a href=\"http://ithemes.com/2013/12/30/introduction-wordpress-security-webinar-replay/\">Introduction to WordPress Security &#8211; Webinar Replay</a> appeared first on <a href=\"http://ithemes.com\">iThemes</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Kristen Wright\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:707:\"<p>If you missed Chris Wiegman&#8217;s recent Intro to WordPress Security webinar, here&#8217;s the replay. During this 59-minute webinar, Chris offers a walkthrough of the <a href=\"http://wordpress.org/plugins/better-wp-security/\">Better WP Security plugin</a> and what you can expect when we take over the plugin and roll out the new iThemes version.</p>
<p><iframe width=\"560\" height=\"315\" src=\"//www.youtube.com/embed/5C9hW5boOMs\" frameborder=\"0\" allowfullscreen></iframe></p>
<p>The post <a href=\"http://ithemes.com/2013/12/30/introduction-wordpress-security-webinar-replay/\">Introduction to WordPress Security &#8211; Webinar Replay</a> appeared first on <a href=\"http://ithemes.com\">iThemes</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"http://ithemes.com/2013/12/30/introduction-wordpress-security-webinar-replay/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:42:\"
		
		
		
		
		
				

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"Now Add Up to 100 WordPress Sites in iThemes Sync\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"http://ithemes.com/2013/12/19/sync-additional-site-plans-now-available/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"http://ithemes.com/2013/12/19/sync-additional-site-plans-now-available/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 19 Dec 2013 20:03:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Sync\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"http://ithemes.com/?p=20826\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:551:\"<p>Last month we rolled out Sync, a new way to manage your WP site updates from one place, with 10 free sites for all current iThemes customers. We&#8217;ve received some pretty amazing feedback, so we&#8217;re glad that Sync has made managing multiple WP sites a lot easier. The biggest request we&#8217;ve had is the ability [&#8230;]</p><p>The post <a href=\"http://ithemes.com/2013/12/19/sync-additional-site-plans-now-available/\">Now Add Up to 100 WordPress Sites in iThemes Sync</a> appeared first on <a href=\"http://ithemes.com\">iThemes</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Kristen Wright\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3411:\"<p style=\"text-align: center;\"><a href=\"http://ithemes.com/member/panel/sync.php#sync-pricing\"><img class=\"aligncenter size-full wp-image-20280\" alt=\"Screen Shot 2013-11-08 at 11.36.18 AM\" src=\"http://ithemes.com/wp-content/uploads/2013/11/Screen-Shot-2013-11-08-at-11.36.18-AM.png\" width=\"337\" height=\"159\" /></a></p>
<p>Last month we rolled out <a href=\"http://ithemes.com/sync/\">Sync,</a> a new way to manage your WP site updates from one place, with <a href=\"http://ithemes.com/2013/11/11/announcing-ithemes-sync-manage-your-wp-updates-from-one-place-easily/\">10 free sites</a> for all current iThemes customers. We&#8217;ve received some pretty amazing feedback, so we&#8217;re glad that Sync has made managing multiple WP sites a lot easier.</p>
<p>The biggest request we&#8217;ve had is the ability to manage more sites with Sync. So today, we&#8217;re rolling out <a href=\"http://ithemes.com/member/panel/sync.php#sync-pricing\">Additional Sync Site Plans</a>. With these plans, our hope is that we can make it easy and affordable to get all your sites on Sync.</p>
<h2 style=\"margin-top: 40px;\">New Additional Sync Site Plans</h2>
<p>Our new <a href=\"http://ithemes.com/member/panel/sync.php#sync-pricing\">Additional Sync Site Plans</a> include:</p>
<ul>
<li><strong><a href=\"http://ithemes.com/member/panel/sync.php\">Free Tier:</a> 10 free sites for all current iThemes Customers; 25 free sites for Toolkit customers -</strong> You already get 10 free sites with any iThemes purchase, so <a href=\"http://ithemes.com/member/panel/sync.php\">go set them up today</a>!</li>
<li><strong><a href=\"http://ithemes.com/member/cart.php?action=add&amp;id=355\">25 Site Plan</a>: </strong>Upgrade from 10 free sites to 25 sites for just $50/year.</li>
<li><strong><a href=\"http://ithemes.com/member/cart.php?action=add&amp;id=356\">50 Site Plan</a>: </strong>Upgrade from 10 free sites to 50 sites for just $90/year.</li>
<li><strong><a href=\"http://ithemes.com/member/cart.php?action=add&amp;id=357\">100 Site Plan</a>:</strong> Upgrade from 10 free sites to 100 sites for just $170/year</li>
</ul>
<p><em>Need even more sites? <a href=\"http://ithemes.com/contact\">Email us here</a>.</em></p>
<h2 style=\"margin-top: 40px;\">Stay tuned for more Sync Features</h2>
<p>We&#8217;re busy working on new Sync integration with BackupBuddy, our new security plugin (due for release in early 2014) and much more.  Check out the <a href=\"https://trello.com/b/IY0dxdOg/ithemes-sync-public-roadmap\" target=\"_blank\">Sync Roadmap</a> here to vote and comment on upcoming and requested features.</p>
<p>So get all your sites on Sync today—with super affordable pricing &amp; hosted by iThemes — the same place where you get your WordPress themes, plugins and training.</p>
<h2 style=\"margin-top: 40px;\">Save 40% off Your Sync Site Upgrade</h2>
<div class=\"coupon-callout\">For a limited time only, save 40% off your Additional Sync Site Plan with coupon code <a href=\"http://ithemes.com/member/cart.php?action=add&amp;coupon=HOLIDAY40\">HOLIDAY40</a> through Dec. 31, 2013.</div>
<p><a class=\"btn blue\" href=\"http://ithemes.com/member/panel/sync.php#sync-pricing\">Log in to upgrade your Sync Site Plan</a></p>
<p>The post <a href=\"http://ithemes.com/2013/12/19/sync-additional-site-plans-now-available/\">Now Add Up to 100 WordPress Sites in iThemes Sync</a> appeared first on <a href=\"http://ithemes.com\">iThemes</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"http://ithemes.com/2013/12/19/sync-additional-site-plans-now-available/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:42:\"
		
		
		
		
		
				

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"Send Invoices with WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"http://ithemes.com/2013/12/19/send-invoices-with-wordpress/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"http://ithemes.com/2013/12/19/send-invoices-with-wordpress/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 19 Dec 2013 19:27:23 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Exchange\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"http://ithemes.com/?p=20781\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:528:\"<p>We&#8217;re excited to announce the release of the Invoices Add-on for Exchange, a new way to send invoices with WordPress and one of the most requested features we&#8217;ve had from our community. With the Invoices Add-on, you can now send invoices to clients or customers that can be paid via your preferred online payment gateway, [&#8230;]</p><p>The post <a href=\"http://ithemes.com/2013/12/19/send-invoices-with-wordpress/\">Send Invoices with WordPress</a> appeared first on <a href=\"http://ithemes.com\">iThemes</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Kristen Wright\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:11924:\"<p>We&#8217;re excited to announce the release of the <a href=\"http://ithemes.com/purchase/invoices/\">Invoices Add-on for Exchange</a>, a new way to send invoices with WordPress and one of the most requested features we&#8217;ve had from our community.</p>
<p>With the Invoices Add-on, you can now send invoices to clients or customers that can be paid via your preferred online payment gateway, like <a href=\"http://ithemes.com/exchange/features/\">PayPal</a> (Standard or Secure; free with Exchange), <a href=\"http://ithemes.com/purchase/paypal-pro/\">PayPal Pro</a>, <a href=\"http://ithemes.com/purchase/stripe-add-on/\">Stripe</a>, <a href=\"http://ithemes.com/purchase/authorize-net-add-on/\">Authorize.net</a> and <a href=\"http://ithemes.com/purchase/cybersource/\">CyberSource</a>.</p>
<h2 style=\"margin-top: 40px;\">Invoices Add-on Feature Overview</h2>
<ul>
<li>Adds a unique invoice product type to your Exchange dashboard menu</li>
<li>Invoices are hidden from your public, front-end store by default</li>
<li>Easy-to-use invoice editor</li>
<li>Protected invoice URLs are generated for your client&#8217;s privacy</li>
<li>Invoices are customer-specific, so select existing clients/customers (users) or add new customers directly from the invoice</li>
<li>Add standard terms to invoices (due upon receipt, 7 days after invoice, etc.)</li>
<li>Create custom invoice and P.O. numbers</li>
<li>Option to email client automatically when invoice is published</li>
<li>Customize email sent to client when invoice is published (in add-on settings)</li>
<li>Create monthly recurring invoices when used with Recurring Payments Add-on</li>
<li>Cool default invoice design</li>
</ul>
<h2 style=\"margin-top: 40px;\">How to Send Invoices with WordPress</h2>
<p>1. Make sure you&#8217;re currently running <a href=\"http://ithemes.com/exchange-download.php\">Exchange 1.7.9</a> or higher.</p>
<p>2. Download, upload and activate the Invoices Add-on from the <strong>Plugins &gt; Add New</strong> page in your WordPress dashboard.</p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-20821\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"Screen Shot 2013-12-19 at 11.01.07 AM\" src=\"http://ithemes.com/wp-content/uploads/2013/12/Screen-Shot-2013-12-19-at-11.01.07-AM.png\" width=\"607\" height=\"324\" /></p>
<p>3. Upon activation, you&#8217;ll now see the Invoices Add-on listed in your Enabled Add-ons on the Exchange Add-ons page.</p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-20782\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"invoices-in-add-ons\" src=\"http://ithemes.com/wp-content/uploads/2013/12/invoices-in-add-ons.png\" width=\"957\" height=\"389\" /></p>
<p>4. License your Invoice Add-on for automatic updates. Visit the iThemes Licensing page from <strong>Settings &gt; iThemes Licensing</strong>.</p>
<p style=\"text-align: center;\"><img class=\"aligncenter size-full wp-image-20791\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"Screen Shot 2013-12-19 at 9.37.10 AM\" src=\"http://ithemes.com/wp-content/uploads/2013/12/Screen-Shot-2013-12-19-at-9.37.10-AM.png\" width=\"346\" height=\"247\" /></p>
<p>5. The Invoices Add-on adds a new <strong>Add Invoice</strong> menu item to your Exchange dashboard menu. Note: if you don&#8217;t have any other product types (like digital downloads or physical products) enabled for your Exchange store, this menu item will just say <strong>Add Product</strong>. Click <strong>Add Invoice</strong> to get started.</p>
<p style=\"text-align: center;\"><img class=\"aligncenter size-full wp-image-20783\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"add-invoice-dashboard\" src=\"http://ithemes.com/wp-content/uploads/2013/12/add-invoice-dashboard.png\" width=\"464\" height=\"317\" /></p>
<p>5. You&#8217;ll now see the <strong>Add New Invoice</strong> editor. Add your <strong>Invoice Title</strong>, <strong>Total Due</strong> and, if you&#8217;re using the Recurring Payments Add-on, select your invoice renewal terms (forever, yearly or monthly).</p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-20794\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"add-new-invoice-recurring\" src=\"http://ithemes.com/wp-content/uploads/2013/12/add-new-invoice-recurring.png\" width=\"1149\" height=\"946\" /></p>
<p>6. Next, fill in your<strong> Invoice Details</strong>. If you need to add a new client<strong> </strong>for this invoice, select <strong>New Client</strong> and complete the fields for first name, last name, company name and email address and select whether to create a custom username and password. Click <strong>Create Client</strong>.</p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-20795\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"add-new-client\" src=\"http://ithemes.com/wp-content/uploads/2013/12/add-new-client.png\" width=\"1155\" height=\"1029\" /></p>
<p>If the client for this invoice is already a customer or user of your site, select <strong>Existing Client </strong>and select a client from the drop-down list.</p>
<p>7. After you add a new client or select an existing one, you can check the box for <strong>Send email automatically when invoice is published</strong>. (This will send an email to your client notifying them of the new invoice with their protected URL to the invoice.)</p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-20802\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"Screen Shot 2013-12-19 at 10.06.18 AM\" src=\"http://ithemes.com/wp-content/uploads/2013/12/Screen-Shot-2013-12-19-at-10.06.18-AM.png\" width=\"758\" height=\"204\" /></p>
<p>8. Next up, select the <strong>Terms</strong> of the invoice. You can select from <strong>No Terms</strong>, <strong>Net 7</strong>, <strong>Net 10</strong>, <strong>Net 30</strong>, <strong>Net 60</strong>, <strong>Net 90</strong> and <strong>Due on Receipt</strong>. These terms will add a &#8220;Payment is due&#8221; description to the invoice.</p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-20796\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"Screen Shot 2013-12-19 at 9.54.20 AM\" src=\"http://ithemes.com/wp-content/uploads/2013/12/Screen-Shot-2013-12-19-at-9.54.20-AM.png\" width=\"757\" height=\"370\" /></p>
<p>9. The last two sections in the invoice editor are the <strong>Invoice Description</strong> and <strong>Notes</strong>. The Invoice Description is a quick summary of your invoice. To add additional info for your clients, use the Notes area.</p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-20797\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"Screen Shot 2013-12-19 at 9.58.36 AM\" src=\"http://ithemes.com/wp-content/uploads/2013/12/Screen-Shot-2013-12-19-at-9.58.36-AM.png\" width=\"760\" height=\"458\" /></p>
<p>10. The <strong>Advanced</strong> button can be expanded to reveal optional <strong>Product Slug</strong>, <strong>Purchase Message</strong> and <strong>Product Availability </strong>settings. You can use these fields to customize the product slug, add a custom after-purchase message and set the start and end date of the invoice availability.</p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-20798\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"Screen Shot 2013-12-19 at 10.01.06 AM\" src=\"http://ithemes.com/wp-content/uploads/2013/12/Screen-Shot-2013-12-19-at-10.01.06-AM.png\" width=\"610\" height=\"230\" /></p>
<p>11. Once your invoice is ready, you can click<strong> Save Draft</strong> and then <strong>Preview</strong>.</p>
<p style=\"text-align: center;\"><img class=\"aligncenter size-full wp-image-20803\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"Screen Shot 2013-12-19 at 10.12.41 AM\" src=\"http://ithemes.com/wp-content/uploads/2013/12/Screen-Shot-2013-12-19-at-10.12.41-AM.png\" width=\"372\" height=\"99\" /></p>
<p>This will generate a preview of your invoice before you publish (and/or email to client).</p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-20805\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"invoice-frontend\" src=\"http://ithemes.com/wp-content/uploads/2013/12/invoice-frontend.png\" width=\"1035\" height=\"917\" /></p>
<p>12. If you return back to the invoice editor, you can see the <strong>Client Link</strong> and a button to <strong>Resend email to client</strong> once you publish the invoice.</p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-20807\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"Screen Shot 2013-12-19 at 10.17.25 AM\" src=\"http://ithemes.com/wp-content/uploads/2013/12/Screen-Shot-2013-12-19-at-10.17.25-AM.png\" width=\"848\" height=\"373\" /></p>
<h3 style=\"margin-top: 40px;\">Invoice Add-on Settings</h3>
<p>Before you publish an Invoice, you&#8217;ll probably want to visit the <strong>Invoice Settings</strong> from your <strong>Exchange &gt; Add-ons</strong> Page. Click the settings gear next to the &#8220;Enabled&#8221; button.</p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-20782\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"invoices-in-add-ons\" src=\"http://ithemes.com/wp-content/uploads/2013/12/invoices-in-add-ons.png\" width=\"957\" height=\"389\" /></p>
<p>Invoice settings include options to customize the <strong>Client Email Settings. </strong>Using the possible data keys listed, you can create an <strong>Invoice Email Subject Line</strong> and the actual <strong>Invoice Email Message</strong>.</p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-20808\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"invoice-settings\" src=\"http://ithemes.com/wp-content/uploads/2013/12/invoice-settings.png\" width=\"1170\" height=\"899\" /></p>
<p>Click <strong>Save Changes.</strong></p>
<h3 style=\"margin-top: 40px;\">Publishing the Invoice</h3>
<p>Once you have previewed your invoice and customized your invoice settings, return back the invoice editor. Click <strong>Publish. </strong>All done! Your invoice can now be manually sent to your client using the <strong>Resend email to client </strong>button or it will automatically arrive in your client&#8217;s inbox based on your initial send email to client automatically settings.</p>
<p>Once the invoice has been paid, you&#8217;ll see a notice at the top of the invoice. Your invoice payments can also be viewed from the<strong> Exchange &gt; Payments</strong> page.</p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-20809\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"paid-invoice\" src=\"http://ithemes.com/wp-content/uploads/2013/12/paid-invoice.png\" width=\"1168\" height=\"795\" /></p>
<h2 style=\"margin-top: 50px;\">Purchase &amp; Download Info</h2>
<p>Note: The Invoices Add-on for Exchange requires <a href=\"http://ithemes.com/exchange\" target=\"_blank\">Exchange 1.7.9 or higher</a>. You can download Exchange for free <a href=\"http://ithemes.com/exchange/\">here</a>.</p>
<div class=\"content-callout green\"><strong>All current <a href=\"http://ithemes.com/toolkit/\">Toolkit</a>, <a href=\"http://ithemes.com/developer-suite/\">Plugin Dev Suite</a> and <a href=\"http://ithemes.com/exchange/#pricing\">Exchange Pro Pack</a> members will now find the Exchange Invoices Add-on available in their member area.</strong> Additions like the Invoices Add-on (reg. $150) are another great example of how we add value to your membership throughout the year.</div>
<p>The <a href=\"http://ithemes.com/purchase/invoices\">Exchange Invoices Add-on</a> is available in 2-site or unlimited site licenses or bundled with the Exchange Pro Pack, the Plugin Dev Suite or the WordPress Web Designer&#8217;s Toolkit.</p>
<p><a class=\"btn green\" href=\"http://ithemes.com/purchase/invoices\">Get the Invoices Add-on</a></p>
<p>The post <a href=\"http://ithemes.com/2013/12/19/send-invoices-with-wordpress/\">Send Invoices with WordPress</a> appeared first on <a href=\"http://ithemes.com\">iThemes</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"http://ithemes.com/2013/12/19/send-invoices-with-wordpress/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:42:\"
		
		
		
		
		
				

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"New Builder Theme: Jackson\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"http://ithemes.com/2013/12/18/new-builder-theme-jackson/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"http://ithemes.com/2013/12/18/new-builder-theme-jackson/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 18 Dec 2013 21:05:23 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Builder Theme\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"http://ithemes.com/?p=20736\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:570:\"<p>Check out Jackson, a brand new iThemes Builder theme that just joined our library of 90+ Builder themes. In addition to Builder&#8217;s Layout Editor and built-in responsive design, Jackson features theme-specific features that make it a really flexible theme for both blog-focused or business websites with ecommerce capabilities. Visit the Jackson Demo Feature Overview Exchange [&#8230;]</p><p>The post <a href=\"http://ithemes.com/2013/12/18/new-builder-theme-jackson/\">New Builder Theme: Jackson</a> appeared first on <a href=\"http://ithemes.com\">iThemes</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Kristen Wright\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:7623:\"<p style=\"margin-top: 40px; margin-bottom: 40px; text-align: center;\"><a href=\"http://demos.ithemes.com/jackson\"><img class=\"aligncenter  wp-image-20759\" alt=\"jackson\" src=\"http://ithemes.com/wp-content/uploads/2013/12/jackson.png\" width=\"600\" height=\"387\" /></a></p>
<p style=\"margin-top: 40px; margin-bottom: 40px;\">Check out <a href=\"http://ithemes.com/purchase/jackson/\">Jackson</a>, a brand new iThemes Builder theme that just joined our library of <a href=\"http://ithemes.com/find/builder/\">90+ Builder themes</a>. In addition to Builder&#8217;s Layout Editor and built-in responsive design, Jackson features theme-specific features that make it a really flexible theme for both blog-focused or business websites with ecommerce capabilities.</p>
<p><a class=\"btn blue\" href=\"http://demos.ithemes.com/jackson/\">Visit the Jackson Demo</a></p>
<h2 style=\"margin-top: 50px;\">Feature Overview</h2>
<ul>
<li>Exchange Styles for Store, Individual Products, Account &amp; Cart</li>
<li>Responsive Mobile Menu</li>
<li>Post Formats: Status, Quote, Image &amp; Standard</li>
<li>Alternate Module Styles: Widget Bar (Default, Transparent Background) and Image Module (Full Window, No Spacing, Default)</li>
<li>Styled Extensions</li>
<li>Unique Featured Images</li>
</ul>
<h2 style=\"margin-top: 50px;\">Exchange Styles</h2>
<p>Jackson includes theme-matching styles for <a href=\"http://ithemes.com/exchange\">Exchange</a>, our free ecommerce plugin, so you can easily set up your online store.</p>
<p>For individual products, Jackson provides styling for the product description, purchase buttons and extended product description.</p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-20737\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"individual-product\" src=\"http://ithemes.com/wp-content/uploads/2013/12/individual-product.png\" width=\"690\" height=\"806\" /></p>
<p>For the Exchange shopping cart, Jackson styles the coupon box (if you have the <a href=\"http://ithemes.com/2013/11/26/new-product-specific-coupons-in-exchange-1-7/\">Coupon Add-on</a> enabled) and makes the &#8220;Checkout&#8221; box the primary call-to-action.</p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-20738\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"Shopping Cart\" src=\"http://ithemes.com/wp-content/uploads/2013/12/Shopping-Cart.png\" width=\"695\" height=\"661\" /></p>
<h2 style=\"margin-top: 50px;\">Responsive Mobile Menu</h2>
<p>The latest Builder themes include a built-in responsive mobile menu so that mobile visitors can easily navigate your site. To use this feature, add a navigation module to your page layout from the <a href=\"http://ithemes.com/codex/page/Creating_a_Builder_Layout\">Builder Layout Editor</a>.</p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-20742\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"Screen Shot 2013-12-18 at 11.07.21 AM\" src=\"http://ithemes.com/wp-content/uploads/2013/12/Screen-Shot-2013-12-18-at-11.07.21-AM.png\" width=\"674\" height=\"316\" /></p>
<p>The mobile menu automatically appears when your site is accessed by devices with screen sizes that are less than 500px wide.</p>
<p style=\"text-align: center;\"><img class=\"aligncenter size-full wp-image-20740\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"mobile-menu\" src=\"http://ithemes.com/wp-content/uploads/2013/12/mobile-menu.png\" width=\"320\" height=\"682\" /></p>
<h2 style=\"margin-top: 60px;\">Post Format Support</h2>
<p>Jackson takes advantage of Image, Quote, Status and Standard post formats by adding unique styling for each. When adding a post, just select the type of post format you&#8217;d like to apply to the post before publishing.</p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-20744\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"post-format\" src=\"http://ithemes.com/wp-content/uploads/2013/12/post-format.png\" width=\"1060\" height=\"634\" /></p>
<p><strong>Image</strong></p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-20748\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"image-format\" src=\"http://ithemes.com/wp-content/uploads/2013/12/image-format.png\" width=\"688\" height=\"631\" /></p>
<p><strong>Standard (with Featured Image)</strong></p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-20747\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"featured-image\" src=\"http://ithemes.com/wp-content/uploads/2013/12/featured-image.png\" width=\"682\" height=\"759\" /></p>
<p><strong>Quote</strong></p>
<p><img class=\"aligncenter size-full wp-image-20745\" alt=\"quote\" src=\"http://ithemes.com/wp-content/uploads/2013/12/quote.png\" width=\"687\" height=\"484\" /></p>
<p><strong>Status</strong></p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-20746\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"status\" src=\"http://ithemes.com/wp-content/uploads/2013/12/status.png\" width=\"689\" height=\"285\" /></p>
<h2 style=\"margin-top: 60px;\">Alternate Module Styles</h2>
<p>Jackson includes <a href=\"http://ithemes.com/codex/page/Builder_Modules:_Alternate_Module_Styles\">alternate module styles</a> to change up your page layouts, including:</p>
<ul>
<li><strong>Widget Bar</strong> &#8211; Default, Transparent Background</li>
<li><strong>Image</strong> &#8211; Default, Full Window, No Spacing</li>
</ul>
<p>To use these alternate module styles, select your preferred style from Style drop-down in the <strong>Modify Module Settings</strong> box when editing or creating a layout.</p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-20749\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"image-module\" src=\"http://ithemes.com/wp-content/uploads/2013/12/image-module.png\" width=\"610\" height=\"450\" /></p>
<h2 style=\"margin-top: 40px;\">Extension Styles</h2>
<p>Last up, Jackson includes theme-matching <a href=\"http://ithemes.com/codex/page/Builder_Extensions:_Introduction\">Extension</a> styles. Extensions are one of Builder&#8217;s core features that provide additional code that changes the content, provides additional features or modifies the styling of the layout.</p>
<p>You&#8217;ll find Extension options when editing a layout or adding a View.</p>
<p style=\"text-align: center;\"><img class=\"aligncenter  wp-image-20751\" style=\"margin-top: 40px; margin-bottom: 40px;\" alt=\"extension\" src=\"http://ithemes.com/wp-content/uploads/2013/12/extension.png\" width=\"681\" height=\"461\" /></p>
<p>For more info on using Builder&#8217;s Extensions, check out the <a href=\"http://ithemes.com/codex/page/Builder_Extensions:_Introduction\">Extensions</a> page in the Codex.</p>
<h2 style=\"margin-top: 40px;\">Purchase &amp; Download Info</h2>
<p>Jackson is available for purchase as part of the <a href=\"http://ithemes.com/purchase/builder-theme/#theme-pricing\">Builder Developer Pack</a>, <a href=\"http://ithemes.com/all-access-pass/\">All Access Theme Pass</a> and <a href=\"http://ithemes.com/toolkit/\">WordPress Web Designer&#8217;s Toolkit</a>. Jackson is also available as a <a href=\"http://ithemes.com/purchase/jackson/\">stand-alone Builder theme</a>.</p>
<div class=\"content-callout green\">All current Builder Developer Pack, All Access Theme Pass and Toolkit members will find Jackson available now for immediate download from the <a href=\"http://ithemes.com/member/\">iThemes Member Panel</a>.</div>
<p><a class=\"btn blue\" href=\"http://ithemes.com/purchase/jackson/\">Get Jackson now</a></p>
<p>The post <a href=\"http://ithemes.com/2013/12/18/new-builder-theme-jackson/\">New Builder Theme: Jackson</a> appeared first on <a href=\"http://ithemes.com\">iThemes</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"http://ithemes.com/2013/12/18/new-builder-theme-jackson/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:42:\"
		
		
		
		
		
				

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"Ecommerce for Nonprofits\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"http://ithemes.com/2013/12/12/ecommerce-nonprofits/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"http://ithemes.com/2013/12/12/ecommerce-nonprofits/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 12 Dec 2013 22:05:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Exchange\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"http://ithemes.com/?p=20716\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:521:\"<p>Ecommerce isn’t just for the big boys. Nonprofits of all shapes and sizes can make use of ecommerce. That’s why we created our Exchange ecommerce plugin. We want to empower all kinds of organizations to make money online. Let’s look at three areas where ecommerce can work for nonprofits: donations, events and sales. Donations Your [&#8230;]</p><p>The post <a href=\"http://ithemes.com/2013/12/12/ecommerce-nonprofits/\">Ecommerce for Nonprofits</a> appeared first on <a href=\"http://ithemes.com\">iThemes</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Kevin D. Hendricks\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3902:\"<p>Ecommerce isn’t just for the big boys. Nonprofits of all shapes and sizes can make use of ecommerce. That’s why we created our <a href=\"http://ithemes.com/exchange/\">Exchange ecommerce plugin</a>. We want to empower all kinds of organizations to make money online.</p>
<p>Let’s look at three areas where ecommerce can work for nonprofits: <strong>donations</strong>, <strong>events</strong> and <strong>sales</strong>.</p>
<h1>Donations</h1>
<p>Your nonprofit needs donations and ecommerce can help. It might be tempting to go with a simple donation link or a third party service like <a href=\"http://www1.networkforgood.org/\">Network for Good</a>. But an ecommerce solution can give you more control and more options.</p>
<p>Adding your own ecommerce donation solution to your site has several big time benefits:</p>
<ul>
<li><strong>Better Branding:</strong> By owning the experience, you can boost your branding. You want donors to remember your nonprofit, not someone else. When you control the donation process, your name shows up on credit card statements.</li>
<li><strong>More Income:</strong> When you control the experience you can keep more of the donation. Any third party service has costs above and beyond the standard credit card fees, but if you control the process you can choose the setup that works best for you and keep more of each donation.</li>
<li><strong>More Options: </strong>It’s your store, you can do what you want. Encourage <a href=\"http://ithemes.com/purchase/recurring-payments-add-on/\">recurring giving</a>, offer <a href=\"http://ithemes.com/purchase/membership-add-on/\">membership</a>, add a <a href=\"http://ithemes.com/purchase/email-add-on-pack/\">newsletter signup</a>. You could even create a gift catalog or do <a href=\"http://ithemes.com/purchase/free-offers-add-on/\">free offers</a>. It’s up to you.</li>
</ul>
<h1>Events</h1>
<p>Another big area for nonprofits is registration and ticketing for events. While you don’t need an entire ecommerce solution to do events—you could always use services like <a href=\"http://www.eventbrite.com/\">Eventbrite</a>—it’s better to own your solution. Just like donations, you can have better branding, keep more of the money for yourself and have more options.</p>
<p>It’s easier than you think. All you have to do is create products for each event. For smaller events you can put all the details on the product page. Use the <a href=\"http://ithemes.com/purchase/featured-video-add-on/\">Featured Video</a> add-on to showcase your event.</p>
<p>You want people to come to your event, so don’t send them to another site. Keep it simple.</p>
<h1>Sales</h1>
<p>This is one area few nonprofits consider, but you can always sell stuff. What stuff? If you have a blog, letters from the field or any kind of written content, you could create an ebook. If you do events or have speakers you could sell DVDs or access to a video library. You could offer <a href=\"http://ithemes.com/publishing/join-the-club-how-to-create-a-membership-site/\">membership</a> for access to a host of resources.</p>
<p>These kinds of resources can be a valuable asset and a way to add additional income streams. Even if you give some of this content away for free in other mediums—blogs or YouTube videos—there’s still value in gathering it and bundling it as a single product. People are willing to pay for that. Your supporters especially would be willing to pay for that.</p>
<p>It’s a good way to take advantage of your content and create new income.</p>
<p><strong>Donations, events and sales are just three simple ways nonprofits can take advantage of ecommerce. Make it happen with <a href=\"http://ithemes.com/exchange/\">Exchange</a>.</strong></p>
<p>The post <a href=\"http://ithemes.com/2013/12/12/ecommerce-nonprofits/\">Ecommerce for Nonprofits</a> appeared first on <a href=\"http://ithemes.com\">iThemes</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"http://ithemes.com/2013/12/12/ecommerce-nonprofits/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:29:\"http://ithemes.com/blog/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"hourly\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";a:10:{s:4:\"date\";s:29:\"Tue, 14 Jan 2014 15:04:58 GMT\";s:6:\"server\";s:6:\"Apache\";s:4:\"vary\";s:6:\"Cookie\";s:10:\"x-pingback\";s:29:\"http://ithemes.com/xmlrpc.php\";s:13:\"last-modified\";s:29:\"Sat, 11 Jan 2014 21:57:45 GMT\";s:4:\"etag\";s:34:\"\"c05f19db0da3d6548482b7d51d5d5a3b\"\";s:10:\"set-cookie\";a:2:{i:0;s:57:\"FirstTimeVisitor=1; expires=Sun, 14-Jan-2024 15:04:58 GMT\";i:1;s:57:\"FirstTimeVisitor=1; expires=Sun, 14-Jan-2024 15:04:58 GMT\";}s:12:\"x-robots-tag\";s:14:\"noindex,follow\";s:10:\"connection\";s:5:\"close\";s:12:\"content-type\";s:23:\"text/xml; charset=UTF-8\";}s:5:\"build\";s:14:\"20140110102336\";}","no");
INSERT INTO `wp_options` VALUES("537","_transient_timeout_feed_mod_761bc2b7ca033de73fa7b3a5a0ffb39a","1389755098","no");
INSERT INTO `wp_options` VALUES("538","_transient_feed_mod_761bc2b7ca033de73fa7b3a5a0ffb39a","1389711898","no");


DROP TABLE IF EXISTS `wp_postmeta`;

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=509 DEFAULT CHARSET=utf8;

INSERT INTO `wp_postmeta` VALUES("1","2","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("12","9","_form","<p>Your Name (required)<br />
    [text* your-name] </p>

<p>Your Email (required)<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>

<p>Your Message<br />
    [textarea your-message] </p>

<p>[submit \"Send\"]</p>");
INSERT INTO `wp_postmeta` VALUES("13","9","_mail","a:7:{s:7:\"subject\";s:27:\"Massage Therapy Information\";s:6:\"sender\";s:26:\"[your-name] <[your-email]>\";s:4:\"body\";s:172:\"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Kw Massage (http://www.kwmassage.com)\";s:9:\"recipient\";s:20:\"jeremy@kwmassage.com\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;}");
INSERT INTO `wp_postmeta` VALUES("14","9","_mail_2","a:8:{s:6:\"active\";b:0;s:7:\"subject\";s:14:\"[your-subject]\";s:6:\"sender\";s:26:\"[your-name] <[your-email]>\";s:4:\"body\";s:114:\"Message Body:
[your-message]

--
This e-mail was sent from a contact form on Kw Massage (http://www.kwmassage.com)\";s:9:\"recipient\";s:12:\"[your-email]\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;}");
INSERT INTO `wp_postmeta` VALUES("15","9","_messages","a:21:{s:12:\"mail_sent_ok\";s:43:\"Your message was sent successfully. Thanks.\";s:12:\"mail_sent_ng\";s:93:\"Failed to send your message. Please try later or contact the administrator by another method.\";s:16:\"validation_error\";s:74:\"Validation errors occurred. Please confirm the fields and submit it again.\";s:4:\"spam\";s:93:\"Failed to send your message. Please try later or contact the administrator by another method.\";s:12:\"accept_terms\";s:35:\"Please accept the terms to proceed.\";s:16:\"invalid_required\";s:31:\"Please fill the required field.\";s:17:\"captcha_not_match\";s:31:\"Your entered code is incorrect.\";s:14:\"invalid_number\";s:28:\"Number format seems invalid.\";s:16:\"number_too_small\";s:25:\"This number is too small.\";s:16:\"number_too_large\";s:25:\"This number is too large.\";s:13:\"invalid_email\";s:28:\"Email address seems invalid.\";s:11:\"invalid_url\";s:18:\"URL seems invalid.\";s:11:\"invalid_tel\";s:31:\"Telephone number seems invalid.\";s:23:\"quiz_answer_not_correct\";s:27:\"Your answer is not correct.\";s:12:\"invalid_date\";s:26:\"Date format seems invalid.\";s:14:\"date_too_early\";s:23:\"This date is too early.\";s:13:\"date_too_late\";s:22:\"This date is too late.\";s:13:\"upload_failed\";s:22:\"Failed to upload file.\";s:24:\"upload_file_type_invalid\";s:30:\"This file type is not allowed.\";s:21:\"upload_file_too_large\";s:23:\"This file is too large.\";s:23:\"upload_failed_php_error\";s:38:\"Failed to upload file. Error occurred.\";}");
INSERT INTO `wp_postmeta` VALUES("16","9","_additional_settings","");
INSERT INTO `wp_postmeta` VALUES("17","9","_locale","en_US");
INSERT INTO `wp_postmeta` VALUES("18","10","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("19","10","_edit_lock","1389353779:1");
INSERT INTO `wp_postmeta` VALUES("20","10","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("506","21","_aioseop_title","Contact Information for Kitchener Massage Therapy");
INSERT INTO `wp_postmeta` VALUES("450","238","_edit_lock","1389635515:1");
INSERT INTO `wp_postmeta` VALUES("442","234","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("441","234","_edit_lock","1389630097:1");
INSERT INTO `wp_postmeta` VALUES("28","2","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("29","2","_wp_trash_meta_time","1389354439");
INSERT INTO `wp_postmeta` VALUES("30","10","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("31","10","_wp_trash_meta_time","1389354448");
INSERT INTO `wp_postmeta` VALUES("52","21","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("53","19","_edit_lock","1389643020:1");
INSERT INTO `wp_postmeta` VALUES("51","21","_edit_lock","1389644029:1");
INSERT INTO `wp_postmeta` VALUES("37","19","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("38","7","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("39","20","_wp_page_template","onecolumn-page.php");
INSERT INTO `wp_postmeta` VALUES("40","21","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("41","22","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("42","23","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("43","24","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("436","226","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("437","226","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("50","75","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("54","19","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("55","75","_edit_lock","1389643080:1");
INSERT INTO `wp_postmeta` VALUES("56","75","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("204","23","_edit_lock","1389360426:1");
INSERT INTO `wp_postmeta` VALUES("205","24","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("258","121","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1800;s:6:\"height\";i:550;s:4:\"file\";s:26:\"2014/01/bg_body_summer.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:26:\"bg_body_summer-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"bg_body_summer-300x91.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:91;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:27:\"bg_body_summer-1024x312.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:312;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:26:\"bg_body_summer-940x198.jpg\";s:5:\"width\";i:940;s:6:\"height\";i:198;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("257","121","_wp_attached_file","2014/01/bg_body_summer.jpg");
INSERT INTO `wp_postmeta` VALUES("206","24","_edit_lock","1389360443:1");
INSERT INTO `wp_postmeta` VALUES("201","22","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("207","105","_menu_item_type","custom");
INSERT INTO `wp_postmeta` VALUES("260","122","_wp_attachment_metadata","a:5:{s:5:\"width\";i:323;s:6:\"height\";i:49;s:4:\"file\";s:28:\"2014/01/bg_contactnumber.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"bg_contactnumber-150x49.png\";s:5:\"width\";i:150;s:6:\"height\";i:49;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"bg_contactnumber-300x45.png\";s:5:\"width\";i:300;s:6:\"height\";i:45;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("259","122","_wp_attached_file","2014/01/bg_contactnumber.png");
INSERT INTO `wp_postmeta` VALUES("208","105","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("256","120","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1800;s:6:\"height\";i:550;s:4:\"file\";s:28:\"2014/01/bg_body_mountain.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"bg_body_mountain-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"bg_body_mountain-300x91.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:91;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:29:\"bg_body_mountain-1024x312.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:312;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:28:\"bg_body_mountain-940x198.jpg\";s:5:\"width\";i:940;s:6:\"height\";i:198;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("203","23","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("255","120","_wp_attached_file","2014/01/bg_body_mountain.jpg");
INSERT INTO `wp_postmeta` VALUES("209","105","_menu_item_object_id","105");
INSERT INTO `wp_postmeta` VALUES("252","7","_edit_lock","1389559252:1");
INSERT INTO `wp_postmeta` VALUES("202","22","_edit_lock","1389360417:1");
INSERT INTO `wp_postmeta` VALUES("210","105","_menu_item_object","custom");
INSERT INTO `wp_postmeta` VALUES("211","105","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("212","105","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("213","105","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("214","105","_menu_item_url","http://www.kwmassage.com/");
INSERT INTO `wp_postmeta` VALUES("216","106","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("217","106","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("218","106","_menu_item_object_id","19");
INSERT INTO `wp_postmeta` VALUES("219","106","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("220","106","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("221","106","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("222","106","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("223","106","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("262","123","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1800;s:6:\"height\";i:355;s:4:\"file\";s:24:\"2014/01/bg_container.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"bg_container-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"bg_container-300x59.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:59;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:25:\"bg_container-1024x201.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:201;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:24:\"bg_container-940x198.jpg\";s:5:\"width\";i:940;s:6:\"height\";i:198;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("225","107","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("226","107","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("227","107","_menu_item_object_id","7");
INSERT INTO `wp_postmeta` VALUES("228","107","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("229","107","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("230","107","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("231","107","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("232","107","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("234","108","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("235","108","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("236","108","_menu_item_object_id","21");
INSERT INTO `wp_postmeta` VALUES("237","108","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("238","108","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("239","108","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("240","108","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("241","108","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("261","123","_wp_attached_file","2014/01/bg_container.jpg");
INSERT INTO `wp_postmeta` VALUES("243","109","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("244","109","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("245","109","_menu_item_object_id","20");
INSERT INTO `wp_postmeta` VALUES("246","109","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("247","109","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("248","109","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("249","109","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("250","109","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("263","124","_wp_attached_file","2014/01/bg_container_top.png");
INSERT INTO `wp_postmeta` VALUES("264","124","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1036;s:6:\"height\";i:370;s:4:\"file\";s:28:\"2014/01/bg_container_top.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"bg_container_top-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"bg_container_top-300x107.png\";s:5:\"width\";i:300;s:6:\"height\";i:107;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:29:\"bg_container_top-1024x365.png\";s:5:\"width\";i:1024;s:6:\"height\";i:365;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:28:\"bg_container_top-940x198.png\";s:5:\"width\";i:940;s:6:\"height\";i:198;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("265","125","_wp_attached_file","2014/01/bg_footer_bottom.gif");
INSERT INTO `wp_postmeta` VALUES("266","125","_wp_attachment_metadata","a:5:{s:5:\"width\";i:916;s:6:\"height\";i:20;s:4:\"file\";s:28:\"2014/01/bg_footer_bottom.gif\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"bg_footer_bottom-150x20.gif\";s:5:\"width\";i:150;s:6:\"height\";i:20;s:9:\"mime-type\";s:9:\"image/gif\";}s:6:\"medium\";a:4:{s:4:\"file\";s:26:\"bg_footer_bottom-300x6.gif\";s:5:\"width\";i:300;s:6:\"height\";i:6;s:9:\"mime-type\";s:9:\"image/gif\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("267","126","_wp_attached_file","2014/01/bg_footermid.gif");
INSERT INTO `wp_postmeta` VALUES("268","126","_wp_attachment_metadata","a:5:{s:5:\"width\";i:610;s:6:\"height\";i:15;s:4:\"file\";s:24:\"2014/01/bg_footermid.gif\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"bg_footermid-150x15.gif\";s:5:\"width\";i:150;s:6:\"height\";i:15;s:9:\"mime-type\";s:9:\"image/gif\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"bg_footermid-300x7.gif\";s:5:\"width\";i:300;s:6:\"height\";i:7;s:9:\"mime-type\";s:9:\"image/gif\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("269","127","_wp_attached_file","2014/01/bg_formbox.png");
INSERT INTO `wp_postmeta` VALUES("270","127","_wp_attachment_metadata","a:5:{s:5:\"width\";i:540;s:6:\"height\";i:26;s:4:\"file\";s:22:\"2014/01/bg_formbox.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"bg_formbox-150x26.png\";s:5:\"width\";i:150;s:6:\"height\";i:26;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"bg_formbox-300x14.png\";s:5:\"width\";i:300;s:6:\"height\";i:14;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("271","128","_wp_attached_file","2014/01/bg_heading_menu.gif");
INSERT INTO `wp_postmeta` VALUES("272","128","_wp_attachment_metadata","a:5:{s:5:\"width\";i:337;s:6:\"height\";i:62;s:4:\"file\";s:27:\"2014/01/bg_heading_menu.gif\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:26:\"bg_heading_menu-150x62.gif\";s:5:\"width\";i:150;s:6:\"height\";i:62;s:9:\"mime-type\";s:9:\"image/gif\";}s:6:\"medium\";a:4:{s:4:\"file\";s:26:\"bg_heading_menu-300x55.gif\";s:5:\"width\";i:300;s:6:\"height\";i:55;s:9:\"mime-type\";s:9:\"image/gif\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("273","129","_wp_attached_file","2014/01/bg_listlink.gif");
INSERT INTO `wp_postmeta` VALUES("274","129","_wp_attachment_metadata","a:5:{s:5:\"width\";i:337;s:6:\"height\";i:40;s:4:\"file\";s:23:\"2014/01/bg_listlink.gif\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"bg_listlink-150x40.gif\";s:5:\"width\";i:150;s:6:\"height\";i:40;s:9:\"mime-type\";s:9:\"image/gif\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"bg_listlink-300x35.gif\";s:5:\"width\";i:300;s:6:\"height\";i:35;s:9:\"mime-type\";s:9:\"image/gif\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("275","130","_wp_attached_file","2014/01/bg_listmenu.gif");
INSERT INTO `wp_postmeta` VALUES("276","130","_wp_attachment_metadata","a:5:{s:5:\"width\";i:253;s:6:\"height\";i:35;s:4:\"file\";s:23:\"2014/01/bg_listmenu.gif\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"bg_listmenu-150x35.gif\";s:5:\"width\";i:150;s:6:\"height\";i:35;s:9:\"mime-type\";s:9:\"image/gif\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("277","131","_wp_attached_file","2014/01/bg_nav.png");
INSERT INTO `wp_postmeta` VALUES("278","131","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1800;s:6:\"height\";i:60;s:4:\"file\";s:18:\"2014/01/bg_nav.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"bg_nav-150x60.png\";s:5:\"width\";i:150;s:6:\"height\";i:60;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"bg_nav-300x10.png\";s:5:\"width\";i:300;s:6:\"height\";i:10;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:18:\"bg_nav-1024x34.png\";s:5:\"width\";i:1024;s:6:\"height\";i:34;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:17:\"bg_nav-940x60.png\";s:5:\"width\";i:940;s:6:\"height\";i:60;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("279","132","_wp_attached_file","2014/01/bg_nav_hover.gif");
INSERT INTO `wp_postmeta` VALUES("280","132","_wp_attachment_metadata","a:5:{s:5:\"width\";i:191;s:6:\"height\";i:42;s:4:\"file\";s:24:\"2014/01/bg_nav_hover.gif\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"bg_nav_hover-150x42.gif\";s:5:\"width\";i:150;s:6:\"height\";i:42;s:9:\"mime-type\";s:9:\"image/gif\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("281","133","_wp_attached_file","2014/01/bg_nav_old.png");
INSERT INTO `wp_postmeta` VALUES("282","133","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1800;s:6:\"height\";i:60;s:4:\"file\";s:22:\"2014/01/bg_nav_old.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"bg_nav_old-150x60.png\";s:5:\"width\";i:150;s:6:\"height\";i:60;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"bg_nav_old-300x10.png\";s:5:\"width\";i:300;s:6:\"height\";i:10;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:22:\"bg_nav_old-1024x34.png\";s:5:\"width\";i:1024;s:6:\"height\";i:34;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"bg_nav_old-940x60.png\";s:5:\"width\";i:940;s:6:\"height\";i:60;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("283","134","_wp_attached_file","2014/01/bg_navold.png");
INSERT INTO `wp_postmeta` VALUES("284","134","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1790;s:6:\"height\";i:60;s:4:\"file\";s:21:\"2014/01/bg_navold.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"bg_navold-150x60.png\";s:5:\"width\";i:150;s:6:\"height\";i:60;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"bg_navold-300x10.png\";s:5:\"width\";i:300;s:6:\"height\";i:10;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"bg_navold-1024x34.png\";s:5:\"width\";i:1024;s:6:\"height\";i:34;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:20:\"bg_navold-940x60.png\";s:5:\"width\";i:940;s:6:\"height\";i:60;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("285","135","_wp_attached_file","2014/01/bg_ratebox.png");
INSERT INTO `wp_postmeta` VALUES("286","135","_wp_attachment_metadata","a:5:{s:5:\"width\";i:350;s:6:\"height\";i:135;s:4:\"file\";s:22:\"2014/01/bg_ratebox.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"bg_ratebox-150x135.png\";s:5:\"width\";i:150;s:6:\"height\";i:135;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"bg_ratebox-300x115.png\";s:5:\"width\";i:300;s:6:\"height\";i:115;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("287","136","_wp_attached_file","2014/01/bg_submenin.gif");
INSERT INTO `wp_postmeta` VALUES("288","136","_wp_attachment_metadata","a:5:{s:5:\"width\";i:350;s:6:\"height\";i:1;s:4:\"file\";s:23:\"2014/01/bg_submenin.gif\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"bg_submenin-150x1.gif\";s:5:\"width\";i:150;s:6:\"height\";i:1;s:9:\"mime-type\";s:9:\"image/gif\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"bg_submenin-300x1.gif\";s:5:\"width\";i:300;s:6:\"height\";i:1;s:9:\"mime-type\";s:9:\"image/gif\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("289","137","_wp_attached_file","2014/01/bg_submenushadow.gif");
INSERT INTO `wp_postmeta` VALUES("290","137","_wp_attachment_metadata","a:5:{s:5:\"width\";i:350;s:6:\"height\";i:20;s:4:\"file\";s:28:\"2014/01/bg_submenushadow.gif\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"bg_submenushadow-150x20.gif\";s:5:\"width\";i:150;s:6:\"height\";i:20;s:9:\"mime-type\";s:9:\"image/gif\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"bg_submenushadow-300x17.gif\";s:5:\"width\";i:300;s:6:\"height\";i:17;s:9:\"mime-type\";s:9:\"image/gif\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("291","138","_wp_attached_file","2014/01/bg_tagline.png");
INSERT INTO `wp_postmeta` VALUES("292","138","_wp_attachment_metadata","a:5:{s:5:\"width\";i:575;s:6:\"height\";i:49;s:4:\"file\";s:22:\"2014/01/bg_tagline.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"bg_tagline-150x49.png\";s:5:\"width\";i:150;s:6:\"height\";i:49;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"bg_tagline-300x25.png\";s:5:\"width\";i:300;s:6:\"height\";i:25;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("293","139","_wp_attached_file","2014/01/bg_tagline_old.png");
INSERT INTO `wp_postmeta` VALUES("294","139","_wp_attachment_metadata","a:5:{s:5:\"width\";i:575;s:6:\"height\";i:49;s:4:\"file\";s:26:\"2014/01/bg_tagline_old.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"bg_tagline_old-150x49.png\";s:5:\"width\";i:150;s:6:\"height\";i:49;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"bg_tagline_old-300x25.png\";s:5:\"width\";i:300;s:6:\"height\";i:25;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("295","140","_wp_attached_file","2014/01/bg_testimonialbox.gif");
INSERT INTO `wp_postmeta` VALUES("296","140","_wp_attachment_metadata","a:5:{s:5:\"width\";i:528;s:6:\"height\";i:10;s:4:\"file\";s:29:\"2014/01/bg_testimonialbox.gif\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"bg_testimonialbox-150x10.gif\";s:5:\"width\";i:150;s:6:\"height\";i:10;s:9:\"mime-type\";s:9:\"image/gif\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"bg_testimonialbox-300x5.gif\";s:5:\"width\";i:300;s:6:\"height\";i:5;s:9:\"mime-type\";s:9:\"image/gif\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("297","141","_wp_attached_file","2014/01/bg_textarea.gif");
INSERT INTO `wp_postmeta` VALUES("298","141","_wp_attachment_metadata","a:5:{s:5:\"width\";i:526;s:6:\"height\";i:115;s:4:\"file\";s:23:\"2014/01/bg_textarea.gif\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"bg_textarea-150x115.gif\";s:5:\"width\";i:150;s:6:\"height\";i:115;s:9:\"mime-type\";s:9:\"image/gif\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"bg_textarea-300x65.gif\";s:5:\"width\";i:300;s:6:\"height\";i:65;s:9:\"mime-type\";s:9:\"image/gif\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("299","142","_wp_attached_file","2014/01/bg_tfw.gif");
INSERT INTO `wp_postmeta` VALUES("300","142","_wp_attachment_metadata","a:5:{s:5:\"width\";i:253;s:6:\"height\";i:35;s:4:\"file\";s:18:\"2014/01/bg_tfw.gif\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"bg_tfw-150x35.gif\";s:5:\"width\";i:150;s:6:\"height\";i:35;s:9:\"mime-type\";s:9:\"image/gif\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("301","143","_wp_attached_file","2014/01/bg_tfw2.gif");
INSERT INTO `wp_postmeta` VALUES("302","143","_wp_attachment_metadata","a:5:{s:5:\"width\";i:253;s:6:\"height\";i:35;s:4:\"file\";s:19:\"2014/01/bg_tfw2.gif\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"bg_tfw2-150x35.gif\";s:5:\"width\";i:150;s:6:\"height\";i:35;s:9:\"mime-type\";s:9:\"image/gif\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("303","144","_wp_attached_file","2014/01/bullet_blue.gif");
INSERT INTO `wp_postmeta` VALUES("304","144","_wp_attachment_metadata","a:5:{s:5:\"width\";i:6;s:6:\"height\";i:6;s:4:\"file\";s:23:\"2014/01/bullet_blue.gif\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("305","145","_wp_attached_file","2014/01/bullet_circle.gif");
INSERT INTO `wp_postmeta` VALUES("306","145","_wp_attachment_metadata","a:5:{s:5:\"width\";i:4;s:6:\"height\";i:4;s:4:\"file\";s:25:\"2014/01/bullet_circle.gif\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("307","146","_wp_attached_file","2014/01/divider_gray.gif");
INSERT INTO `wp_postmeta` VALUES("308","146","_wp_attachment_metadata","a:5:{s:5:\"width\";i:4;s:6:\"height\";i:10;s:4:\"file\";s:24:\"2014/01/divider_gray.gif\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("309","147","_wp_attached_file","2014/01/icon_arrow.png");
INSERT INTO `wp_postmeta` VALUES("310","147","_wp_attachment_metadata","a:5:{s:5:\"width\";i:15;s:6:\"height\";i:15;s:4:\"file\";s:22:\"2014/01/icon_arrow.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("311","148","_wp_attached_file","2014/01/icon_clear.gif");
INSERT INTO `wp_postmeta` VALUES("312","148","_wp_attachment_metadata","a:5:{s:5:\"width\";i:15;s:6:\"height\";i:15;s:4:\"file\";s:22:\"2014/01/icon_clear.gif\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("313","149","_wp_attached_file","2014/01/icon_graysend.gif");
INSERT INTO `wp_postmeta` VALUES("314","149","_wp_attachment_metadata","a:5:{s:5:\"width\";i:15;s:6:\"height\";i:15;s:4:\"file\";s:25:\"2014/01/icon_graysend.gif\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("315","150","_wp_attached_file","2014/01/icon_send.gif");
INSERT INTO `wp_postmeta` VALUES("316","150","_wp_attachment_metadata","a:5:{s:5:\"width\";i:15;s:6:\"height\";i:15;s:4:\"file\";s:21:\"2014/01/icon_send.gif\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("317","151","_wp_attached_file","2014/01/img_1.jpg");
INSERT INTO `wp_postmeta` VALUES("318","151","_wp_attachment_metadata","a:5:{s:5:\"width\";i:250;s:6:\"height\";i:180;s:4:\"file\";s:17:\"2014/01/img_1.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"img_1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("319","152","_wp_attached_file","2014/01/img_bg.gif");
INSERT INTO `wp_postmeta` VALUES("320","152","_wp_attachment_metadata","a:5:{s:5:\"width\";i:270;s:6:\"height\";i:210;s:4:\"file\";s:18:\"2014/01/img_bg.gif\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"img_bg-150x150.gif\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/gif\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:18:\"img_bg-270x198.gif\";s:5:\"width\";i:270;s:6:\"height\";i:198;s:9:\"mime-type\";s:9:\"image/gif\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("321","153","_wp_attached_file","2014/01/img_comabottom.gif");
INSERT INTO `wp_postmeta` VALUES("322","153","_wp_attachment_metadata","a:5:{s:5:\"width\";i:34;s:6:\"height\";i:30;s:4:\"file\";s:26:\"2014/01/img_comabottom.gif\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("323","154","_wp_attached_file","2014/01/img_comatop.gif");
INSERT INTO `wp_postmeta` VALUES("324","154","_wp_attachment_metadata","a:5:{s:5:\"width\";i:34;s:6:\"height\";i:30;s:4:\"file\";s:23:\"2014/01/img_comatop.gif\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("325","155","_wp_attached_file","2014/01/img_video.gif");
INSERT INTO `wp_postmeta` VALUES("326","155","_wp_attachment_metadata","a:5:{s:5:\"width\";i:350;s:6:\"height\";i:322;s:4:\"file\";s:21:\"2014/01/img_video.gif\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"img_video-150x150.gif\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/gif\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"img_video-300x276.gif\";s:5:\"width\";i:300;s:6:\"height\";i:276;s:9:\"mime-type\";s:9:\"image/gif\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"img_video-350x198.gif\";s:5:\"width\";i:350;s:6:\"height\";i:198;s:9:\"mime-type\";s:9:\"image/gif\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("327","156","_wp_attached_file","2014/01/KWMassage-1f_u3011-copy_12-02.png");
INSERT INTO `wp_postmeta` VALUES("328","156","_wp_attachment_metadata","a:5:{s:5:\"width\";i:9;s:6:\"height\";i:60;s:4:\"file\";s:41:\"2014/01/KWMassage-1f_u3011-copy_12-02.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("329","157","_wp_attached_file","2014/01/logo.png");
INSERT INTO `wp_postmeta` VALUES("330","157","_wp_attachment_metadata","a:5:{s:5:\"width\";i:92;s:6:\"height\";i:82;s:4:\"file\";s:16:\"2014/01/logo.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("331","155","_edit_lock","1389554753:1");
INSERT INTO `wp_postmeta` VALUES("349","7","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("350","155","_wp_attachment_image_alt","Jeremy Bissonnette, Registered Massage Therapist");
INSERT INTO `wp_postmeta` VALUES("357","20","_edit_lock","1389559241:1");
INSERT INTO `wp_postmeta` VALUES("449","238","_wp_attachment_metadata","a:5:{s:5:\"width\";i:570;s:6:\"height\";i:470;s:4:\"file\";s:31:\"2014/01/trigger_point_chart.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"trigger_point_chart-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"trigger_point_chart-300x247.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:247;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:31:\"trigger_point_chart-570x198.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:198;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("440","234","_wp_attached_file","2014/01/Health-History.pdf");
INSERT INTO `wp_postmeta` VALUES("438","226","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("435","226","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("413","216","_edit_lock","1389564088:1");
INSERT INTO `wp_postmeta` VALUES("433","226","_menu_item_object_id","224");
INSERT INTO `wp_postmeta` VALUES("418","219","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("419","219","_edit_lock","1389635280:1");
INSERT INTO `wp_postmeta` VALUES("432","226","_menu_item_menu_item_parent","107");
INSERT INTO `wp_postmeta` VALUES("422","221","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("423","221","_edit_lock","1389630418:1");
INSERT INTO `wp_postmeta` VALUES("431","226","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("428","224","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("429","224","_edit_lock","1389630123:1");
INSERT INTO `wp_postmeta` VALUES("430","224","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("412","216","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("406","211","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("407","211","_edit_lock","1389563761:1");
INSERT INTO `wp_postmeta` VALUES("434","226","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("448","238","_wp_attached_file","2014/01/trigger_point_chart.jpg");
INSERT INTO `wp_postmeta` VALUES("453","238","_wp_attachment_image_alt","Massage Therapy Trigger Point Chart");
INSERT INTO `wp_postmeta` VALUES("454","238","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("455","241","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("456","241","_edit_lock","1389641452:1");
INSERT INTO `wp_postmeta` VALUES("457","241","_wp_trash_meta_status","draft");
INSERT INTO `wp_postmeta` VALUES("458","241","_wp_trash_meta_time","1389641499");
INSERT INTO `wp_postmeta` VALUES("459","244","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("463","246","_wp_attached_file","2014/01/levator-stretch-pic.jpg");
INSERT INTO `wp_postmeta` VALUES("462","244","_edit_lock","1389641769:1");
INSERT INTO `wp_postmeta` VALUES("464","246","_wp_attachment_metadata","a:5:{s:5:\"width\";i:191;s:6:\"height\";i:120;s:4:\"file\";s:31:\"2014/01/levator-stretch-pic.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"levator-stretch-pic-150x120.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:120;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("465","247","_wp_attached_file","2014/01/up-trap-stretch-picture.jpg");
INSERT INTO `wp_postmeta` VALUES("466","247","_wp_attachment_metadata","a:5:{s:5:\"width\";i:195;s:6:\"height\";i:151;s:4:\"file\";s:35:\"2014/01/up-trap-stretch-picture.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"up-trap-stretch-picture-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("467","247","_wp_attachment_image_alt","Stretch Upper Trap");
INSERT INTO `wp_postmeta` VALUES("471","249","_edit_lock","1389642069:1");
INSERT INTO `wp_postmeta` VALUES("470","249","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("475","251","_edit_lock","1389643720:1");
INSERT INTO `wp_postmeta` VALUES("474","251","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("492","257","_edit_lock","1389642907:1");
INSERT INTO `wp_postmeta` VALUES("478","253","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("491","257","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("481","253","_edit_lock","1389644648:1");
INSERT INTO `wp_postmeta` VALUES("484","253","_wp_old_slug","tension-headaches");
INSERT INTO `wp_postmeta` VALUES("493","22","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("494","22","_wp_trash_meta_time","1389643122");
INSERT INTO `wp_postmeta` VALUES("495","23","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("496","23","_wp_trash_meta_time","1389643122");
INSERT INTO `wp_postmeta` VALUES("497","24","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("498","24","_wp_trash_meta_time","1389643122");
INSERT INTO `wp_postmeta` VALUES("499","259","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("500","259","_edit_lock","1389643939:1");
INSERT INTO `wp_postmeta` VALUES("501","259","_wp_page_template","default");


DROP TABLE IF EXISTS `wp_posts`;

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=MyISAM AUTO_INCREMENT=272 DEFAULT CHARSET=utf8;

INSERT INTO `wp_posts` VALUES("2","3","2014-01-10 10:46:52","2014-01-10 10:46:52","This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href=\"http://www.kwmassage.com/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!","Sample Page","","trash","open","open","","sample-page","","","2014-01-10 11:47:19","2014-01-10 11:47:19","","0","http://www.kwmassage.com/?page_id=2","0","page","","0");
INSERT INTO `wp_posts` VALUES("3","3","2014-01-10 10:48:02","0000-00-00 00:00:00","","Auto Draft","","auto-draft","open","open","","","","","2014-01-10 10:48:02","0000-00-00 00:00:00","","0","http://www.kwmassage.com/?p=3","0","post","","0");
INSERT INTO `wp_posts` VALUES("99","3","2014-01-10 13:21:38","2014-01-10 13:21:38","<p><a href=\"#\"><img src=\"http://test.xhtmlchop.com/blog853/wp-content/themes/6261/images/img_1.jpg\" alt=\"Image\" class=\"imgbox\" /></a>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>In feugiat velit non lectus hendrerit id condimentum purus tempus. Ut malesuada varius mi, id sagittis mi hendrerit eu.</p>
<div class=\"shadowbox\">
<h2>This Is an H2 Tag</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
<ul class=\"blue\">
<li>List item 1</li>
<li>List Item 2</li>
</ul>
<ol class=\"number\">
<li>List item 1</li>
<li>List Item 2</li>
</ol>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
</div>","About Jeremy Bissonnette link1","","inherit","open","open","","22-revision-v1","","","2014-01-10 13:21:38","2014-01-10 13:21:38","","22","http://www.kwmassage.com/?p=99","0","revision","","0");
INSERT INTO `wp_posts` VALUES("9","3","2014-01-10 11:17:50","2014-01-10 11:17:50","<p>Your Name (required)<br />
    [text* your-name] </p>

<p>Your Email (required)<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>

<p>Your Message<br />
    [textarea your-message] </p>

<p>[submit \"Send\"]</p>
Massage Therapy Information
[your-name] <[your-email]>
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Kw Massage (http://www.kwmassage.com)
jeremy@kwmassage.com




[your-subject]
[your-name] <[your-email]>
Message Body:
[your-message]

--
This e-mail was sent from a contact form on Kw Massage (http://www.kwmassage.com)
[your-email]



Your message was sent successfully. Thanks.
Failed to send your message. Please try later or contact the administrator by another method.
Validation errors occurred. Please confirm the fields and submit it again.
Failed to send your message. Please try later or contact the administrator by another method.
Please accept the terms to proceed.
Please fill the required field.
Your entered code is incorrect.
Number format seems invalid.
This number is too small.
This number is too large.
Email address seems invalid.
URL seems invalid.
Telephone number seems invalid.
Your answer is not correct.
Date format seems invalid.
This date is too early.
This date is too late.
Failed to upload file.
This file type is not allowed.
This file is too large.
Failed to upload file. Error occurred.","Contact form 1","","publish","open","open","","contact-form-1","","","2014-01-11 17:56:45","2014-01-11 17:56:45","","0","http://www.kwmassage.com/?post_type=wpcf7_contact_form&#038;p=9","0","wpcf7_contact_form","","0");
INSERT INTO `wp_posts` VALUES("10","3","2014-01-10 11:20:49","2014-01-10 11:20:49","[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Contact Us","","trash","closed","closed","","contact-us","","","2014-01-10 11:47:28","2014-01-10 11:47:28","","0","http://www.kwmassage.com/?page_id=10","0","page","","0");
INSERT INTO `wp_posts` VALUES("11","3","2014-01-10 11:20:49","2014-01-10 11:20:49","","Contact Us","","inherit","open","open","","10-revision-v1","","","2014-01-10 11:20:49","2014-01-10 11:20:49","","10","http://www.kwmassage.com/?p=11","0","revision","","0");
INSERT INTO `wp_posts` VALUES("12","3","2014-01-10 11:23:40","2014-01-10 11:23:40","[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Contact Us","","inherit","open","open","","10-revision-v1","","","2014-01-10 11:23:40","2014-01-10 11:23:40","","10","http://www.kwmassage.com/?p=12","0","revision","","0");
INSERT INTO `wp_posts` VALUES("113","3","2014-01-12 20:59:29","2014-01-12 20:59:29","<a href=\"http://youtu.be/XSRrvEXZSdk\" target=\"_blank\" rel=\"http://youtu.be/XSRrvEXZSdk\"><img class=\" wp-image-155 alignleft\" alt=\"Jeremy Bissonnette, Registered Massage Therapist\" src=\"http://www.kwmassage.com/wp-content/uploads/2014/01/img_video-300x276.gif\" width=\"240\" height=\"221\" /></a>I graduated with Honours from the <a href=\"http://www.collegeofmassage.com/cambridge/\">Canadian College of Massage and Hydrotherapy </a>in 2005 as a <a href=\"http://www.cmto.com/\">Registered Massage Therapist </a>(RMT). I’ve practiced massage therapy in Kitchener and Waterloo in a variety of locations in including a home practice, the <a href=\"http://www.uoguelph.ca/hpc/\">University of Guelph’s Health and Performance Center, </a>and most recently, in an independently owned chiropractic office. I have also provided chair treatments at the <a href=\"http://www.kitchenermarket.ca/\">Kitchener Market </a>on a monthly basis in the past.

My massage therapy treatment style has been focused around <a href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">Deep Tissue Therapy </a>with an emphasis on helping clients learn to care for their own bodies. I have practiced yoga for the past 10 years and find my clients respond well to my recommendations around specific yoga asana and stretches to help with the different ailments they need to address. I find my knowledge of anatomy helps create clarity on the yoga mat and I have an interest in sharing this experience.
<div class=\"shadowbox\">
<h2>My Personal World</h2>
My main focus in life is caring for my 2 daughters, Rowan (7) and Breanne (5). I’m busy getting kids fed, dressed, doing hair, making bread, doing homework and housework, planning a garden, and all the activities associated with being a parent. Being a dad can have its challenges but it is also very rewarding. I feel very lucky to be able to fill this role while my wife works full-time.

In my spare time, I enjoy <a href=\"http://www.kwmassage.com/rock_climbing/rock-climbing-as-a-life-style\">rock climbing</a>, yoga, reading, camping, and gardening. Prior to becoming a registered massage therapist, I used to work in a <a href=\"http://www.paramountsports.ca/\">bike and snow board shop</a>, so when I can, I love to hit the hills and get back to my original roots.

</div>","About Jeremy","","inherit","open","open","","19-autosave-v1","","","2014-01-12 20:59:29","2014-01-12 20:59:29","","19","http://www.kwmassage.com/?p=113","0","revision","","0");
INSERT INTO `wp_posts` VALUES("16","3","2014-01-10 11:47:19","2014-01-10 11:47:19","This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href=\"http://www.kwmassage.com/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!","Sample Page","","inherit","open","open","","2-revision-v1","","","2014-01-10 11:47:19","2014-01-10 11:47:19","","2","http://www.kwmassage.com/?p=16","0","revision","","0");
INSERT INTO `wp_posts` VALUES("111","3","2014-01-10 14:26:03","2014-01-10 14:26:03","Specializing in Deep Tissue Massage and Trigger Point Release Therapy to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace and family life.

<span class=\"black\">(519) 745-4112</span><span class=\"black\">jeremy@kwmassage.com</span><span class=\"black\">7 Clarence Place</span><span class=\"black\">Kitchener, On</span>
<div id=\"formbox\">
<h1>Contact Form</h1>
</div>
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Contact Jeremy","","inherit","open","open","","21-revision-v1","","","2014-01-10 14:26:03","2014-01-10 14:26:03","","21","http://www.kwmassage.com/?p=111","0","revision","","0");
INSERT INTO `wp_posts` VALUES("76","3","2014-01-10 11:49:44","2014-01-10 11:49:44","<p>Specializing in Deep Tissue Massage and Trigger Point Release Therapy to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace and family life.</p>
<p>
<span class=\"black\">(519) 745-4112</span><span class=\"black\">jeremy@kwmassage.com</span><span class=\"black\">7 Clarence Place</span><span class=\"black\">Kitchener, On</span></p>
<div id=\"formbox\"><h1>Contact Form</h1>[contact-form 1 \"Contact form 1\"]</div> 
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Contact Jeremy Bissonette","","inherit","open","open","","21-revision-v1","","","2014-01-10 11:49:44","2014-01-10 11:49:44","","21","http://www.kwmassage.com/?p=76","0","revision","","0");
INSERT INTO `wp_posts` VALUES("114","3","2014-01-11 18:42:28","2014-01-11 18:42:28","<p><a href=\"#\"><img src=\"http://test.xhtmlchop.com/blog853/wp-content/themes/6261/images/img_1.jpg\" alt=\"Image\" class=\"imgbox\" /></a>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>In feugiat velit non lectus hendrerit id condimentum purus tempus. Ut malesuada varius mi, id sagittis mi hendrerit eu.</p>

<h2>This Is an H2 Tag</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
<ul class=\"blue\">
<li>List item 1</li>
<li>List Item 2</li>
</ul>
<ol class=\"number\">
<li>List item 1</li>
<li>List Item 2</li>
</ol>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
</div>","About Jeremy","","inherit","open","open","","19-revision-v1","","","2014-01-11 18:42:28","2014-01-11 18:42:28","","19","http://www.kwmassage.com/?p=114","0","revision","","0");
INSERT INTO `wp_posts` VALUES("19","3","2011-02-10 12:25:45","2011-02-10 18:25:45","<a title=\"Kitchener Massage Therapy Welcome Video\" href=\"http://youtu.be/XSRrvEXZSdk\" target=\"_blank\" rel=\"http://youtu.be/XSRrvEXZSdk\"><img class=\" wp-image-155 alignleft\" alt=\"Jeremy Bissonnette, Registered Massage Therapist\" src=\"http://www.kwmassage.com/wp-content/uploads/2014/01/img_video-300x276.gif\" width=\"240\" height=\"221\" /></a>I graduated with Honours from the <a href=\"http://www.collegeofmassage.com/cambridge/\">Canadian College of Massage and Hydrotherapy </a>in 2005 as a <a href=\"http://www.cmto.com/\">Registered Massage Therapist </a>(RMT). I’ve practiced massage therapy in Kitchener and Waterloo in a variety of locations in including a home practice, the <a href=\"http://www.uoguelph.ca/hpc/\">University of Guelph’s Health and Performance Center, </a>and most recently, in an independently owned chiropractic office. I have also provided chair treatments at the <a href=\"http://www.kitchenermarket.ca/\">Kitchener Market </a>on a monthly basis in the past.

My massage therapy treatment style has been focused around <a href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">Deep Tissue Therapy </a>with an emphasis on helping clients learn to care for their own bodies. I have practiced yoga for the past 10 years and find my clients respond well to my recommendations around specific yoga asana and stretches to help with the different ailments they need to address. I find my knowledge of anatomy helps create clarity on the yoga mat and I have an interest in sharing this experience.
<div class=\"shadowbox\">
<h2>My Personal World</h2>
My main focus in life is caring for my 2 daughters, Rowan (7) and Breanne (5). I’m busy getting kids fed, dressed, doing hair, making bread, doing homework and housework, planning a garden, and all the activities associated with being a parent. Being a dad can have its challenges but it is also very rewarding. I feel very lucky to be able to fill this role while my wife works full-time.

In my spare time, I enjoy <a href=\"http://www.kwmassage.com/rock_climbing/rock-climbing-as-a-life-style\">rock climbing</a>, yoga, reading, camping, and gardening. Prior to becoming a registered massage therapist, I used to work in a <a href=\"http://www.paramountsports.ca/\">bike and snow board shop</a>, so when I can, I love to hit the hills and get back to my original roots.

</div>","About","","publish","closed","closed","","about","","","2014-01-13 19:56:59","2014-01-13 19:56:59","","0","http://test.xhtmlchop.com/blog853/?page_id=2","0","page","","0");
INSERT INTO `wp_posts` VALUES("180","3","2014-01-12 20:19:13","2014-01-12 20:19:13","<a href=\"http://www.kwmassage.com/wp-content/uploads/2014/01/img_video.gif\"><img class=\"alignnone size-medium wp-image-155\" alt=\"img_video\" src=\"http://www.kwmassage.com/wp-content/uploads/2014/01/img_video-300x276.gif\" width=\"300\" height=\"276\" /></a>

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.

In feugiat velit non lectus hendrerit id condimentum purus tempus. Ut malesuada varius mi, id sagittis mi hendrerit eu.
<div class=\"shadowbox\">
<h2>This Is an H2 Tag</h2>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.
<ul class=\"blue\">
	<li>List item 1</li>
	<li>List Item 2</li>
</ul>
<ol class=\"number\">
	<li>List item 1</li>
	<li>List Item 2</li>
</ol>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.

</div>","About Jeremy Bissonnette","","inherit","open","open","","19-revision-v1","","","2014-01-12 20:19:13","2014-01-12 20:19:13","","19","http://www.kwmassage.com/clinic-information","0","revision","","0");
INSERT INTO `wp_posts` VALUES("7","3","2011-02-18 09:19:50","2011-02-18 09:19:50","One of the easiest ways for you to make an appointment with me at the clinic is to book one online! The first time you book your appointment online, you will need to create an account with my scheduling service, Schedulicity. Scheduling an appointment online is fast, efficient, and easy.
<b>Step #1</b>: How long a massage do you want? You can have 30, 60, or 90 minutes of massage treatment time. The table below includes treatment rates. Click the link for the massage you need.
<b>Step #2</b>: Use the calendar to find an open time slot for your massage treatment. When you find an appointment time that works for you, click the link for that appointment.
<b>Step #3</b>: Sign In to Schedulicity with your <b>Email</b> and <b>Password</b>. New to Schedulicity? Sign Up – it’s free!
<b>Step #4</b>: Review the details of your appointment. It’s easy to change the appointment details if needed. You can also send me a message. When you’re ready to book your massage treatment, click <b>Book It</b>.
You will receive an email confirmation of your appointment. If you don’t – please try rebooking or contact me directly .
If you do not want to book online, please feel free to call me to book an appointment. Sometimes, if you are lucky, you might be able to get a last-minute appointment , or I may have additional time slots open that the scheduling tool doesn\'t.
<script type=\"text/javascript\" src=\"http://www.schedulicity.com/Scheduling/Embed/embedjs.aspx?business=KDXBZN\"></script><noscript><a href=\'http://www.schedulicity.com/Scheduling/Default.aspx?business=KDXBZN\' title=\'Online Scheduling\'>Schedule Now</a></noscript>
Please Note:
	* an appointment is required in advance
	* 24 hours’ notice is necessary to cancel an appointment and all missed appointments must be paid for.
	* There is no access to debit or credit in the <a title=\"clinic\" href=\"http://www.kwmassage.com/clinic-information/clinic\">clinic</a>, please bring cash or Cheques only.

","Appointments","","publish","open","open","","clinic-information","","","2014-01-12 20:13:42","2014-01-12 20:13:42","","0","http://test.xhtmlchop.com/blog853/?page_id=7","0","page","","0");
INSERT INTO `wp_posts` VALUES("20","3","2011-02-18 09:20:56","2011-02-18 09:20:56","Lorem ipsum dolor sit amet, consectetur adipiscing elit. In nunc diam, elementum at placerat ac, commodo in tellus. Donec bibendum, lectus mattis accumsan cursus, felis odio auctor leo, semper elementum purus purus id massa.

Fusce at suscipit lacus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aliquam tortor risus, pretium vel commodo eu, tincidunt a tortor.

Sed eros diam, pharetra vel scelerisque et, sollicitudin ut ante. Pellentesque nisl ante, accumsan vel posuere ac, ornare eget quam. Maecenas in tortor a dolor posuere dictum. Fusce lobortis dolor a arcu sodales tempor. Sed leo velit, semper non aliquet consequat, egestas a leo. Proin elementum ullamcorper molestie.

Donec tincidunt ullamcorper tellus ut elementum. Ut aliquam accumsan vestibulum. Cras blandit velit vel libero egestas a semper felis imperdiet. Nullam urna lectus, fermentum eget feugiat vitae, ornare et eros. Nulla et iaculis erat. Nullam auctor tincidunt dolor non auctor. Duis ut sapien a ante consectetur venenatis.

Proin elementum ullamcorper molestie. Donec tincidunt ullamcorper tellus ut elementum. Ut aliquam accumsan vestibulum. Cras blandit velit vel libero egestas a semper felis imperdiet. Nullam urna lectus, fermentum eget feugiat vitae, ornare et eros. Nulla et iaculis erat. Nullam auctor tincidunt dolor non auctor. Duis ut sapien a ante consectetur venenatis.
","Knowledge Centre","","publish","open","open","","knowledge-centre","","","2011-02-18 09:20:56","2011-02-18 09:20:56","","0","http://test.xhtmlchop.com/blog853/?page_id=9","0","page","","0");
INSERT INTO `wp_posts` VALUES("21","3","2011-02-18 09:21:11","2011-02-18 09:21:11","The quickest way to book an appointment with me is to <a href=\"http://www.kwmassage.com/clinic-information\">book a treatment online</a>.

To get in touch with me directly to make a <a title=\"Book Massage Therapy Appointment Online\" href=\"http://www.kwmassage.com/clinic-information\">massage therapy appointment </a>in Kitchener/Waterloo, you can call me, send me an email or text message, or you can <a href=\"http://www.facebook.com/pages/KWmassage/354131367967709\">Facebook</a> me. You can also use the form below to send me a message.

229 Frederick Street
Kitchener, ON
(519) 745-4112
<a href=\"mailto:Jeremy@kwmassage.com\">Jeremy@kwmassage.com</a>
<div></div>
<iframe src=\"https://mapsengine.google.com/map/embed?mid=z1kzsRant038.kwaZ-HV4FUfg\" height=\"400\" width=\"550\"></iframe>
<div id=\"formbox\">
<h1>Contact Form</h1>
</div>
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Contact","","publish","closed","open","","contact","","","2014-01-13 20:13:43","2014-01-13 20:13:43","","0","http://test.xhtmlchop.com/blog853/?page_id=11","0","page","","0");
INSERT INTO `wp_posts` VALUES("22","3","2011-02-18 09:26:38","2011-02-18 09:26:38","<p><a href=\"#\"><img src=\"http://test.xhtmlchop.com/blog853/wp-content/themes/6261/images/img_1.jpg\" alt=\"Image\" class=\"imgbox\" /></a>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>In feugiat velit non lectus hendrerit id condimentum purus tempus. Ut malesuada varius mi, id sagittis mi hendrerit eu.</p>
<div class=\"shadowbox\">
<h2>This Is an H2 Tag</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
<ul class=\"blue\">
<li>List item 1</li>
<li>List Item 2</li>
</ul>
<ol class=\"number\">
<li>List item 1</li>
<li>List Item 2</li>
</ol>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
</div>","About Jeremy link1","","trash","open","closed","","about-jeremy-bissonnette","","","2014-01-13 19:58:42","2014-01-13 19:58:42","","19","http://test.xhtmlchop.com/blog853/?page_id=18","0","page","","0");
INSERT INTO `wp_posts` VALUES("23","3","2011-02-18 09:27:20","2011-02-18 09:27:20","<p><a href=\"#\"><img src=\"http://test.xhtmlchop.com/blog853/wp-content/themes/6261/images/img_1.jpg\" alt=\"Image\" class=\"imgbox\" /></a>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>In feugiat velit non lectus hendrerit id condimentum purus tempus. Ut malesuada varius mi, id sagittis mi hendrerit eu.</p>
<div class=\"shadowbox\">
<h2>This Is an H2 Tag</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
<ul class=\"blue\">
<li>List item 1</li>
<li>List Item 2</li>
</ul>
<ol class=\"number\">
<li>List item 1</li>
<li>List Item 2</li>
</ol>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
</div>","About Jeremy link2","","trash","open","closed","","about-jeremy-bissonnette-link2","","","2014-01-13 19:58:42","2014-01-13 19:58:42","","19","http://test.xhtmlchop.com/blog853/?page_id=22","0","page","","0");
INSERT INTO `wp_posts` VALUES("24","3","2011-02-18 09:27:30","2011-02-18 09:27:30","<p><a href=\"#\"><img src=\"http://test.xhtmlchop.com/blog853/wp-content/themes/6261/images/img_1.jpg\" alt=\"Image\" class=\"imgbox\" /></a>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>In feugiat velit non lectus hendrerit id condimentum purus tempus. Ut malesuada varius mi, id sagittis mi hendrerit eu.</p>
<div class=\"shadowbox\">
<h2>This Is an H2 Tag</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
<ul class=\"blue\">
<li>List item 1</li>
<li>List Item 2</li>
</ul>
<ol class=\"number\">
<li>List item 1</li>
<li>List Item 2</li>
</ol>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
</div>","About Jeremy link3","","trash","open","closed","","about-jeremy-bissonnette-link3","","","2014-01-13 19:58:42","2014-01-13 19:58:42","","19","http://test.xhtmlchop.com/blog853/?page_id=24","0","page","","0");
INSERT INTO `wp_posts` VALUES("215","3","2014-01-12 21:58:29","2014-01-12 21:58:29","<h1>Kitchener Massage Therapy</h1>
Specializing in <a href=\"http://www.kwmassage.com/generalmassagetherapy/what-is-deep-tissue-massage\">Deep Tissue Massage </a>and<a href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\"> Trigger Point Release Therapy </a>to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace, and family life.
<div class=\"testimonialbox\">
<div class=\"testimonialinner\">
<div class=\"quotetop\">
<div class=\"quotebottom\">
<p style=\"padding-bottom: 0px;\"><strong>by Carrie - Technical Writer</strong>
I walked out of my first treatment with Jeremy impressed that he did exactly what I wanted him to do. Deep tissue massage treatment is nothing like a relaxing day at a spa, but it is precisely what I need...</p>

</div>
</div>
</div>
</div>
<div class=\"clear\">

<b> </b>

</div>
<h2>What is Deep Tissue Massage?</h2>
Deep Tissue massage is similar to the most common type of massage, Swedish massage, in that your therapist uses long, smooth, and kneading strokes to achieve healing changes in the body. The two forms of massage differ in that <a title=\"Discomfort of deep tissue massage\" href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">Deep Tissue massage aims to affect the deeper structures of the body </a>and have a deeper level of healing. Deep Tissue massage is very effective in treating chronic muscle and connective tissue injuries. <a href=\"http://www.kwmassage.com/generalmassagetherapy/what-is-deep-tissue-massage\">Read more...</a><a title=\"What is Deep Tissue Massage?\" href=\"http://www.kwmassage.com/generalmassagetherapy/what-is-deep-tissue-massage\">
</a>
<div id=\"formbox\">
<h1>Contact Form</h1>
</div>
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Welcome","","inherit","open","open","","75-revision-v1","","","2014-01-12 21:58:29","2014-01-12 21:58:29","","75","http://www.kwmassage.com/generalmassagetherapy/75-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("216","3","2014-01-12 22:01:14","2014-01-12 22:01:14","Often <a title=\"Deep tissue massage therapy\" href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">Deep Tissue massage therapy </a>will cause some tenderness when <a title=\"Jeremy, massage therapist in Kitchener\" href=\"http://www.kwmassage.com/about\">your massage therapist </a>is working hard to work out the tension, scar tissue, and trigger points from your muscles and ligaments. And yes, sometimes you will feel a little stiffness the day after. Most often, this soreness is a <a title=\"welcome\" href=\"http://www.kwmassage.com/welcome\">welcome</a> relief as your therapist has the skill to pinpoint the source of your pain and work it out.

Because each person’s discomfort tolerance is unique to them alone, you must communicate clearly and honestly with your therapist if/when more pressure is used than is comfortable for you.
<div>
<div>

&nbsp;

</div>
</div>","Does Deep Tissue Massage Hurt? ","","publish","open","open","","does-deep-tissue-massage-heart","","
http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage","2014-01-12 22:01:27","2014-01-12 22:01:27","","0","http://www.kwmassage.com/?p=216","0","post","","0");
INSERT INTO `wp_posts` VALUES("217","3","2014-01-12 22:01:14","2014-01-12 22:01:14","Often <a title=\"Deep tissue massage therapy\" href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">Deep Tissue massage therapy </a>will cause some tenderness when <a title=\"Jeremy, massage therapist in Kitchener\" href=\"http://www.kwmassage.com/about\">your massage therapist </a>is working hard to work out the tension, scar tissue, and trigger points from your muscles and ligaments. And yes, sometimes you will feel a little stiffness the day after. Most often, this soreness is a <a title=\"welcome\" href=\"http://www.kwmassage.com/welcome\">welcome</a> relief as your therapist has the skill to pinpoint the source of your pain and work it out.

Because each person’s discomfort tolerance is unique to them alone, you must communicate clearly and honestly with your therapist if/when more pressure is used than is comfortable for you.
<div>
<div>

&nbsp;

</div>
</div>","Does Deep Tissue Massage Heart? ","","inherit","open","open","","216-revision-v1","","","2014-01-12 22:01:14","2014-01-12 22:01:14","","216","http://www.kwmassage.com/generalmassagetherapy/216-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("218","3","2014-01-12 22:01:27","2014-01-12 22:01:27","Often <a title=\"Deep tissue massage therapy\" href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">Deep Tissue massage therapy </a>will cause some tenderness when <a title=\"Jeremy, massage therapist in Kitchener\" href=\"http://www.kwmassage.com/about\">your massage therapist </a>is working hard to work out the tension, scar tissue, and trigger points from your muscles and ligaments. And yes, sometimes you will feel a little stiffness the day after. Most often, this soreness is a <a title=\"welcome\" href=\"http://www.kwmassage.com/welcome\">welcome</a> relief as your therapist has the skill to pinpoint the source of your pain and work it out.

Because each person’s discomfort tolerance is unique to them alone, you must communicate clearly and honestly with your therapist if/when more pressure is used than is comfortable for you.
<div>
<div>

&nbsp;

</div>
</div>","Does Deep Tissue Massage Hurt? ","","inherit","open","open","","216-revision-v1","","","2014-01-12 22:01:27","2014-01-12 22:01:27","","216","http://www.kwmassage.com/generalmassagetherapy/216-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("219","3","2014-01-12 22:17:35","2014-01-12 22:17:35","<a href=\"http://www.kwmassage.com/about\">After studying and treating Trigger Points for many years, </a>I describe them to my clients as a part of muscle that has become hyper-sensitive and irritable. Trigger Points are found in a tight or stiff band of muscle, and they can be found in muscles throughout the body. The following video shows me describing a Trigger Point to a client:

<iframe src=\"//www.youtube.com/embed/shGC3k2tlb0?rel=0\" height=\"315\" width=\"560\" allowfullscreen=\"\" frameborder=\"0\"></iframe>

Trigger Points are sensitive to touch and they usually have a pattern of pain that presents in another part of the body. Sometimes where you hurt is not necessarily where the problem needs to be treated. The Trigger Point Chart below shows you how this referral pain travels. A Trigger Point in the Lower Trapezius muscle (represented as an X in the pink area) can show up as pain at the base of the skull because a Trigger Point in that one muscle can affect a significant area. It is very common to have pain referred from one part of your body to another, and I use Trigger Point Charts in my office to locate, connect, and treat pain on a regular basis.

<a href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy/attachment/trigger_point_chart\" rel=\"attachment wp-att-238\"><img class=\"alignleft size-medium wp-image-238\" alt=\"trigger_point_chart\" src=\"http://www.kwmassage.com/wp-content/uploads/2014/01/trigger_point_chart-300x247.jpg\" width=\"300\" height=\"247\" /></a>

Over time, trigger points can create a chronic shortening of affected muscle, and trigger points are often responsible for many chronic pain syndromes such as torticollis, <a href=\"http://www.kwmassage.com/generalmassagetherapy/tension-headaches-3\">headaches</a>, <a href=\"http://www.kwmassage.com/stretching/low-back-pain\">back pain</a>, knee pain, and postural stress.

At<a href=\"http://www.kwmassage.com/\"> Kitchener Massage Therapy </a>I use a few different <a href=\"http://www.kwmassage.com/generalmassagetherapy/what-is-deep-tissue-massage\">Deep Tissue Massage </a>techniques like muscle stripping, direct pressure held for up to a minute, and<a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\"> stretching</a>to treat Trigger Points.

<a href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">It is uncomfortable to have a Trigger Point worked out </a>but the relief you get from the <a href=\"http://www.kwmassage.com/generalmassagetherapy/tension-headaches-3\">headache</a>, <a href=\"http://www.kwmassage.com/stretching/low-back-pain\">sore back </a>or <a href=\"http://www.kwmassage.com/generalmassagetherapy/what-can-deep-tissue-massage-treat\">whatever it is you are experiencing</a> can be great. My clients often describe the pain from Trigger Point work as a good pain . I think this stems from the fact that someone has finally been able to pinpoint and address the source of their discomfort after what could have been many years.","Trigger Points and Trigger Point Therapy ","","publish","open","open","","trigger-points-and-trigger-point-therapy","","http://www.kwmassage.com/generalmassagetherapy/what-is-deep-tissue-massage
http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart","2014-01-13 17:47:58","2014-01-13 17:47:58","","0","http://www.kwmassage.com/?p=219","0","post","","0");
INSERT INTO `wp_posts` VALUES("75","3","2011-03-02 09:45:08","2011-03-02 09:45:08","<h1>Kitchener Massage Therapy</h1>
Specializing in <a href=\"http://www.kwmassage.com/generalmassagetherapy/what-is-deep-tissue-massage\">Deep Tissue Massage </a>and<a href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\"> Trigger Point Release Therapy </a>to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace, and family life.
<div class=\"testimonialbox\">
<div class=\"testimonialinner\">
<div class=\"quotetop\">
<div class=\"quotebottom\">
<p style=\"padding-bottom: 0px;\"><strong>by Carrie - Technical Writer</strong>
I walked out of my first treatment with Jeremy impressed that he did exactly what I wanted him to do. Deep tissue massage treatment is nothing like a relaxing day at a spa, but it is precisely what I need...</p>

</div>
</div>
</div>
</div>
<div class=\"clear\">

<b> </b>

</div>
<h2>What is Deep Tissue Massage?</h2>
Deep Tissue massage is similar to the most common type of massage, Swedish massage, in that your therapist uses long, smooth, and kneading strokes to achieve healing changes in the body. The two forms of massage differ in that <a title=\"Discomfort of deep tissue massage\" href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">Deep Tissue massage aims to affect the deeper structures of the body </a>and have a deeper level of healing. Deep Tissue massage is very effective in treating chronic muscle and connective tissue injuries. <a href=\"http://www.kwmassage.com/generalmassagetherapy/what-is-deep-tissue-massage\">Read more...</a><a title=\"What is Deep Tissue Massage?\" href=\"http://www.kwmassage.com/generalmassagetherapy/what-is-deep-tissue-massage\">
</a>
<div id=\"formbox\">
<h1>Contact Form</h1>
</div>
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Welcome","","publish","closed","closed","","welcome","","","2014-01-12 21:58:29","2014-01-12 21:58:29","","19","http://test.xhtmlchop.com/blog853/?page_id=75","0","page","","0");
INSERT INTO `wp_posts` VALUES("77","3","2014-01-10 12:55:07","2014-01-10 12:55:07","<p><a href=\"#\"><img src=\"http://test.xhtmlchop.com/blog853/wp-content/themes/6261/images/img_1.jpg\" alt=\"Image\" class=\"imgbox\" /></a>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>In feugiat velit non lectus hendrerit id condimentum purus tempus. Ut malesuada varius mi, id sagittis mi hendrerit eu.</p>
<div class=\"shadowbox\">
<h2>This Is an H2 Tag</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
<ul class=\"blue\">
<li>List item 1</li>
<li>List Item 2</li>
</ul>
<ol class=\"number\">
<li>List item 1</li>
<li>List Item 2</li>
</ol>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
</div>","About Jeremy","","inherit","open","open","","19-revision-v1","","","2014-01-10 12:55:07","2014-01-10 12:55:07","","19","http://www.kwmassage.com/?p=77","0","revision","","0");
INSERT INTO `wp_posts` VALUES("78","3","2014-01-10 12:57:00","2014-01-10 12:57:00","<p>Specializing in Deep Tissue Massage and Trigger Point Release Therapy to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace and family life.</p>
<p>
<span class=\"black\">(519) 745-4112</span><span class=\"black\">jeremy@kwmassage.com</span><span class=\"black\">7 Clarence Place</span><span class=\"black\">Kitchener, On</span></p>
<div id=\"formbox\"><h1>Contact Form</h1>[contact-form 1 \"Contact form 1\"]</div> 
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Contact Jeremy","","inherit","open","open","","21-revision-v1","","","2014-01-10 12:57:00","2014-01-10 12:57:00","","21","http://www.kwmassage.com/?p=78","0","revision","","0");
INSERT INTO `wp_posts` VALUES("115","3","2014-01-11 18:42:57","2014-01-11 18:42:57","<p><a href=\"#\"><img src=\"http://test.xhtmlchop.com/blog853/wp-content/themes/6261/images/img_1.jpg\" alt=\"Image\" class=\"imgbox\" /></a>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>In feugiat velit non lectus hendrerit id condimentum purus tempus. Ut malesuada varius mi, id sagittis mi hendrerit eu.</p>
<div class=\"shadowbox\">
<h2>This Is an H2 Tag</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
<ul class=\"blue\">
<li>List item 1</li>
<li>List Item 2</li>
</ul>
<ol class=\"number\">
<li>List item 1</li>
<li>List Item 2</li>
</ol>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
</div>","About Jeremy","","inherit","open","open","","19-revision-v1","","","2014-01-11 18:42:57","2014-01-11 18:42:57","","19","http://www.kwmassage.com/?p=115","0","revision","","0");
INSERT INTO `wp_posts` VALUES("80","3","2014-01-10 13:01:47","2014-01-10 13:01:47","<h1>Kitchener Massage Therapy</h1>
<p>Specializing in Deep Tissue Massage and Trigger Point Release Therapy to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace and family life.</p>
<div class=\"testimonialbox\">
<div class=\"testimonialinner\">
<div class=\"quotetop\">
<div class=\"quotebottom\">
<p style=\"padding-bottom:0px;\"> <strong>by Carrie - Technical Writer</strong>
I walked out of my first treatment with Jeremy impressed that he did exactly what I wanted him to do. Deep tissue massage treatment is nothing like a relaxing day at a spa, but it is precisely what I need...</p>
</div>
</div>
</div>
</div>
<div class=\"clear\"></div>
<p>Deep Tissue massage is similar to the most common type of massage, Swedish massage, in that your therapist uses long, smooth and kneading strokes to achieve healing changes in the body. The two forms of massage differ in that Deep Tissue massage aims to affect the deeper structures of the body and have a deeper level of healing. Deep Tissue massage is very effective in treating chronic muscle and connective tissue injuries.</p>","Welcome","","inherit","open","open","","75-revision-v1","","","2014-01-10 13:01:47","2014-01-10 13:01:47","","75","http://www.kwmassage.com/?p=80","0","revision","","0");
INSERT INTO `wp_posts` VALUES("82","3","2014-01-10 13:09:33","2014-01-10 13:09:33","<h1>Kitchener Massage Therapy</h1>
Specializing in Deep Tissue Massage and Trigger Point Release Therapy to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace and family life.
<div class=\"testimonialbox\">
<div class=\"testimonialinner\">
<div class=\"quotetop\">
<div class=\"quotebottom\">
<p style=\"padding-bottom: 0px;\"><strong>by Carrie - Technical Writer</strong>
I walked out of my first treatment with Jeremy impressed that he did exactly what I wanted him to do. Deep tissue massage treatment is nothing like a relaxing day at a spa, but it is precisely what I need...</p>

</div>
</div>
</div>
</div>
<div class=\"clear\"></div>
Deep Tissue massage is similar to the most common type of massage, Swedish massage, in that your therapist uses long, smooth and kneading strokes to achieve healing changes in the body. The two forms of massage differ in that Deep Tissue massage aims to affect the deeper structures of the body and have a deeper level of healing. Deep Tissue massage is very effective in treating chronic muscle and connective tissue injuries.","Home","","inherit","open","open","","75-revision-v1","","","2014-01-10 13:09:33","2014-01-10 13:09:33","","75","http://www.kwmassage.com/?p=82","0","revision","","0");
INSERT INTO `wp_posts` VALUES("81","3","2014-01-10 13:09:14","2014-01-10 13:09:14","<h1>Kitchener Massage Therapy</h1>
<p>Specializing in Deep Tissue Massage and Trigger Point Release Therapy to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace and family life.</p>
<div class=\"testimonialbox\">
<div class=\"testimonialinner\">
<div class=\"quotetop\">
<div class=\"quotebottom\">
<p style=\"padding-bottom:0px;\"> <strong>by Carrie - Technical Writer</strong><br />
I walked out of my first treatment with Jeremy impressed that he did exactly what I wanted him to do. Deep tissue massage treatment is nothing like a relaxing day at a spa, but it is precisely what I need...</p>
</div>
</div>
</div>
</div>
<div class=\"clear\"></div>
<p>Deep Tissue massage is similar to the most common type of massage, Swedish massage, in that your therapist uses long, smooth and kneading strokes to achieve healing changes in the body. The two forms of massage differ in that Deep Tissue massage aims to affect the deeper structures of the body and have a deeper level of healing. Deep Tissue massage is very effective in treating chronic muscle and connective tissue injuries.</p>
","Welcome","","inherit","open","open","","75-revision-v1","","","2014-01-10 13:09:14","2014-01-10 13:09:14","","75","http://www.kwmassage.com/?p=81","0","revision","","0");
INSERT INTO `wp_posts` VALUES("101","3","2014-01-10 13:26:57","2014-01-10 13:26:57","<p><a href=\"#\"><img src=\"http://test.xhtmlchop.com/blog853/wp-content/themes/6261/images/img_1.jpg\" alt=\"Image\" class=\"imgbox\" /></a>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>In feugiat velit non lectus hendrerit id condimentum purus tempus. Ut malesuada varius mi, id sagittis mi hendrerit eu.</p>
<div class=\"shadowbox\">
<h2>This Is an H2 Tag</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
<ul class=\"blue\">
<li>List item 1</li>
<li>List Item 2</li>
</ul>
<ol class=\"number\">
<li>List item 1</li>
<li>List Item 2</li>
</ol>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
</div>","About Jeremy link1","","inherit","open","open","","22-revision-v1","","","2014-01-10 13:26:57","2014-01-10 13:26:57","","22","http://www.kwmassage.com/?p=101","0","revision","","0");
INSERT INTO `wp_posts` VALUES("100","3","2014-01-10 13:25:11","2014-01-10 13:25:11","<h1>Kitchener Massage Therapy</h1>
Specializing in Deep Tissue Massage and Trigger Point Release Therapy to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace and family life.
<div class=\"testimonialbox\">
<div class=\"testimonialinner\">
<div class=\"quotetop\">
<div class=\"quotebottom\">
<p style=\"padding-bottom: 0px;\"><strong>by Carrie - Technical Writer</strong>
I walked out of my first treatment with Jeremy impressed that he did exactly what I wanted him to do. Deep tissue massage treatment is nothing like a relaxing day at a spa, but it is precisely what I need...</p>

</div>
</div>
</div>
</div>
<div class=\"clear\"></div>
Deep Tissue massage is similar to the most common type of massage, Swedish massage, in that your therapist uses long, smooth and kneading strokes to achieve healing changes in the body. The two forms of massage differ in that Deep Tissue massage aims to affect the deeper structures of the body and have a deeper level of healing. Deep Tissue massage is very effective in treating chronic muscle and connective tissue injuries.","Welcome","","inherit","open","open","","75-revision-v1","","","2014-01-10 13:25:11","2014-01-10 13:25:11","","75","http://www.kwmassage.com/?p=100","0","revision","","0");
INSERT INTO `wp_posts` VALUES("102","3","2014-01-10 13:27:06","2014-01-10 13:27:06","<p><a href=\"#\"><img src=\"http://test.xhtmlchop.com/blog853/wp-content/themes/6261/images/img_1.jpg\" alt=\"Image\" class=\"imgbox\" /></a>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>In feugiat velit non lectus hendrerit id condimentum purus tempus. Ut malesuada varius mi, id sagittis mi hendrerit eu.</p>
<div class=\"shadowbox\">
<h2>This Is an H2 Tag</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
<ul class=\"blue\">
<li>List item 1</li>
<li>List Item 2</li>
</ul>
<ol class=\"number\">
<li>List item 1</li>
<li>List Item 2</li>
</ol>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
</div>","About Jeremy link2","","inherit","open","open","","23-revision-v1","","","2014-01-10 13:27:06","2014-01-10 13:27:06","","23","http://www.kwmassage.com/?p=102","0","revision","","0");
INSERT INTO `wp_posts` VALUES("103","3","2014-01-10 13:27:23","2014-01-10 13:27:23","<p><a href=\"#\"><img src=\"http://test.xhtmlchop.com/blog853/wp-content/themes/6261/images/img_1.jpg\" alt=\"Image\" class=\"imgbox\" /></a>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>In feugiat velit non lectus hendrerit id condimentum purus tempus. Ut malesuada varius mi, id sagittis mi hendrerit eu.</p>
<div class=\"shadowbox\">
<h2>This Is an H2 Tag</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
<ul class=\"blue\">
<li>List item 1</li>
<li>List Item 2</li>
</ul>
<ol class=\"number\">
<li>List item 1</li>
<li>List Item 2</li>
</ol>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
</div>","About Jeremy link3","","inherit","open","open","","24-revision-v1","","","2014-01-10 13:27:23","2014-01-10 13:27:23","","24","http://www.kwmassage.com/?p=103","0","revision","","0");
INSERT INTO `wp_posts` VALUES("105","3","2014-01-10 13:45:47","2014-01-10 13:45:47","","Home","","publish","open","open","","home","","","2014-01-13 14:50:14","2014-01-13 14:50:14","","0","http://www.kwmassage.com/?p=105","1","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("106","3","2014-01-10 13:45:47","2014-01-10 13:45:47"," ","","","publish","open","open","","106","","","2014-01-13 14:50:14","2014-01-13 14:50:14","","0","http://www.kwmassage.com/?p=106","2","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("107","3","2014-01-10 13:45:47","2014-01-10 13:45:47"," ","","Massage Therapy Appointments","publish","open","open","","107","","","2014-01-13 14:50:14","2014-01-13 14:50:14","","0","http://www.kwmassage.com/?p=107","3","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("108","3","2014-01-10 13:45:47","2014-01-10 13:45:47"," ","","","publish","open","open","","108","","","2014-01-13 14:50:14","2014-01-13 14:50:14","","0","http://www.kwmassage.com/?p=108","6","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("109","3","2014-01-10 13:45:47","2014-01-10 13:45:47"," ","","","publish","open","open","","109","","","2014-01-13 14:50:14","2014-01-13 14:50:14","","0","http://www.kwmassage.com/?p=109","5","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("116","3","2014-01-11 18:44:03","2014-01-11 18:44:03","<p><a href=\"#\"><img src=\"http://test.xhtmlchop.com/blog853/wp-content/themes/6261/images/img_1.jpg\" alt=\"Image\" class=\"imgbox\" /></a>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>In feugiat velit non lectus hendrerit id condimentum purus tempus. Ut malesuada varius mi, id sagittis mi hendrerit eu.</p>

<h2>This Is an H2 Tag</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
<ul class=\"blue\">
<li>List item 1</li>
<li>List Item 2</li>
</ul>
<ol class=\"number\">
<li>List item 1</li>
<li>List Item 2</li>
</ol>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
</div>","About Jeremy","","inherit","open","open","","19-revision-v1","","","2014-01-11 18:44:03","2014-01-11 18:44:03","","19","http://www.kwmassage.com/?p=116","0","revision","","0");
INSERT INTO `wp_posts` VALUES("117","3","2014-01-11 18:44:21","2014-01-11 18:44:21","<p><a href=\"#\"><img src=\"http://test.xhtmlchop.com/blog853/wp-content/themes/6261/images/img_1.jpg\" alt=\"Image\" class=\"imgbox\" /></a>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>In feugiat velit non lectus hendrerit id condimentum purus tempus. Ut malesuada varius mi, id sagittis mi hendrerit eu.</p>
<div class=\"shadowbox\">
<h2>This Is an H2 Tag</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
<ul class=\"blue\">
<li>List item 1</li>
<li>List Item 2</li>
</ul>
<ol class=\"number\">
<li>List item 1</li>
<li>List Item 2</li>
</ol>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
</div>","About Jeremy","","inherit","open","open","","19-revision-v1","","","2014-01-11 18:44:21","2014-01-11 18:44:21","","19","http://www.kwmassage.com/?p=117","0","revision","","0");
INSERT INTO `wp_posts` VALUES("118","3","2014-01-11 18:44:43","2014-01-11 18:44:43","<p><a href=\"#\"><img src=\"http://test.xhtmlchop.com/blog853/wp-content/themes/6261/images/img_1.jpg\" alt=\"Image\" class=\"imgbox\" /></a>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>In feugiat velit non lectus hendrerit id condimentum purus tempus. Ut malesuada varius mi, id sagittis mi hendrerit eu.</p>

<h2>This Is an H2 Tag</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
<ul class=\"blue\">
<li>List item 1</li>
<li>List Item 2</li>
</ul>
<ol class=\"number\">
<li>List item 1</li>
<li>List Item 2</li>
</ol>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
</div>","About Jeremy","","inherit","open","open","","19-revision-v1","","","2014-01-11 18:44:43","2014-01-11 18:44:43","","19","http://www.kwmassage.com/?p=118","0","revision","","0");
INSERT INTO `wp_posts` VALUES("119","3","2014-01-11 18:45:03","2014-01-11 18:45:03","<p><a href=\"#\"><img src=\"http://test.xhtmlchop.com/blog853/wp-content/themes/6261/images/img_1.jpg\" alt=\"Image\" class=\"imgbox\" /></a>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque. Donec ullamcorper adipiscing erat, non congue nisl fringilla vitae. Mauris arcu enim, auctor vitae varius fermentum, pellentesque a purus.</p>
<p>In feugiat velit non lectus hendrerit id condimentum purus tempus. Ut malesuada varius mi, id sagittis mi hendrerit eu.</p>
<div class=\"shadowbox\">
<h2>This Is an H2 Tag</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
<ul class=\"blue\">
<li>List item 1</li>
<li>List Item 2</li>
</ul>
<ol class=\"number\">
<li>List item 1</li>
<li>List Item 2</li>
</ol>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.</p>
</div>","About Jeremy","","inherit","open","open","","19-revision-v1","","","2014-01-11 18:45:03","2014-01-11 18:45:03","","19","http://www.kwmassage.com/?p=119","0","revision","","0");
INSERT INTO `wp_posts` VALUES("120","3","2014-01-12 17:33:22","2014-01-12 17:33:22","","bg_body_mountain","","inherit","open","open","","bg_body_mountain","","","2014-01-12 17:33:22","2014-01-12 17:33:22","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bg_body_mountain.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("121","3","2014-01-12 17:33:24","2014-01-12 17:33:24","","bg_body_summer","","inherit","open","open","","bg_body_summer","","","2014-01-12 17:33:24","2014-01-12 17:33:24","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bg_body_summer.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("122","3","2014-01-12 17:33:24","2014-01-12 17:33:24","","bg_contactnumber","","inherit","open","open","","bg_contactnumber","","","2014-01-12 17:33:24","2014-01-12 17:33:24","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bg_contactnumber.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("123","3","2014-01-12 17:33:25","2014-01-12 17:33:25","","bg_container","","inherit","open","open","","bg_container","","","2014-01-12 17:33:25","2014-01-12 17:33:25","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bg_container.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("124","3","2014-01-12 17:33:30","2014-01-12 17:33:30","","bg_container_top","","inherit","open","open","","bg_container_top","","","2014-01-12 17:33:30","2014-01-12 17:33:30","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bg_container_top.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("125","3","2014-01-12 17:33:31","2014-01-12 17:33:31","","bg_footer_bottom","","inherit","open","open","","bg_footer_bottom","","","2014-01-12 17:33:31","2014-01-12 17:33:31","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bg_footer_bottom.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("126","3","2014-01-12 17:33:31","2014-01-12 17:33:31","","bg_footermid","","inherit","open","open","","bg_footermid","","","2014-01-12 17:33:31","2014-01-12 17:33:31","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bg_footermid.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("127","3","2014-01-12 17:33:32","2014-01-12 17:33:32","","bg_formbox","","inherit","open","open","","bg_formbox","","","2014-01-12 17:33:32","2014-01-12 17:33:32","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bg_formbox.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("128","3","2014-01-12 17:33:32","2014-01-12 17:33:32","","bg_heading_menu","","inherit","open","open","","bg_heading_menu","","","2014-01-12 17:33:32","2014-01-12 17:33:32","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bg_heading_menu.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("129","3","2014-01-12 17:33:32","2014-01-12 17:33:32","","bg_listlink","","inherit","open","open","","bg_listlink","","","2014-01-12 17:33:32","2014-01-12 17:33:32","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bg_listlink.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("130","3","2014-01-12 17:33:33","2014-01-12 17:33:33","","bg_listmenu","","inherit","open","open","","bg_listmenu","","","2014-01-12 17:33:33","2014-01-12 17:33:33","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bg_listmenu.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("131","3","2014-01-12 17:33:33","2014-01-12 17:33:33","","bg_nav","","inherit","open","open","","bg_nav","","","2014-01-12 17:33:33","2014-01-12 17:33:33","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bg_nav.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("132","3","2014-01-12 17:33:33","2014-01-12 17:33:33","","bg_nav_hover","","inherit","open","open","","bg_nav_hover","","","2014-01-12 17:33:33","2014-01-12 17:33:33","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bg_nav_hover.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("133","3","2014-01-12 17:33:34","2014-01-12 17:33:34","","bg_nav_old","","inherit","open","open","","bg_nav_old","","","2014-01-12 17:33:34","2014-01-12 17:33:34","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bg_nav_old.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("134","3","2014-01-12 17:33:34","2014-01-12 17:33:34","","bg_navold","","inherit","open","open","","bg_navold","","","2014-01-12 17:33:34","2014-01-12 17:33:34","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bg_navold.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("135","3","2014-01-12 17:33:35","2014-01-12 17:33:35","","bg_ratebox","","inherit","open","open","","bg_ratebox","","","2014-01-12 17:33:35","2014-01-12 17:33:35","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bg_ratebox.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("136","3","2014-01-12 17:33:35","2014-01-12 17:33:35","","bg_submenin","","inherit","open","open","","bg_submenin","","","2014-01-12 17:33:35","2014-01-12 17:33:35","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bg_submenin.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("137","3","2014-01-12 17:33:35","2014-01-12 17:33:35","","bg_submenushadow","","inherit","open","open","","bg_submenushadow","","","2014-01-12 17:33:35","2014-01-12 17:33:35","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bg_submenushadow.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("138","3","2014-01-12 17:33:36","2014-01-12 17:33:36","","bg_tagline","","inherit","open","open","","bg_tagline","","","2014-01-12 17:33:36","2014-01-12 17:33:36","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bg_tagline.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("139","3","2014-01-12 17:33:36","2014-01-12 17:33:36","","bg_tagline_old","","inherit","open","open","","bg_tagline_old","","","2014-01-12 17:33:36","2014-01-12 17:33:36","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bg_tagline_old.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("140","3","2014-01-12 17:33:36","2014-01-12 17:33:36","","bg_testimonialbox","","inherit","open","open","","bg_testimonialbox","","","2014-01-12 17:33:36","2014-01-12 17:33:36","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bg_testimonialbox.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("141","3","2014-01-12 17:33:37","2014-01-12 17:33:37","","bg_textarea","","inherit","open","open","","bg_textarea","","","2014-01-12 17:33:37","2014-01-12 17:33:37","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bg_textarea.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("142","3","2014-01-12 17:33:37","2014-01-12 17:33:37","","bg_tfw","","inherit","open","open","","bg_tfw","","","2014-01-12 17:33:37","2014-01-12 17:33:37","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bg_tfw.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("143","3","2014-01-12 17:33:37","2014-01-12 17:33:37","","bg_tfw2","","inherit","open","open","","bg_tfw2","","","2014-01-12 17:33:37","2014-01-12 17:33:37","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bg_tfw2.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("144","3","2014-01-12 17:33:38","2014-01-12 17:33:38","","bullet_blue","","inherit","open","open","","bullet_blue","","","2014-01-12 17:33:38","2014-01-12 17:33:38","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bullet_blue.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("145","3","2014-01-12 17:33:38","2014-01-12 17:33:38","","bullet_circle","","inherit","open","open","","bullet_circle","","","2014-01-12 17:33:38","2014-01-12 17:33:38","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/bullet_circle.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("146","3","2014-01-12 17:33:39","2014-01-12 17:33:39","","divider_gray","","inherit","open","open","","divider_gray","","","2014-01-12 17:33:39","2014-01-12 17:33:39","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/divider_gray.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("147","3","2014-01-12 17:33:39","2014-01-12 17:33:39","","icon_arrow","","inherit","open","open","","icon_arrow","","","2014-01-12 17:33:39","2014-01-12 17:33:39","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/icon_arrow.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("148","3","2014-01-12 17:33:39","2014-01-12 17:33:39","","icon_clear","","inherit","open","open","","icon_clear","","","2014-01-12 17:33:39","2014-01-12 17:33:39","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/icon_clear.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("149","3","2014-01-12 17:33:40","2014-01-12 17:33:40","","icon_graysend","","inherit","open","open","","icon_graysend","","","2014-01-12 17:33:40","2014-01-12 17:33:40","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/icon_graysend.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("150","3","2014-01-12 17:33:40","2014-01-12 17:33:40","","icon_send","","inherit","open","open","","icon_send","","","2014-01-12 17:33:40","2014-01-12 17:33:40","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/icon_send.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("151","3","2014-01-12 17:33:40","2014-01-12 17:33:40","","img_1","","inherit","open","open","","img_1","","","2014-01-12 17:33:40","2014-01-12 17:33:40","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/img_1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("152","3","2014-01-12 17:33:41","2014-01-12 17:33:41","","img_bg","","inherit","open","open","","img_bg","","","2014-01-12 17:33:41","2014-01-12 17:33:41","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/img_bg.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("153","3","2014-01-12 17:33:41","2014-01-12 17:33:41","","img_comabottom","","inherit","open","open","","img_comabottom","","","2014-01-12 17:33:41","2014-01-12 17:33:41","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/img_comabottom.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("154","3","2014-01-12 17:33:41","2014-01-12 17:33:41","","img_comatop","","inherit","open","open","","img_comatop","","","2014-01-12 17:33:41","2014-01-12 17:33:41","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/img_comatop.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("155","3","2014-01-12 17:33:42","2014-01-12 17:33:42","Meet Jeremy Bissonnette, Registered Massage Therapist, in a one-on-one welcom video","Jeremy Bissonnette, Registered Massage Therapist","","inherit","open","open","","img_video","","","2014-01-12 17:33:42","2014-01-12 17:33:42","","19","http://www.kwmassage.com/wp-content/uploads/2014/01/img_video.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("156","3","2014-01-12 17:33:42","2014-01-12 17:33:42","","KWMassage-1f_u3011-copy_12-02","","inherit","open","open","","kwmassage-1f_u3011-copy_12-02","","","2014-01-12 17:33:42","2014-01-12 17:33:42","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/KWMassage-1f_u3011-copy_12-02.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("157","3","2014-01-12 17:33:43","2014-01-12 17:33:43","","logo","","inherit","open","open","","logo","","","2014-01-12 17:33:43","2014-01-12 17:33:43","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/logo.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("158","3","2014-01-12 18:31:16","2014-01-12 18:31:16","<h1>Kitchener Massage Therapy</h1>
Specializing in Deep Tissue Massage and Trigger Point Release Therapy to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace and family life.
<div class=\"testimonialbox\">
<div class=\"testimonialinner\">
<div class=\"quotetop\">
<div class=\"quotebottom\">
<p style=\"padding-bottom: 0px;\"><strong>by Carrie - Technical Writer</strong>
I walked out of my first treatment with Jeremy impressed that he did exactly what I wanted him to do. Deep tissue massage treatment is nothing like a relaxing day at a spa, but it is precisely what I need...</p>

</div>
</div>
</div>
</div>
<div class=\"clear\"></div>
Deep Tissue massage is similar to the most common type of massage, Swedish massage, in that your therapist uses long, smooth and kneading strokes to achieve healing changes in the body. The two forms of massage differ in that Deep Tissue massage aims to affect the deeper structures of the body and have a deeper level of healing. Deep Tissue massage is very effective in treating chronic muscle and connective tissue injuries.

<div id=\"formbox\">
<h1>Contact Form</h1>
</div>
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Welcome","","inherit","open","open","","75-revision-v1","","","2014-01-12 18:31:16","2014-01-12 18:31:16","","75","http://www.kwmassage.com/?p=158","0","revision","","0");
INSERT INTO `wp_posts` VALUES("159","3","2014-01-12 18:55:57","2014-01-12 18:55:57","Specializing in Deep Tissue Massage and Trigger Point Release Therapy to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace and family life.

<span class=\"black\">(519) 745-4112</span><span class=\"black\">jeremy@kwmassage.com</span><span class=\"black\">7 Clarence Place</span><span class=\"black\">Kitchener, On</span>
<iframe src=\"https://mapsengine.google.com/map/embed?mid=z1kzsRant038.kH-1_NZrzzA0\" width=\"640\" height=\"480\"></iframe>

<div id=\"formbox\">
<h1>Contact Form</h1>
</div>
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Contact Jeremy","","inherit","open","open","","21-revision-v1","","","2014-01-12 18:55:57","2014-01-12 18:55:57","","21","http://www.kwmassage.com/?p=159","0","revision","","0");
INSERT INTO `wp_posts` VALUES("160","3","2014-01-12 19:28:09","2014-01-12 19:28:09","Specializing in Deep Tissue Massage and Trigger Point Release Therapy to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace and family life.

<span class=\"black\">(519) 745-4112</span><span class=\"black\">jeremy@kwmassage.com</span><span class=\"black\">7 Clarence Place</span><span class=\"black\">Kitchener, On</span>
<iframe src=\"https://mapsengine.google.com/map/embed?mid=z1kzsRant038.kwaZ-HV4FUfg\" width=\"640\" height=\"480\"></iframe>
<div id=\"formbox\">
<h1>Contact Form</h1>
</div>
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Contact Jeremy","","inherit","open","open","","21-revision-v1","","","2014-01-12 19:28:09","2014-01-12 19:28:09","","21","http://www.kwmassage.com/?p=160","0","revision","","0");
INSERT INTO `wp_posts` VALUES("161","3","2014-01-12 20:37:37","2014-01-12 20:37:37","The quickest way to book an appointment with me is to book a treatment online.

To get in touch with me directly to make a <a href=\"http://www.kwmassage.com/clinic-information\">massage therapy appointment </a>in Kitchener/Waterloo, you can call me, send me an email or text message, or you can <a href=\"http://www.facebook.com/pages/KWmassage/354131367967709\">Facebook</a> me. You can also use the form below to send me a message.

229 Frederick Street
Kitchener, ON
(519) 745-4112
<a href=\"mailto:Jeremy@kwmassage.com\">Jeremy@kwmassage.com</a>
<div></div>
<iframe src=\"https://mapsengine.google.com/map/embed?mid=z1kzsRant038.kwaZ-HV4FUfg\" height=\"400\" width=\"550\"></iframe>
<div id=\"formbox\">
<h1>Contact Form</h1>
</div>
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Contact","","inherit","open","open","","21-autosave-v1","","","2014-01-12 20:37:37","2014-01-12 20:37:37","","21","http://www.kwmassage.com/?p=161","0","revision","","0");
INSERT INTO `wp_posts` VALUES("162","3","2014-01-12 19:29:15","2014-01-12 19:29:15","Specializing in Deep Tissue Massage and Trigger Point Release Therapy to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace and family life.

<span class=\"black\">(519) 745-4112</span><span class=\"black\">jeremy@kwmassage.com</span><span class=\"black\">229 Frederick Street</span><span class=\"black\">Kitchener, On</span>
<iframe src=\"https://mapsengine.google.com/map/embed?mid=z1kzsRant038.kwaZ-HV4FUfg\" width=\"580\" height=\"430\"></iframe>
<div id=\"formbox\">
<h1>Contact Form</h1>
</div>
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Contact Jeremy","","inherit","open","open","","21-revision-v1","","","2014-01-12 19:29:15","2014-01-12 19:29:15","","21","http://www.kwmassage.com/?p=162","0","revision","","0");
INSERT INTO `wp_posts` VALUES("163","3","2014-01-12 19:29:49","2014-01-12 19:29:49","Specializing in Deep Tissue Massage and Trigger Point Release Therapy to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace and family life.

<span class=\"black\">(519) 745-4112</span><span class=\"black\">jeremy@kwmassage.com</span><span class=\"black\">229 Frederick Street</span><span class=\"black\">Kitchener, On</span>
<iframe src=\"https://mapsengine.google.com/map/embed?mid=z1kzsRant038.kwaZ-HV4FUfg\" width=\"570\" height=\"420\"></iframe>
<div id=\"formbox\">
<h1>Contact Form</h1>
</div>
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Contact Jeremy","","inherit","open","open","","21-revision-v1","","","2014-01-12 19:29:49","2014-01-12 19:29:49","","21","http://www.kwmassage.com/?p=163","0","revision","","0");
INSERT INTO `wp_posts` VALUES("164","3","2014-01-12 19:30:12","2014-01-12 19:30:12","Specializing in Deep Tissue Massage and Trigger Point Release Therapy to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace and family life.

<span class=\"black\">(519) 745-4112</span><span class=\"black\">jeremy@kwmassage.com</span><span class=\"black\">229 Frederick Street</span><span class=\"black\">Kitchener, On</span>
<iframe src=\"https://mapsengine.google.com/map/embed?mid=z1kzsRant038.kwaZ-HV4FUfg\" width=\"550\" height=\"400\"></iframe>
<div id=\"formbox\">
<h1>Contact Form</h1>
</div>
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Contact Jeremy","","inherit","open","open","","21-revision-v1","","","2014-01-12 19:30:12","2014-01-12 19:30:12","","21","http://www.kwmassage.com/?p=164","0","revision","","0");
INSERT INTO `wp_posts` VALUES("165","3","2014-01-12 19:58:37","2014-01-12 19:58:37","Lorem ipsum dolor sit amet, consectetur adipiscing elit. In nunc diam, elementum at placerat ac, commodo in tellus. Donec bibendum, lectus mattis accumsan cursus, felis odio auctor leo, semper elementum purus purus id massa.

Fusce at suscipit lacus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aliquam tortor risus, pretium vel commodo eu, tincidunt a tortor.

Sed eros diam, pharetra vel scelerisque et, sollicitudin ut ante. Pellentesque nisl ante, accumsan vel posuere ac, ornare eget quam. Maecenas in tortor a dolor posuere dictum. Fusce lobortis dolor a arcu sodales tempor. Sed leo velit, semper non aliquet consequat, egestas a leo. Proin elementum ullamcorper molestie.

Donec tincidunt ullamcorper tellus ut elementum. Ut aliquam accumsan vestibulum. Cras blandit velit vel libero egestas a semper felis imperdiet. Nullam urna lectus, fermentum eget feugiat vitae, ornare et eros. Nulla et iaculis erat. Nullam auctor tincidunt dolor non auctor. Duis ut sapien a ante consectetur venenatis.

Proin elementum ullamcorper molestie. Donec tincidunt ullamcorper tellus ut elementum. Ut aliquam accumsan vestibulum. Cras blandit velit vel libero egestas a semper felis imperdiet. Nullam urna lectus, fermentum eget feugiat vitae, ornare et eros. Nulla et iaculis erat. Nullam auctor tincidunt dolor non auctor. Duis ut sapien a ante consectetur venenatis.
","Appointments","","inherit","open","open","","7-revision-v1","","","2014-01-12 19:58:37","2014-01-12 19:58:37","","7","http://www.kwmassage.com/?p=165","0","revision","","0");
INSERT INTO `wp_posts` VALUES("166","3","2014-01-12 20:12:22","2014-01-12 20:12:22","One of the easiest ways for you to make an appointment with me at the clinic is to book one online! The first time you book your appointment online, you will need to create an account with my scheduling service, Schedulicity. Scheduling an appointment online is fast, efficient, and easy.
<b>Step #1</b>: How long a massage do you want? You can have 30, 60, or 90 minutes of massage treatment time. The table below includes treatment rates. Click the link for the massage you need.
<b>Step #2</b>: Use the calendar to find an open time slot for your massage treatment. When you find an appointment time that works for you, click the link for that appointment.
<b>Step #3</b>: Sign In to Schedulicity with your <b>Email</b> and <b>Password</b>. New to Schedulicity? Sign Up – it’s free!
<b>Step #4</b>: Review the details of your appointment. It’s easy to change the appointment details if needed. You can also send me a message. When you’re ready to book your massage treatment, click <b>Book It</b>.
You will receive an email confirmation of your appointment. If you don’t – please try rebooking or contact me directly .
If you do not want to book online, please feel free to call me to book an appointment. Sometimes, if you are lucky, you might be able to get a last-minute appointment , or I may have additional time slots open that the scheduling tool doesn\'t.
<script type=\"text/javascript\" src=\"http://www.schedulicity.com/Scheduling/Embed/embedjs.aspx?business=KDXBZN\"></script><noscript><a href=\'http://www.schedulicity.com/Scheduling/Default.aspx?business=KDXBZN\' title=\'Online Scheduling\'>Schedule Now</a></noscript>
Please Note:

	an appointment is required in advance
	24 hours’ notice is necessary to cancel an appointment and all missed appointments must be paid for.
	There is no access to debit or credit in the <a title=\"clinic\" href=\"http://www.kwmassage.com/clinic-information/clinic\">clinic</a>, please bring cash or Cheques only.

","Appointments","","inherit","open","open","","7-autosave-v1","","","2014-01-12 20:12:22","2014-01-12 20:12:22","","7","http://www.kwmassage.com/?p=166","0","revision","","0");
INSERT INTO `wp_posts` VALUES("169","3","2014-01-12 20:02:48","2014-01-12 20:02:48","One of the easiest ways for you to make an appointment with me at the clinic is to book one online! The first time you book your appointment online, you will need to create an account with my scheduling service, Schedulicity. Scheduling an appointment online is fast, efficient, and easy.
<b>Step #1</b>: How long a massage do you want? You can have 30, 60, or 90 minutes of massage treatment time. The table below includes treatment rates. Click the link for the massage you need.
<b>Step #2</b>: Use the calendar to find an open time slot for your massage treatment. When you find an appointment time that works for you, click the link for that appointment.
<b>Step #3</b>: Sign In to Schedulicity with your <b>Email</b> and <b>Password</b>. New to Schedulicity? Sign Up – it’s free!
<b>Step #4</b>: Review the details of your appointment. It’s easy to change the appointment details if needed. You can also send me a message. When you’re ready to book your massage treatment, click <b>Book It</b>.

You will receive an email confirmation of your appointment. If you don’t – please try rebooking or contact me directly .

If you do not want to book online, please feel free to call me to book an appointment. Sometimes, if you are lucky, you might be able to get a last-minute appointment , or I may have additional time slots open that the scheduling tool doesn\'t.

Please Note:
<ul>
	<li>an appointment is required in advance</li>
	<li>24 hours’ notice is necessary to cancel an appointment and all missed appointments must be paid for.</li>
	<li>There is no access to debit or credit in the <a title=\"clinic\" href=\"http://www.kwmassage.com/clinic-information/clinic\">clinic</a>, please bring cash or Cheques only.</li>
</ul>
&nbsp;","Appointments","","inherit","open","open","","7-revision-v1","","","2014-01-12 20:02:48","2014-01-12 20:02:48","","7","http://www.kwmassage.com/?p=169","0","revision","","0");
INSERT INTO `wp_posts` VALUES("167","3","2014-01-12 20:00:55","2014-01-12 20:00:55","One of the easiest ways for you to make an appointment with me at the clinic is to book one online! The first time you book your appointment online, you will need to create an account with my scheduling service, Schedulicity. Scheduling an appointment online is fast, efficient, and easy.

<b>Step #1</b>: How long a massage do you want? You can have 30, 60, or 90 minutes of massage treatment time. The table below includes treatment rates. Click the link for the massage you need.

<b>Step #2</b>: Use the calendar to find an open time slot for your massage treatment. When you find an appointment time that works for you, click the link for that appointment.

<b>Step #3</b>: Sign In to Schedulicity with your <b>Email</b> and <b>Password</b>. New to Schedulicity? Sign Up – it’s free!

<b>Step #4</b>: Review the details of your appointment. It’s easy to change the appointment details if needed. You can also send me a message. When you’re ready to book your massage treatment, click <b>Book It</b>.

You will receive an email confirmation of your appointment. If you don’t – please try rebooking or contact me directly .

If you do not want to book online, please feel free to call me to book an appointment. Sometimes, if you are lucky, you might be able to get a last-minute appointment , or I may have additional time slots open that the scheduling tool doesn\'t.

Please Note:
<ul>
	<li>an appointment is required in advance</li>
	<li>24 hours’ notice is necessary to cancel an appointment and all missed appointments must be paid for.</li>
	<li>There is no access to debit or credit in the <a title=\"clinic\" href=\"http://www.kwmassage.com/clinic-information/clinic\">clinic</a>, please bring cash or Cheques only.</li>
</ul>
&nbsp;","Appointments","","inherit","open","open","","7-revision-v1","","","2014-01-12 20:00:55","2014-01-12 20:00:55","","7","http://www.kwmassage.com/?p=167","0","revision","","0");
INSERT INTO `wp_posts` VALUES("168","3","2014-01-12 20:01:32","2014-01-12 20:01:32","One of the easiest ways for you to make an appointment with me at the clinic is to book one online! The first time you book your appointment online, you will need to create an account with my scheduling service, Schedulicity. Scheduling an appointment online is fast, efficient, and easy.<b>Step #1</b>: How long a massage do you want? You can have 30, 60, or 90 minutes of massage treatment time. The table below includes treatment rates. Click the link for the massage you need.

<b>Step #2</b>: Use the calendar to find an open time slot for your massage treatment. When you find an appointment time that works for you, click the link for that appointment.

<b>Step #3</b>: Sign In to Schedulicity with your <b>Email</b> and <b>Password</b>. New to Schedulicity? Sign Up – it’s free!

<b>Step #4</b>: Review the details of your appointment. It’s easy to change the appointment details if needed. You can also send me a message. When you’re ready to book your massage treatment, click <b>Book It</b>.

You will receive an email confirmation of your appointment. If you don’t – please try rebooking or contact me directly .

If you do not want to book online, please feel free to call me to book an appointment. Sometimes, if you are lucky, you might be able to get a last-minute appointment , or I may have additional time slots open that the scheduling tool doesn\'t.

Please Note:
<ul>
	<li>an appointment is required in advance</li>
	<li>24 hours’ notice is necessary to cancel an appointment and all missed appointments must be paid for.</li>
	<li>There is no access to debit or credit in the <a title=\"clinic\" href=\"http://www.kwmassage.com/clinic-information/clinic\">clinic</a>, please bring cash or Cheques only.</li>
</ul>
&nbsp;","Appointments","","inherit","open","open","","7-revision-v1","","","2014-01-12 20:01:32","2014-01-12 20:01:32","","7","http://www.kwmassage.com/?p=168","0","revision","","0");
INSERT INTO `wp_posts` VALUES("170","3","2014-01-12 20:03:57","2014-01-12 20:03:57","One of the easiest ways for you to make an appointment with me at the clinic is to book one online! The first time you book your appointment online, you will need to create an account with my scheduling service, Schedulicity. Scheduling an appointment online is fast, efficient, and easy.
<b>Step #1</b>: How long a massage do you want? You can have 30, 60, or 90 minutes of massage treatment time. The table below includes treatment rates. Click the link for the massage you need.
<b>Step #2</b>: Use the calendar to find an open time slot for your massage treatment. When you find an appointment time that works for you, click the link for that appointment.
<b>Step #3</b>: Sign In to Schedulicity with your <b>Email</b> and <b>Password</b>. New to Schedulicity? Sign Up – it’s free!
<b>Step #4</b>: Review the details of your appointment. It’s easy to change the appointment details if needed. You can also send me a message. When you’re ready to book your massage treatment, click <b>Book It</b>.

You will receive an email confirmation of your appointment. If you don’t – please try rebooking or contact me directly .

If you do not want to book online, please feel free to call me to book an appointment. Sometimes, if you are lucky, you might be able to get a last-minute appointment , or I may have additional time slots open that the scheduling tool doesn\'t.

Please Note:
<ul>
	<li>an appointment is required in advance</li>
	<li>24 hours’ notice is necessary to cancel an appointment and all missed appointments must be paid for.</li>
	<li>There is no access to debit or credit in the <a title=\"clinic\" href=\"http://www.kwmassage.com/clinic-information/clinic\">clinic</a>, please bring cash or Cheques only.</li>
</ul>","Appointments","","inherit","open","open","","7-revision-v1","","","2014-01-12 20:03:57","2014-01-12 20:03:57","","7","http://www.kwmassage.com/?p=170","0","revision","","0");
INSERT INTO `wp_posts` VALUES("171","3","2014-01-12 20:04:17","2014-01-12 20:04:17","One of the easiest ways for you to make an appointment with me at the clinic is to book one online! The first time you book your appointment online, you will need to create an account with my scheduling service, Schedulicity. Scheduling an appointment online is fast, efficient, and easy.
<b>Step #1</b>: How long a massage do you want? You can have 30, 60, or 90 minutes of massage treatment time. The table below includes treatment rates. Click the link for the massage you need.
<b>Step #2</b>: Use the calendar to find an open time slot for your massage treatment. When you find an appointment time that works for you, click the link for that appointment.
<b>Step #3</b>: Sign In to Schedulicity with your <b>Email</b> and <b>Password</b>. New to Schedulicity? Sign Up – it’s free!
<b>Step #4</b>: Review the details of your appointment. It’s easy to change the appointment details if needed. You can also send me a message. When you’re ready to book your massage treatment, click <b>Book It</b>.

You will receive an email confirmation of your appointment. If you don’t – please try rebooking or contact me directly .

If you do not want to book online, please feel free to call me to book an appointment. Sometimes, if you are lucky, you might be able to get a last-minute appointment , or I may have additional time slots open that the scheduling tool doesn\'t.

Please Note:
<ol>
	<li>an appointment is required in advance</li>
	<li>24 hours’ notice is necessary to cancel an appointment and all missed appointments must be paid for.</li>
	<li>There is no access to debit or credit in the <a title=\"clinic\" href=\"http://www.kwmassage.com/clinic-information/clinic\">clinic</a>, please bring cash or Cheques only.</li>
</ol>","Appointments","","inherit","open","open","","7-revision-v1","","","2014-01-12 20:04:17","2014-01-12 20:04:17","","7","http://www.kwmassage.com/?p=171","0","revision","","0");
INSERT INTO `wp_posts` VALUES("172","3","2014-01-12 20:04:53","2014-01-12 20:04:53","One of the easiest ways for you to make an appointment with me at the clinic is to book one online! The first time you book your appointment online, you will need to create an account with my scheduling service, Schedulicity. Scheduling an appointment online is fast, efficient, and easy.
<b>Step #1</b>: How long a massage do you want? You can have 30, 60, or 90 minutes of massage treatment time. The table below includes treatment rates. Click the link for the massage you need.
<b>Step #2</b>: Use the calendar to find an open time slot for your massage treatment. When you find an appointment time that works for you, click the link for that appointment.
<b>Step #3</b>: Sign In to Schedulicity with your <b>Email</b> and <b>Password</b>. New to Schedulicity? Sign Up – it’s free!
<b>Step #4</b>: Review the details of your appointment. It’s easy to change the appointment details if needed. You can also send me a message. When you’re ready to book your massage treatment, click <b>Book It</b>.

You will receive an email confirmation of your appointment. If you don’t – please try rebooking or contact me directly .

If you do not want to book online, please feel free to call me to book an appointment. Sometimes, if you are lucky, you might be able to get a last-minute appointment , or I may have additional time slots open that the scheduling tool doesn\'t.

Please Note:
	<li>an appointment is required in advance</li>
	<li>24 hours’ notice is necessary to cancel an appointment and all missed appointments must be paid for.</li>
	<li>There is no access to debit or credit in the <a title=\"clinic\" href=\"http://www.kwmassage.com/clinic-information/clinic\">clinic</a>, please bring cash or Cheques only.</li>
","Appointments","","inherit","open","open","","7-revision-v1","","","2014-01-12 20:04:53","2014-01-12 20:04:53","","7","http://www.kwmassage.com/?p=172","0","revision","","0");
INSERT INTO `wp_posts` VALUES("173","3","2014-01-12 20:05:16","2014-01-12 20:05:16","One of the easiest ways for you to make an appointment with me at the clinic is to book one online! The first time you book your appointment online, you will need to create an account with my scheduling service, Schedulicity. Scheduling an appointment online is fast, efficient, and easy.
<b>Step #1</b>: How long a massage do you want? You can have 30, 60, or 90 minutes of massage treatment time. The table below includes treatment rates. Click the link for the massage you need.
<b>Step #2</b>: Use the calendar to find an open time slot for your massage treatment. When you find an appointment time that works for you, click the link for that appointment.
<b>Step #3</b>: Sign In to Schedulicity with your <b>Email</b> and <b>Password</b>. New to Schedulicity? Sign Up – it’s free!
<b>Step #4</b>: Review the details of your appointment. It’s easy to change the appointment details if needed. You can also send me a message. When you’re ready to book your massage treatment, click <b>Book It</b>.

You will receive an email confirmation of your appointment. If you don’t – please try rebooking or contact me directly .

If you do not want to book online, please feel free to call me to book an appointment. Sometimes, if you are lucky, you might be able to get a last-minute appointment , or I may have additional time slots open that the scheduling tool doesn\'t.

Please Note:
	an appointment is required in advance
	<li>24 hours’ notice is necessary to cancel an appointment and all missed appointments must be paid for.</li>
	<li>There is no access to debit or credit in the <a title=\"clinic\" href=\"http://www.kwmassage.com/clinic-information/clinic\">clinic</a>, please bring cash or Cheques only.</li>
","Appointments","","inherit","open","open","","7-revision-v1","","","2014-01-12 20:05:16","2014-01-12 20:05:16","","7","http://www.kwmassage.com/?p=173","0","revision","","0");
INSERT INTO `wp_posts` VALUES("174","3","2014-01-12 20:05:58","2014-01-12 20:05:58","One of the easiest ways for you to make an appointment with me at the clinic is to book one online! The first time you book your appointment online, you will need to create an account with my scheduling service, Schedulicity. Scheduling an appointment online is fast, efficient, and easy.
<b>Step #1</b>: How long a massage do you want? You can have 30, 60, or 90 minutes of massage treatment time. The table below includes treatment rates. Click the link for the massage you need.
<b>Step #2</b>: Use the calendar to find an open time slot for your massage treatment. When you find an appointment time that works for you, click the link for that appointment.
<b>Step #3</b>: Sign In to Schedulicity with your <b>Email</b> and <b>Password</b>. New to Schedulicity? Sign Up – it’s free!
<b>Step #4</b>: Review the details of your appointment. It’s easy to change the appointment details if needed. You can also send me a message. When you’re ready to book your massage treatment, click <b>Book It</b>.

You will receive an email confirmation of your appointment. If you don’t – please try rebooking or contact me directly .

If you do not want to book online, please feel free to call me to book an appointment. Sometimes, if you are lucky, you might be able to get a last-minute appointment , or I may have additional time slots open that the scheduling tool doesn\'t.

Please Note:
<ul>
	<li>an appointment is required in advance</li>
	<li>24 hours’ notice is necessary to cancel an appointment and all missed appointments must be paid for.</li>
	<li>There is no access to debit or credit in the <a title=\"clinic\" href=\"http://www.kwmassage.com/clinic-information/clinic\">clinic</a>, please bring cash or Cheques only.</li>
</ul>","Appointments","","inherit","open","open","","7-revision-v1","","","2014-01-12 20:05:58","2014-01-12 20:05:58","","7","http://www.kwmassage.com/?p=174","0","revision","","0");
INSERT INTO `wp_posts` VALUES("175","3","2014-01-12 20:06:41","2014-01-12 20:06:41","One of the easiest ways for you to make an appointment with me at the clinic is to book one online! The first time you book your appointment online, you will need to create an account with my scheduling service, Schedulicity. Scheduling an appointment online is fast, efficient, and easy.
<b>Step #1</b>: How long a massage do you want? You can have 30, 60, or 90 minutes of massage treatment time. The table below includes treatment rates. Click the link for the massage you need.
<b>Step #2</b>: Use the calendar to find an open time slot for your massage treatment. When you find an appointment time that works for you, click the link for that appointment.
<b>Step #3</b>: Sign In to Schedulicity with your <b>Email</b> and <b>Password</b>. New to Schedulicity? Sign Up – it’s free!
<b>Step #4</b>: Review the details of your appointment. It’s easy to change the appointment details if needed. You can also send me a message. When you’re ready to book your massage treatment, click <b>Book It</b>.

You will receive an email confirmation of your appointment. If you don’t – please try rebooking or contact me directly .

If you do not want to book online, please feel free to call me to book an appointment. Sometimes, if you are lucky, you might be able to get a last-minute appointment , or I may have additional time slots open that the scheduling tool doesn\'t.

Please Note:
<ul>
	an appointment is required in advance
	24 hours’ notice is necessary to cancel an appointment and all missed appointments must be paid for.
	There is no access to debit or credit in the <a title=\"clinic\" href=\"http://www.kwmassage.com/clinic-information/clinic\">clinic</a>, please bring cash or Cheques only.
</ul>","Appointments","","inherit","open","open","","7-revision-v1","","","2014-01-12 20:06:41","2014-01-12 20:06:41","","7","http://www.kwmassage.com/?p=175","0","revision","","0");
INSERT INTO `wp_posts` VALUES("176","3","2014-01-12 20:10:28","2014-01-12 20:10:28","One of the easiest ways for you to make an appointment with me at the clinic is to book one online! The first time you book your appointment online, you will need to create an account with my scheduling service, Schedulicity. Scheduling an appointment online is fast, efficient, and easy.
<b>Step #1</b>: How long a massage do you want? You can have 30, 60, or 90 minutes of massage treatment time. The table below includes treatment rates. Click the link for the massage you need.
<b>Step #2</b>: Use the calendar to find an open time slot for your massage treatment. When you find an appointment time that works for you, click the link for that appointment.
<b>Step #3</b>: Sign In to Schedulicity with your <b>Email</b> and <b>Password</b>. New to Schedulicity? Sign Up – it’s free!
<b>Step #4</b>: Review the details of your appointment. It’s easy to change the appointment details if needed. You can also send me a message. When you’re ready to book your massage treatment, click <b>Book It</b>.

You will receive an email confirmation of your appointment. If you don’t – please try rebooking or contact me directly .

If you do not want to book online, please feel free to call me to book an appointment. Sometimes, if you are lucky, you might be able to get a last-minute appointment , or I may have additional time slots open that the scheduling tool doesn\'t.

Please Note:
<ul>
	an appointment is required in advance
	24 hours’ notice is necessary to cancel an appointment and all missed appointments must be paid for.
	There is no access to debit or credit in the <a title=\"clinic\" href=\"http://www.kwmassage.com/clinic-information/clinic\">clinic</a>, please bring cash or Cheques only.
</ul>

<script type=\"text/javascript\" src=\"http://www.schedulicity.com/Scheduling/Embed/popupjs.aspx?business=KDXBZN\"></script><noscript><a href=\'http://www.schedulicity.com/Scheduling/Default.aspx?business=KDXBZN\' title=\'Online Scheduling\'>Schedule Now</a></noscript>","Appointments","","inherit","open","open","","7-revision-v1","","","2014-01-12 20:10:28","2014-01-12 20:10:28","","7","http://www.kwmassage.com/clinic-information","0","revision","","0");
INSERT INTO `wp_posts` VALUES("177","3","2014-01-12 20:11:21","2014-01-12 20:11:21","One of the easiest ways for you to make an appointment with me at the clinic is to book one online! The first time you book your appointment online, you will need to create an account with my scheduling service, Schedulicity. Scheduling an appointment online is fast, efficient, and easy.
<b>Step #1</b>: How long a massage do you want? You can have 30, 60, or 90 minutes of massage treatment time. The table below includes treatment rates. Click the link for the massage you need.
<b>Step #2</b>: Use the calendar to find an open time slot for your massage treatment. When you find an appointment time that works for you, click the link for that appointment.
<b>Step #3</b>: Sign In to Schedulicity with your <b>Email</b> and <b>Password</b>. New to Schedulicity? Sign Up – it’s free!
<b>Step #4</b>: Review the details of your appointment. It’s easy to change the appointment details if needed. You can also send me a message. When you’re ready to book your massage treatment, click <b>Book It</b>.

You will receive an email confirmation of your appointment. If you don’t – please try rebooking or contact me directly .

If you do not want to book online, please feel free to call me to book an appointment. Sometimes, if you are lucky, you might be able to get a last-minute appointment , or I may have additional time slots open that the scheduling tool doesn\'t.

Please Note:
<ul>
	an appointment is required in advance
	24 hours’ notice is necessary to cancel an appointment and all missed appointments must be paid for.
	There is no access to debit or credit in the <a title=\"clinic\" href=\"http://www.kwmassage.com/clinic-information/clinic\">clinic</a>, please bring cash or Cheques only.
</ul>

<script type=\"text/javascript\" src=\"http://www.schedulicity.com/Scheduling/Embed/embedjs.aspx?business=KDXBZN\"></script><noscript><a href=\'http://www.schedulicity.com/Scheduling/Default.aspx?business=KDXBZN\' title=\'Online Scheduling\'>Schedule Now</a></noscript>","Appointments","","inherit","open","open","","7-revision-v1","","","2014-01-12 20:11:21","2014-01-12 20:11:21","","7","http://www.kwmassage.com/clinic-information","0","revision","","0");
INSERT INTO `wp_posts` VALUES("178","3","2014-01-12 20:12:45","2014-01-12 20:12:45","One of the easiest ways for you to make an appointment with me at the clinic is to book one online! The first time you book your appointment online, you will need to create an account with my scheduling service, Schedulicity. Scheduling an appointment online is fast, efficient, and easy.
<b>Step #1</b>: How long a massage do you want? You can have 30, 60, or 90 minutes of massage treatment time. The table below includes treatment rates. Click the link for the massage you need.
<b>Step #2</b>: Use the calendar to find an open time slot for your massage treatment. When you find an appointment time that works for you, click the link for that appointment.
<b>Step #3</b>: Sign In to Schedulicity with your <b>Email</b> and <b>Password</b>. New to Schedulicity? Sign Up – it’s free!
<b>Step #4</b>: Review the details of your appointment. It’s easy to change the appointment details if needed. You can also send me a message. When you’re ready to book your massage treatment, click <b>Book It</b>.
You will receive an email confirmation of your appointment. If you don’t – please try rebooking or contact me directly .
If you do not want to book online, please feel free to call me to book an appointment. Sometimes, if you are lucky, you might be able to get a last-minute appointment , or I may have additional time slots open that the scheduling tool doesn\'t.

<script type=\"text/javascript\" src=\"http://www.schedulicity.com/Scheduling/Embed/embedjs.aspx?business=KDXBZN\"></script><noscript><a href=\'http://www.schedulicity.com/Scheduling/Default.aspx?business=KDXBZN\' title=\'Online Scheduling\'>Schedule Now</a></noscript>

Please Note:

	an appointment is required in advance
	24 hours’ notice is necessary to cancel an appointment and all missed appointments must be paid for.
	There is no access to debit or credit in the <a title=\"clinic\" href=\"http://www.kwmassage.com/clinic-information/clinic\">clinic</a>, please bring cash or Cheques only.

","Appointments","","inherit","open","open","","7-revision-v1","","","2014-01-12 20:12:45","2014-01-12 20:12:45","","7","http://www.kwmassage.com/clinic-information","0","revision","","0");
INSERT INTO `wp_posts` VALUES("179","3","2014-01-12 20:13:42","2014-01-12 20:13:42","One of the easiest ways for you to make an appointment with me at the clinic is to book one online! The first time you book your appointment online, you will need to create an account with my scheduling service, Schedulicity. Scheduling an appointment online is fast, efficient, and easy.
<b>Step #1</b>: How long a massage do you want? You can have 30, 60, or 90 minutes of massage treatment time. The table below includes treatment rates. Click the link for the massage you need.
<b>Step #2</b>: Use the calendar to find an open time slot for your massage treatment. When you find an appointment time that works for you, click the link for that appointment.
<b>Step #3</b>: Sign In to Schedulicity with your <b>Email</b> and <b>Password</b>. New to Schedulicity? Sign Up – it’s free!
<b>Step #4</b>: Review the details of your appointment. It’s easy to change the appointment details if needed. You can also send me a message. When you’re ready to book your massage treatment, click <b>Book It</b>.
You will receive an email confirmation of your appointment. If you don’t – please try rebooking or contact me directly .
If you do not want to book online, please feel free to call me to book an appointment. Sometimes, if you are lucky, you might be able to get a last-minute appointment , or I may have additional time slots open that the scheduling tool doesn\'t.
<script type=\"text/javascript\" src=\"http://www.schedulicity.com/Scheduling/Embed/embedjs.aspx?business=KDXBZN\"></script><noscript><a href=\'http://www.schedulicity.com/Scheduling/Default.aspx?business=KDXBZN\' title=\'Online Scheduling\'>Schedule Now</a></noscript>
Please Note:
	* an appointment is required in advance
	* 24 hours’ notice is necessary to cancel an appointment and all missed appointments must be paid for.
	* There is no access to debit or credit in the <a title=\"clinic\" href=\"http://www.kwmassage.com/clinic-information/clinic\">clinic</a>, please bring cash or Cheques only.

","Appointments","","inherit","open","open","","7-revision-v1","","","2014-01-12 20:13:42","2014-01-12 20:13:42","","7","http://www.kwmassage.com/clinic-information","0","revision","","0");
INSERT INTO `wp_posts` VALUES("184","3","2014-01-12 20:31:35","2014-01-12 20:31:35","<a href=\"http://www.kwmassage.com/wp-content/uploads/2014/01/img_video.gif\"><img class=\" wp-image-155 alignleft\" alt=\"Jeremy Bissonnette, Registered Massage Therapist\" src=\"http://www.kwmassage.com/wp-content/uploads/2014/01/img_video-300x276.gif\" width=\"240\" height=\"221\" /></a>I graduated with Honours from the <a href=\"http://www.collegeofmassage.com/cambridge/\">Canadian College of Massage and Hydrotherapy </a>in 2005 as a <a href=\"http://www.cmto.com/\">Registered Massage Therapist </a>(RMT). I’ve practiced massage therapy in Kitchener and Waterloo in a variety of locations in including a home practice, the <a href=\"http://www.uoguelph.ca/hpc/\">University of Guelph’s Health and Performance Center, </a>and most recently, in an independently owned chiropractic office. I have also provided chair treatments at the <a href=\"http://www.kitchenermarket.ca/\">Kitchener Market </a>on a monthly basis in the past.

My massage therapy treatment style has been focused around <a href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">Deep Tissue Therapy </a>with an emphasis on helping clients learn to care for their own bodies. I have practiced yoga for the past 10 years and find my clients respond well to my recommendations around specific yoga asana and stretches to help with the different ailments they need to address. I find my knowledge of anatomy helps create clarity on the yoga mat and I have an interest in sharing this experience.
<div class=\"shadowbox\">

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.
<ul class=\"blue\">
	<li>List item 1</li>
	<li>List Item 2</li>
</ul>
<ol class=\"number\">
	<li>List item 1</li>
	<li>List Item 2</li>
</ol>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.

</div>","About Jeremy","","inherit","open","open","","19-revision-v1","","","2014-01-12 20:31:35","2014-01-12 20:31:35","","19","http://www.kwmassage.com/clinic-information","0","revision","","0");
INSERT INTO `wp_posts` VALUES("181","3","2014-01-12 20:25:46","2014-01-12 20:25:46","<a href=\"http://www.kwmassage.com/wp-content/uploads/2014/01/img_video.gif\"><img class=\" wp-image-155  alignleft\" title=\"Jeremy Bissonnette, Registered Massage Therapist\" alt=\"KWmassage Welcome Video\" src=\"http://www.kwmassage.com/wp-content/uploads/2014/01/img_video-300x276.gif\" width=\"108\" height=\"100\" /></a>

I graduated with Honours from the <a href=\"http://www.collegeofmassage.com/cambridge/\">Canadian College of Massage and Hydrotherapy </a>in 2005 as a <a href=\"http://www.cmto.com/\">Registered Massage Therapist </a>(RMT). I’ve practiced massage therapy in Kitchener and Waterloo in a variety of locations in including a home practice, the <a href=\"http://www.uoguelph.ca/hpc/\">University of Guelph’s Health and Performance Center, </a>and most recently, in an independently owned chiropractic office. I have also provided chair treatments at the <a href=\"http://www.kitchenermarket.ca/\">Kitchener Market </a>on a monthly basis in the past.

My massage therapy treatment style has been focused around <a href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">Deep Tissue Therapy </a>with an emphasis on helping clients learn to care for their own bodies. I have practiced yoga for the past 10 years and find my clients respond well to my recommendations around specific yoga asana and stretches to help with the different ailments they need to address. I find my knowledge of anatomy helps create clarity on the yoga mat and I have an interest in sharing this experience.
<div class=\"shadowbox\">

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.
<ul class=\"blue\">
	<li>List item 1</li>
	<li>List Item 2</li>
</ul>
<ol class=\"number\">
	<li>List item 1</li>
	<li>List Item 2</li>
</ol>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.

</div>","About Jeremy Bissonnette","","inherit","open","open","","19-revision-v1","","","2014-01-12 20:25:46","2014-01-12 20:25:46","","19","http://www.kwmassage.com/clinic-information","0","revision","","0");
INSERT INTO `wp_posts` VALUES("182","3","2014-01-12 20:26:25","2014-01-12 20:26:25","<a href=\"http://www.kwmassage.com/wp-content/uploads/2014/01/img_video.gif\"><img class=\" wp-image-155  alignleft\" title=\"Jeremy Bissonnette, Registered Massage Therapist\" alt=\"KWmassage Welcome Video\" src=\"http://www.kwmassage.com/wp-content/uploads/2014/01/img_video-300x276.gif\" width=\"86\" height=\"80\" /></a>

I graduated with Honours from the <a href=\"http://www.collegeofmassage.com/cambridge/\">Canadian College of Massage and Hydrotherapy </a>in 2005 as a <a href=\"http://www.cmto.com/\">Registered Massage Therapist </a>(RMT). I’ve practiced massage therapy in Kitchener and Waterloo in a variety of locations in including a home practice, the <a href=\"http://www.uoguelph.ca/hpc/\">University of Guelph’s Health and Performance Center, </a>and most recently, in an independently owned chiropractic office. I have also provided chair treatments at the <a href=\"http://www.kitchenermarket.ca/\">Kitchener Market </a>on a monthly basis in the past.

My massage therapy treatment style has been focused around <a href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">Deep Tissue Therapy </a>with an emphasis on helping clients learn to care for their own bodies. I have practiced yoga for the past 10 years and find my clients respond well to my recommendations around specific yoga asana and stretches to help with the different ailments they need to address. I find my knowledge of anatomy helps create clarity on the yoga mat and I have an interest in sharing this experience.
<div class=\"shadowbox\">

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.
<ul class=\"blue\">
	<li>List item 1</li>
	<li>List Item 2</li>
</ul>
<ol class=\"number\">
	<li>List item 1</li>
	<li>List Item 2</li>
</ol>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.

</div>","About Jeremy Bissonnette","","inherit","open","open","","19-revision-v1","","","2014-01-12 20:26:25","2014-01-12 20:26:25","","19","http://www.kwmassage.com/clinic-information","0","revision","","0");
INSERT INTO `wp_posts` VALUES("183","3","2014-01-12 20:28:34","2014-01-12 20:28:34","<a href=\"http://www.kwmassage.com/wp-content/uploads/2014/01/img_video.gif\"><img class=\" wp-image-155 alignleft\" alt=\"Jeremy Bissonnette, Registered Massage Therapist\" src=\"http://www.kwmassage.com/wp-content/uploads/2014/01/img_video-300x276.gif\" width=\"240\" height=\"221\" /></a>I graduated with Honours from the <a href=\"http://www.collegeofmassage.com/cambridge/\">Canadian College of Massage and Hydrotherapy </a>in 2005 as a <a href=\"http://www.cmto.com/\">Registered Massage Therapist </a>(RMT). I’ve practiced massage therapy in Kitchener and Waterloo in a variety of locations in including a home practice, the <a href=\"http://www.uoguelph.ca/hpc/\">University of Guelph’s Health and Performance Center, </a>and most recently, in an independently owned chiropractic office. I have also provided chair treatments at the <a href=\"http://www.kitchenermarket.ca/\">Kitchener Market </a>on a monthly basis in the past.

My massage therapy treatment style has been focused around <a href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">Deep Tissue Therapy </a>with an emphasis on helping clients learn to care for their own bodies. I have practiced yoga for the past 10 years and find my clients respond well to my recommendations around specific yoga asana and stretches to help with the different ailments they need to address. I find my knowledge of anatomy helps create clarity on the yoga mat and I have an interest in sharing this experience.
<div class=\"shadowbox\">

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.
<ul class=\"blue\">
	<li>List item 1</li>
	<li>List Item 2</li>
</ul>
<ol class=\"number\">
	<li>List item 1</li>
	<li>List Item 2</li>
</ol>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec nisl interdum eros viverra hendrerit in vel arcu. Sed vel felis dignissim mi varius vestibulum in vel ante. Pellentesque convallis, mi eget facilisis iaculis, velit velit mollis mi, non ullamcorper augue est sit amet neque.

</div>","About Jeremy Bissonnette","","inherit","open","open","","19-revision-v1","","","2014-01-12 20:28:34","2014-01-12 20:28:34","","19","http://www.kwmassage.com/clinic-information","0","revision","","0");
INSERT INTO `wp_posts` VALUES("227","3","2014-01-13 14:52:07","2014-01-13 14:52:07","When you come in for your first <a href=\"http://www.kwmassage.com/clinic-information\">massage therapy appointment </a>at <a href=\"http://www.kwmassage.com/\">KW massage </a>with me, a few things need to be done in preparation for your <a href=\"http://www.kwmassage.com/\">massage therapy treatment</a>.

First, I do not charge an initial consultation fee. What you pay depends on the length of treatment you request when you book the appointment. I do not charge any additional fees.

I have a <a href=\"http://www.kwmassage.com/wp-content/uploads/2011/06/Health-History.pdf\">health history form </a>that you need to fill out before we get started. Try to come about 10 minutes early to fill out this form. Or, you can also print it out and complete it ahead of time. Just be sure to bring it with you on the day of your first appointment.

This health history form  gives me a general overview of your state of health so that we can be sure there is no risk to the treatment plan I create for you. Once I have gone over your treatment plan, we will have a short discussion about what it is you want me to treat. I try not to take up more than a few minutes with this stage but it is important for me to have a clear picture of what we will be working on before we get started. I commonly ask questions like:
<ul>
	<li>where does it hurt?</li>
	<li>what does the pain feel like?</li>
	<li>what sort of things aggravate the injury?</li>
	<li>was there and accident to create the injury?</li>
</ul>
Sometimes I will want to have a closer look at your posture (the way you stand) or maybe I will want to do some range of motion testing. These tests will allow me to zone in on the source of your problem. Often, I don’t want to do any of these tests; I find I can get the same information while you are on the table by making the testing and treating procedure one and the same.

After I get a general idea of what it is I’m going to work on, it’s time to get started. While I go wash my hands, it’s your chance to get ready for your treatment. You always have the final say regarding how you get ready and what clothes you are comfortable taking off.

Most of my clients are comfortable removing all their clothing but their underpants knowing that I will always make sure they are covered discreetly with a sheet. I only expose one part of your body at a time, and only the specific body part I will be working on.

During your treatment, I will be using an assortment of massage techniques. Some of these can be relaxing and others can be <a href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">kind of tender</a>. In most cases, <a href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">a little pain is necessary </a>to get the results you are looking for from a massage therapy treatment.

It’s important that you be able to rate your discomfort on a scale of 1 to 10, where 10 is the most pain you’ve ever experienced. A discomfort level of 7 or under can be appropriate depending on the injury or need, but any more than that won’t bring you healing benefits. If, at any time during your treatment, your discomfort level becomes intolerable, please speak up. You may find that some areas of the body are more sensitive than others, or that your sensitivity changes day to day. Feel free to let me know how you’re doing. It’s entirely okay to ask me to adjust my pressure and technique at any time during your treatment.

During your massage treatment, I will try to spark up a conversation. Not only does this allow us to become better acquainted, but I also find that a light conversation helps distract you from when I find a sore spot like a <a href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\">Trigger Point </a>or Scar Tissue. This distraction technique allows you to stay relaxed, helps keep your muscles from pushing back against me working, and reduces pain overall. I often try to direct conversation to subjects that might give me clues or hints about what is creating your pain or discomfort. Topics like your work, the kind of car you drive, or sports or athletics you are involved often give me lots of information about you posture, repetitive movements you often do, or strength or flexibility issues.

When your treatment is complete, I will let you know, then go wash my hands again (I do this a lot). This gives you time to get up, get dressed, and come out to see me. If, during your treatment, we discussed any exercises, stretches, or heat/cold treatments for you do at home, this is when I will go over that in more detail.

After the massage treatment, it is also time to handle the payment and rebooking. I don’t have credit or debit machines so cash payment is necessary.

If you have extended health care benefits, on my receipt you will find my <a href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">registration number as a registered massage therapist</a>.  When you send your receipt to your health care company for reimbursement, this registration is what they need for approval.
<div></div>","Note to New Massage Clients","","inherit","open","open","","224-revision-v1","","","2014-01-13 14:52:07","2014-01-13 14:52:07","","224","http://www.kwmassage.com/generalmassagetherapy/224-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("185","3","2014-01-12 20:33:33","2014-01-12 20:33:33","<a href=\"http://www.kwmassage.com/wp-content/uploads/2014/01/img_video.gif\"><img class=\" wp-image-155 alignleft\" alt=\"Jeremy Bissonnette, Registered Massage Therapist\" src=\"http://www.kwmassage.com/wp-content/uploads/2014/01/img_video-300x276.gif\" width=\"240\" height=\"221\" /></a>I graduated with Honours from the <a href=\"http://www.collegeofmassage.com/cambridge/\">Canadian College of Massage and Hydrotherapy </a>in 2005 as a <a href=\"http://www.cmto.com/\">Registered Massage Therapist </a>(RMT). I’ve practiced massage therapy in Kitchener and Waterloo in a variety of locations in including a home practice, the <a href=\"http://www.uoguelph.ca/hpc/\">University of Guelph’s Health and Performance Center, </a>and most recently, in an independently owned chiropractic office. I have also provided chair treatments at the <a href=\"http://www.kitchenermarket.ca/\">Kitchener Market </a>on a monthly basis in the past.

My massage therapy treatment style has been focused around <a href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">Deep Tissue Therapy </a>with an emphasis on helping clients learn to care for their own bodies. I have practiced yoga for the past 10 years and find my clients respond well to my recommendations around specific yoga asana and stretches to help with the different ailments they need to address. I find my knowledge of anatomy helps create clarity on the yoga mat and I have an interest in sharing this experience.
<div class=\"shadowbox\">
<h2>My Personal World</h2>
My main focus in life is caring for my 2 daughters, Rowan (7) and Breanne (5). I’m busy getting kids fed, dressed, doing hair, making bread, doing homework and housework, planning a garden, and all the activities associated with being a parent. Being a dad can have its challenges but it is also very rewarding. I feel very lucky to be able to fill this role while my wife works full-time.

In my spare time, I enjoy <a href=\"http://www.kwmassage.com/rock_climbing/rock-climbing-as-a-life-style\">rock climbing</a>, yoga, reading, camping, and gardening. Prior to becoming a registered massage therapist, I used to work in a <a href=\"http://www.paramountsports.ca/\">bike and snow board shop</a>, so when I can, I love to hit the hills and get back to my original roots.

</div>","About Jeremy","","inherit","open","open","","19-revision-v1","","","2014-01-12 20:33:33","2014-01-12 20:33:33","","19","http://www.kwmassage.com/clinic-information","0","revision","","0");
INSERT INTO `wp_posts` VALUES("187","3","2014-01-12 20:38:10","2014-01-12 20:38:10","The quickest way to book an appointment with me is to book a treatment online.

To get in touch with me directly to make a <a title=\"Book Massage Therapy Appointment Online\" href=\"http://www.kwmassage.com/clinic-information\">massage therapy appointment </a>in Kitchener/Waterloo, you can call me, send me an email or text message, or you can <a href=\"http://www.facebook.com/pages/KWmassage/354131367967709\">Facebook</a> me. You can also use the form below to send me a message.

229 Frederick Street
Kitchener, ON
(519) 745-4112
<a href=\"mailto:Jeremy@kwmassage.com\">Jeremy@kwmassage.com</a>
<div></div>
<iframe src=\"https://mapsengine.google.com/map/embed?mid=z1kzsRant038.kwaZ-HV4FUfg\" height=\"400\" width=\"550\"></iframe>
<div id=\"formbox\">
<h1>Contact Form</h1>
</div>
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Contact","","inherit","open","open","","21-revision-v1","","","2014-01-12 20:38:10","2014-01-12 20:38:10","","21","http://www.kwmassage.com/clinic-information","0","revision","","0");
INSERT INTO `wp_posts` VALUES("186","3","2014-01-12 20:36:37","2014-01-12 20:36:37","The quickest way to book an appointment with me is to book a treatment online<a href=\"file:///C:/Users/KWmassage/Documents/JeremyBissonnetteWebsiteReview-progression.docx#_msocom_1\">[C1]</a> .

To get in touch with me directly to make a <a href=\"http://www.kwmassage.com/clinic-information\">massage therapy appointment </a>in Kitchener/Waterloo, you can call me, send me an email or text message, or you can <a href=\"http://www.facebook.com/pages/KWmassage/354131367967709\">Facebook</a> me. You can also use the form below to send me a message.

229 Frederick Street
Kitchener, ON
(519) 745-4112
<a href=\"mailto:Jeremy@kwmassage.com\">Jeremy@kwmassage.com</a>
<div></div>
<iframe src=\"https://mapsengine.google.com/map/embed?mid=z1kzsRant038.kwaZ-HV4FUfg\" height=\"400\" width=\"550\"></iframe>
<div id=\"formbox\">
<h1>Contact Form</h1>
</div>
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Contact","","inherit","open","open","","21-revision-v1","","","2014-01-12 20:36:37","2014-01-12 20:36:37","","21","http://www.kwmassage.com/clinic-information","0","revision","","0");
INSERT INTO `wp_posts` VALUES("188","3","2014-01-12 20:43:40","2014-01-12 20:43:40","<h1>Kitchener Massage</h1>
Specializing in Deep Tissue Massage and Trigger Point Release Therapy to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace and family life.
<div class=\"testimonialbox\">
<div class=\"testimonialinner\">
<div class=\"quotetop\">
<div class=\"quotebottom\">
<p style=\"padding-bottom: 0px;\"><strong>by Carrie - Technical Writer</strong>
I walked out of my first treatment with Jeremy impressed that he did exactly what I wanted him to do. Deep tissue massage treatment is nothing like a relaxing day at a spa, but it is precisely what I need...</p>

</div>
</div>
</div>
</div>
<div class=\"clear\"></div>
Deep Tissue massage is similar to the most common type of massage, Swedish massage, in that your therapist uses long, smooth and kneading strokes to achieve healing changes in the body. The two forms of massage differ in that Deep Tissue massage aims to affect the deeper structures of the body and have a deeper level of healing. Deep Tissue massage is very effective in treating chronic muscle and connective tissue injuries.
<div id=\"formbox\">
<h1>Contact Form</h1>
</div>
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Welcome","","inherit","open","open","","75-revision-v1","","","2014-01-12 20:43:40","2014-01-12 20:43:40","","75","http://www.kwmassage.com/clinic-information","0","revision","","0");
INSERT INTO `wp_posts` VALUES("214","3","2014-01-12 21:58:06","2014-01-12 21:58:06","<h1>Kitchener Massage Therapy</h1>
Specializing in <a href=\"http://www.kwmassage.com/generalmassagetherapy/what-is-deep-tissue-massage\">Deep Tissue Massage </a>and<a href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\"> Trigger Point Release Therapy </a>to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace, and family life.
<div class=\"testimonialbox\">
<div class=\"testimonialinner\">
<div class=\"quotetop\">
<div class=\"quotebottom\">
<p style=\"padding-bottom: 0px;\"><strong>by Carrie - Technical Writer</strong>
I walked out of my first treatment with Jeremy impressed that he did exactly what I wanted him to do. Deep tissue massage treatment is nothing like a relaxing day at a spa, but it is precisely what I need...</p>

</div>
</div>
</div>
</div>
<div class=\"clear\">

<b> </b>

</div>
<h2>What is Deep Tissue Massage?</h2>
Deep Tissue massage is similar to the most common type of massage, Swedish massage, in that your therapist uses long, smooth, and kneading strokes to achieve healing changes in the body. The two forms of massage differ in that <a title=\"Discomfort of deep tissue massage\" href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">Deep Tissue massage aims to affect the deeper structures of the body </a>and have a deeper level of healing. Deep Tissue massage is very effective in treating chronic muscle and connective tissue injuries. <a title=\"What is Deep Tissue Massage?\" href=\"http://www.kwmassage.com/generalmassagetherapy/what-is-deep-tissue-massage\">
</a>
<div id=\"formbox\">
<h1>Contact Form</h1>
</div>
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Welcome","","inherit","open","open","","75-revision-v1","","","2014-01-12 21:58:06","2014-01-12 21:58:06","","75","http://www.kwmassage.com/generalmassagetherapy/75-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("190","3","2014-01-12 20:45:02","2014-01-12 20:45:02","<h1>Kitchener Massage Therapy</h1>
Specializing in Deep Tissue Massage and Trigger Point Release Therapy to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace and family life.
<div class=\"testimonialbox\">
<div class=\"testimonialinner\">
<div class=\"quotetop\">
<div class=\"quotebottom\">
<p style=\"padding-bottom: 0px;\"><strong>by Carrie - Technical Writer</strong>
I walked out of my first treatment with Jeremy impressed that he did exactly what I wanted him to do. Deep tissue massage treatment is nothing like a relaxing day at a spa, but it is precisely what I need...</p>

</div>
</div>
</div>
</div>
<div class=\"clear\"></div>
Deep Tissue massage is similar to the most common type of massage, Swedish massage, in that your therapist uses long, smooth and kneading strokes to achieve healing changes in the body. The two forms of massage differ in that Deep Tissue massage aims to affect the deeper structures of the body and have a deeper level of healing. Deep Tissue massage is very effective in treating chronic muscle and connective tissue injuries.
<div id=\"formbox\">
<h1>Contact Form</h1>
</div>
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Welcome","","inherit","open","open","","75-revision-v1","","","2014-01-12 20:45:02","2014-01-12 20:45:02","","75","http://www.kwmassage.com/clinic-information","0","revision","","0");
INSERT INTO `wp_posts` VALUES("191","3","2014-01-12 20:47:01","2014-01-12 20:47:01","<h1>Kitchener Massage Therapy</h1>
Specializing in Deep Tissue Massage and Trigger Point Release Therapy to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace and family life.
<div class=\"testimonialbox\">
<div class=\"testimonialinner\">
<div class=\"quotetop\">
<div class=\"quotebottom\">
<p style=\"padding-bottom: 0px;\"><strong>by Carrie - Technical Writer</strong>
I walked out of my first treatment with Jeremy impressed that he did exactly what I wanted him to do. Deep tissue massage treatment is nothing like a relaxing day at a spa, but it is precisely what I need...</p>

</div>
</div>
</div>
</div>
<div class=\"clear\"></div>
Deep Tissue massage is similar to the most common type of massage, Swedish massage, in that your therapist uses long, smooth and kneading strokes to achieve healing changes in the body. The two forms of massage differ in that Deep Tissue massage aims to affect the deeper structures of the body and have a deeper level of healing. Deep Tissue massage is very effective in treating chronic muscle and connective tissue injuries.
<div id=\"formbox\">
<h1>Contact Form</h1>
</div>
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","","","inherit","open","open","","75-revision-v1","","","2014-01-12 20:47:01","2014-01-12 20:47:01","","75","http://www.kwmassage.com/clinic-information","0","revision","","0");
INSERT INTO `wp_posts` VALUES("192","3","2014-01-12 20:47:37","2014-01-12 20:47:37","<h1>Kitchener Massage Therapy</h1>
Specializing in Deep Tissue Massage and Trigger Point Release Therapy to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace and family life.
<div class=\"testimonialbox\">
<div class=\"testimonialinner\">
<div class=\"quotetop\">
<div class=\"quotebottom\">
<p style=\"padding-bottom: 0px;\"><strong>by Carrie - Technical Writer</strong>
I walked out of my first treatment with Jeremy impressed that he did exactly what I wanted him to do. Deep tissue massage treatment is nothing like a relaxing day at a spa, but it is precisely what I need...</p>

</div>
</div>
</div>
</div>
<div class=\"clear\"></div>
Deep Tissue massage is similar to the most common type of massage, Swedish massage, in that your therapist uses long, smooth and kneading strokes to achieve healing changes in the body. The two forms of massage differ in that Deep Tissue massage aims to affect the deeper structures of the body and have a deeper level of healing. Deep Tissue massage is very effective in treating chronic muscle and connective tissue injuries.
<div id=\"formbox\">
<h1>Contact Form</h1>
</div>
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Welcome","","inherit","open","open","","75-revision-v1","","","2014-01-12 20:47:37","2014-01-12 20:47:37","","75","http://www.kwmassage.com/clinic-information","0","revision","","0");
INSERT INTO `wp_posts` VALUES("193","3","2014-01-12 20:52:24","2014-01-12 20:52:24","<h1>Kitchener Massage Therapy</h1>
Specializing in <a href=\"http://www.kwmassage.com/generalmassagetherapy/what-is-deep-tissue-massage\">Deep Tissue Massage </a>and<a href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\"> Trigger Point Release Therapy </a>to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace, and family life.
<div class=\"testimonialbox\">
<div class=\"testimonialinner\">
<div class=\"quotetop\">
<div class=\"quotebottom\">
<p style=\"padding-bottom: 0px;\"><strong>by Carrie - Technical Writer</strong>
I walked out of my first treatment with Jeremy impressed that he did exactly what I wanted him to do. Deep tissue massage treatment is nothing like a relaxing day at a spa, but it is precisely what I need...</p>

</div>
</div>
</div>
</div>
<div class=\"clear\">

<b>What is Deep Tissue Massage?</b>

</div>
Deep Tissue massage is similar to the most common type of massage, Swedish massage, in that your therapist uses long, smooth, and kneading strokes to achieve healing changes in the body. The two forms of massage differ in that <a title=\"Discomfort of deep tissue massage\" href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">Deep Tissue massage aims to affect the deeper structures of the body </a>and have a deeper level of healing. Deep Tissue massage is very effective in treating chronic muscle and connective tissue injuries.
<div id=\"formbox\">
<h1>Contact Form</h1>
</div>
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Welcome","","inherit","open","open","","75-revision-v1","","","2014-01-12 20:52:24","2014-01-12 20:52:24","","75","http://www.kwmassage.com/clinic-information","0","revision","","0");
INSERT INTO `wp_posts` VALUES("194","3","2014-01-12 20:53:31","2014-01-12 20:53:31","<h1>Kitchener Massage Therapy</h1>
Specializing in <a href=\"http://www.kwmassage.com/generalmassagetherapy/what-is-deep-tissue-massage\">Deep Tissue Massage </a>and<a href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\"> Trigger Point Release Therapy </a>to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace, and family life.
<div class=\"testimonialbox\">
<div class=\"testimonialinner\">
<div class=\"quotetop\">
<div class=\"quotebottom\">
<p style=\"padding-bottom: 0px;\"><strong>by Carrie - Technical Writer</strong>
I walked out of my first treatment with Jeremy impressed that he did exactly what I wanted him to do. Deep tissue massage treatment is nothing like a relaxing day at a spa, but it is precisely what I need...</p>

</div>
</div>
</div>
</div>
<div class=\"clear\">

<b> </b>

</div>
<h1>What is Deep Tissue Massage?</h1>
Deep Tissue massage is similar to the most common type of massage, Swedish massage, in that your therapist uses long, smooth, and kneading strokes to achieve healing changes in the body. The two forms of massage differ in that <a title=\"Discomfort of deep tissue massage\" href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">Deep Tissue massage aims to affect the deeper structures of the body </a>and have a deeper level of healing. Deep Tissue massage is very effective in treating chronic muscle and connective tissue injuries.
<div id=\"formbox\">
<h1>Contact Form</h1>
</div>
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Welcome","","inherit","open","open","","75-revision-v1","","","2014-01-12 20:53:31","2014-01-12 20:53:31","","75","http://www.kwmassage.com/clinic-information","0","revision","","0");
INSERT INTO `wp_posts` VALUES("195","3","2014-01-12 20:54:05","2014-01-12 20:54:05","<h1>Kitchener Massage Therapy</h1>
Specializing in <a href=\"http://www.kwmassage.com/generalmassagetherapy/what-is-deep-tissue-massage\">Deep Tissue Massage </a>and<a href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\"> Trigger Point Release Therapy </a>to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace, and family life.
<div class=\"testimonialbox\">
<div class=\"testimonialinner\">
<div class=\"quotetop\">
<div class=\"quotebottom\">
<p style=\"padding-bottom: 0px;\"><strong>by Carrie - Technical Writer</strong>
I walked out of my first treatment with Jeremy impressed that he did exactly what I wanted him to do. Deep tissue massage treatment is nothing like a relaxing day at a spa, but it is precisely what I need...</p>

</div>
</div>
</div>
</div>
<div class=\"clear\">

<b> </b>

</div>
<h2>What is Deep Tissue Massage?</h2>
Deep Tissue massage is similar to the most common type of massage, Swedish massage, in that your therapist uses long, smooth, and kneading strokes to achieve healing changes in the body. The two forms of massage differ in that <a title=\"Discomfort of deep tissue massage\" href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">Deep Tissue massage aims to affect the deeper structures of the body </a>and have a deeper level of healing. Deep Tissue massage is very effective in treating chronic muscle and connective tissue injuries.
<div id=\"formbox\">
<h1>Contact Form</h1>
</div>
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Welcome","","inherit","open","open","","75-revision-v1","","","2014-01-12 20:54:05","2014-01-12 20:54:05","","75","http://www.kwmassage.com/clinic-information","0","revision","","0");
INSERT INTO `wp_posts` VALUES("196","3","2014-01-12 21:00:22","2014-01-12 21:00:22","<a title=\"Kitchener Massage Therapy Welcome Video\" href=\"http://youtu.be/XSRrvEXZSdk\" target=\"_blank\" rel=\"http://youtu.be/XSRrvEXZSdk\"><img class=\" wp-image-155 alignleft\" alt=\"Jeremy Bissonnette, Registered Massage Therapist\" src=\"http://www.kwmassage.com/wp-content/uploads/2014/01/img_video-300x276.gif\" width=\"240\" height=\"221\" /></a>I graduated with Honours from the <a href=\"http://www.collegeofmassage.com/cambridge/\">Canadian College of Massage and Hydrotherapy </a>in 2005 as a <a href=\"http://www.cmto.com/\">Registered Massage Therapist </a>(RMT). I’ve practiced massage therapy in Kitchener and Waterloo in a variety of locations in including a home practice, the <a href=\"http://www.uoguelph.ca/hpc/\">University of Guelph’s Health and Performance Center, </a>and most recently, in an independently owned chiropractic office. I have also provided chair treatments at the <a href=\"http://www.kitchenermarket.ca/\">Kitchener Market </a>on a monthly basis in the past.

My massage therapy treatment style has been focused around <a href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">Deep Tissue Therapy </a>with an emphasis on helping clients learn to care for their own bodies. I have practiced yoga for the past 10 years and find my clients respond well to my recommendations around specific yoga asana and stretches to help with the different ailments they need to address. I find my knowledge of anatomy helps create clarity on the yoga mat and I have an interest in sharing this experience.
<div class=\"shadowbox\">
<h2>My Personal World</h2>
My main focus in life is caring for my 2 daughters, Rowan (7) and Breanne (5). I’m busy getting kids fed, dressed, doing hair, making bread, doing homework and housework, planning a garden, and all the activities associated with being a parent. Being a dad can have its challenges but it is also very rewarding. I feel very lucky to be able to fill this role while my wife works full-time.

In my spare time, I enjoy <a href=\"http://www.kwmassage.com/rock_climbing/rock-climbing-as-a-life-style\">rock climbing</a>, yoga, reading, camping, and gardening. Prior to becoming a registered massage therapist, I used to work in a <a href=\"http://www.paramountsports.ca/\">bike and snow board shop</a>, so when I can, I love to hit the hills and get back to my original roots.

</div>","About Jeremy","","inherit","open","open","","19-revision-v1","","","2014-01-12 21:00:22","2014-01-12 21:00:22","","19","http://www.kwmassage.com/clinic-information","0","revision","","0");
INSERT INTO `wp_posts` VALUES("224","3","2014-01-13 14:46:49","2014-01-13 14:46:49","When you come in for your first <a href=\"http://www.kwmassage.com/clinic-information\">massage therapy appointment </a>at <a href=\"http://www.kwmassage.com/\">KW massage </a>with me, a few things need to be done in preparation for your <a href=\"http://www.kwmassage.com/\">massage therapy treatment</a>.

First, I do not charge an initial consultation fee. What you pay depends on the length of treatment you request when you book the appointment. I do not charge any additional fees.

I have a <a href=\"http://www.kwmassage.com/wp-content/uploads/2014/01/Health-History.pdf\">health history form </a>that you need to fill out before we get started. Try to come about 10 minutes early to fill out this form. Or, you can also print it out and complete it ahead of time. Just be sure to bring it with you on the day of your first appointment.

This health history form  gives me a general overview of your state of health so that we can be sure there is no risk to the treatment plan I create for you. Once I have gone over your treatment plan, we will have a short discussion about what it is you want me to treat. I try not to take up more than a few minutes with this stage but it is important for me to have a clear picture of what we will be working on before we get started. I commonly ask questions like:

* where does it hurt?
* what does the pain feel like?
* what sort of things aggravate the injury?
* was there and accident to create the injury?

Sometimes I will want to have a closer look at your posture (the way you stand) or maybe I will want to do some range of motion testing. These tests will allow me to zone in on the source of your problem. Often, I don’t want to do any of these tests; I find I can get the same information while you are on the table by making the testing and treating procedure one and the same.

After I get a general idea of what it is I’m going to work on, it’s time to get started. While I go wash my hands, it’s your chance to get ready for your treatment. You always have the final say regarding how you get ready and what clothes you are comfortable taking off.

Most of my clients are comfortable removing all their clothing but their underpants knowing that I will always make sure they are covered discreetly with a sheet. I only expose one part of your body at a time, and only the specific body part I will be working on.

During your treatment, I will be using an assortment of massage techniques. Some of these can be relaxing and others can be <a href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">kind of tender</a>. In most cases, <a href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">a little pain is necessary </a>to get the results you are looking for from a massage therapy treatment.

It’s important that you be able to rate your discomfort on a scale of 1 to 10, where 10 is the most pain you’ve ever experienced. A discomfort level of 7 or under can be appropriate depending on the injury or need, but any more than that won’t bring you healing benefits. If, at any time during your treatment, your discomfort level becomes intolerable, please speak up. You may find that some areas of the body are more sensitive than others, or that your sensitivity changes day to day. Feel free to let me know how you’re doing. It’s entirely okay to ask me to adjust my pressure and technique at any time during your treatment.

During your massage treatment, I will try to spark up a conversation. Not only does this allow us to become better acquainted, but I also find that a light conversation helps distract you from when I find a sore spot like a <a href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\">Trigger Point </a>or Scar Tissue. This distraction technique allows you to stay relaxed, helps keep your muscles from pushing back against me working, and reduces pain overall. I often try to direct conversation to subjects that might give me clues or hints about what is creating your pain or discomfort. Topics like your work, the kind of car you drive, or sports or athletics you are involved often give me lots of information about you posture, repetitive movements you often do, or strength or flexibility issues.

When your treatment is complete, I will let you know, then go wash my hands again (I do this a lot). This gives you time to get up, get dressed, and come out to see me. If, during your treatment, we discussed any exercises, stretches, or heat/cold treatments for you do at home, this is when I will go over that in more detail.

After the massage treatment, it is also time to handle the payment and rebooking. I don’t have credit or debit machines so cash payment is necessary.

If you have extended health care benefits, on my receipt you will find my <a href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">registration number as a registered massage therapist</a>.  When you send your receipt to your health care company for reimbursement, this registration is what they need for approval.
<div></div>","Note to New Massage Clients","","publish","open","open","","note-to-new-massage-therapy-clients","","","2014-01-13 16:22:03","2014-01-13 16:22:03","","7","http://www.kwmassage.com/?page_id=224","0","page","","0");
INSERT INTO `wp_posts` VALUES("223","3","2014-01-13 14:39:21","2014-01-13 14:39:21","When you come in for your first <a href=\"http://www.kwmassage.com/clinic-information\">massage therapy appointment </a>at <a href=\"http://www.kwmassage.com/\">KW massage </a>with me, a few things need to be done in preparation for your <a href=\"http://www.kwmassage.com/\">massage therapy treatment</a>.

First, I do not charge an initial consultation fee. What you pay depends on the length of treatment you request when you book the appointment. I do not charge any additional fees.

I have a <a href=\"http://www.kwmassage.com/wp-content/uploads/2011/06/Health-History.pdf\">health history form </a>that you need to fill out before we get started. Try to come about 10 minutes early to fill out this form. Or, you can also print it out and complete it ahead of time. Just be sure to bring it with you on the day of your first appointment.

This health history form  gives me a general overview of your state of health so that we can be sure there is no risk to the treatment plan I create for you. Once I have gone over your treatment plan, we will have a short discussion about what it is you want me to treat. I try not to take up more than a few minutes with this stage but it is important for me to have a clear picture of what we will be working on before we get started. I commonly ask questions like:
<ul>
	<li>where does it hurt?</li>
	<li>what does the pain feel like?</li>
	<li>what sort of things aggravate the injury?</li>
	<li>was there and accident to create the injury?</li>
</ul>
Sometimes I will want to have a closer look at your posture (the way you stand) or maybe I will want to do some range of motion testing. These tests will allow me to zone in on the source of your problem. Often, I don’t want to do any of these tests; I find I can get the same information while you are on the table by making the testing and treating procedure one and the same.

After I get a general idea of what it is I’m going to work on, it’s time to get started. While I go wash my hands, it’s your chance to get ready for your treatment. You always have the final say regarding how you get ready and what clothes you are comfortable taking off.

Most of my clients are comfortable removing all their clothing but their underpants knowing that I will always make sure they are covered discreetly with a sheet. I only expose one part of your body at a time, and only the specific body part I will be working on.

During your treatment, I will be using an assortment of massage techniques. Some of these can be relaxing and others can be <a href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">kind of tender</a>. In most cases, <a href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">a little pain is necessary </a>to get the results you are looking for from a massage therapy treatment.

It’s important that you be able to rate your discomfort on a scale of 1 to 10, where 10 is the most pain you’ve ever experienced. A discomfort level of 7 or under can be appropriate depending on the injury or need, but any more than that won’t bring you healing benefits. If, at any time during your treatment, your discomfort level becomes intolerable, please speak up. You may find that some areas of the body are more sensitive than others, or that your sensitivity changes day to day. Feel free to let me know how you’re doing. It’s entirely okay to ask me to adjust my pressure and technique at any time during your treatment.

During your massage treatment, I will try to spark up a conversation. Not only does this allow us to become better acquainted, but I also find that a light conversation helps distract you from when I find a sore spot like a <a href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\">Trigger Point </a>or Scar Tissue. This distraction technique allows you to stay relaxed, helps keep your muscles from pushing back against me working, and reduces pain overall. I often try to direct conversation to subjects that might give me clues or hints about what is creating your pain or discomfort. Topics like your work, the kind of car you drive, or sports or athletics you are involved often give me lots of information about you posture, repetitive movements you often do, or strength or flexibility issues.

When your treatment is complete, I will let you know, then go wash my hands again (I do this a lot). This gives you time to get up, get dressed, and come out to see me. If, during your treatment, we discussed any exercises, stretches, or heat/cold treatments for you do at home, this is when I will go over that in more detail.

After the massage treatment, it is also time to handle the payment and rebooking. I don’t have credit or debit machines so cash payment is necessary.

If you have extended health care benefits, on my receipt you will find my <a href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">registration number as a registered massage therapist</a>.  When you send your receipt to your health care company for reimbursement, this registration is what they need for approval.
<div></div>","Note to New Massage Therapy Clients ","","inherit","open","open","","221-revision-v1","","","2014-01-13 14:39:21","2014-01-13 14:39:21","","221","http://www.kwmassage.com/generalmassagetherapy/221-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("220","3","2014-01-12 22:17:35","2014-01-12 22:17:35","<a href=\"http://www.kwmassage.com/about\">After studying and treating Trigger Points for many years, </a>I describe them to my clients as a part of muscle that has become hyper-sensitive and irritable. Trigger Points are found in a tight or stiff band of muscle, and they can be found in muscles throughout the body. The following video shows me describing a Trigger Point to a client:

<iframe width=\"560\" height=\"315\" src=\"//www.youtube.com/embed/shGC3k2tlb0?rel=0\" frameborder=\"0\" allowfullscreen></iframe>

Trigger Points are sensitive to touch and they usually have a pattern of pain that presents in another part of the body. Sometimes where you hurt is not necessarily where the problem needs to be treated. The Trigger Point Chart below shows you how this referral pain travels. A Trigger Point in the Lower Trapezius muscle (represented as an X in the pink area) can show up as pain at the base of the skull because a Trigger Point in that one muscle can affect a significant area. It is very common to have pain referred from one part of your body to another, and I use Trigger Point Charts in my office to locate, connect, and treat pain on a regular basis.

[add trigger point chart here]

Over time, trigger points can create a chronic shortening of affected muscle, and trigger points are often responsible for many chronic pain syndromes such as torticollis, <a href=\"http://www.kwmassage.com/generalmassagetherapy/tension-headaches-3\">headaches</a>, <a href=\"http://www.kwmassage.com/stretching/low-back-pain\">back pain</a>, knee pain, and postural stress.

At<a href=\"http://www.kwmassage.com/\"> Kitchener Massage Therapy </a>I use a few different <a href=\"http://www.kwmassage.com/generalmassagetherapy/what-is-deep-tissue-massage\">Deep Tissue Massage </a>techniques like muscle stripping, direct pressure held for up to a minute, and<a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\"> stretching</a>to treat Trigger Points.

<a href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">It is uncomfortable to have a Trigger Point worked out </a>but the relief you get from the <a href=\"http://www.kwmassage.com/generalmassagetherapy/tension-headaches-3\">headache</a>, <a href=\"http://www.kwmassage.com/stretching/low-back-pain\">sore back </a>or <a href=\"http://www.kwmassage.com/generalmassagetherapy/what-can-deep-tissue-massage-treat\">whatever it is you are experiencing</a> can be great. My clients often describe the pain from Trigger Point work as a good pain . I think this stems from the fact that someone has finally been able to pinpoint and address the source of their discomfort after what could have been many years.","Trigger Points and Trigger Point Therapy ","","inherit","open","open","","219-revision-v1","","","2014-01-12 22:17:35","2014-01-12 22:17:35","","219","http://www.kwmassage.com/generalmassagetherapy/219-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("221","3","2014-01-13 14:38:17","2014-01-13 14:38:17","When you come in for your first <a href=\"http://www.kwmassage.com/clinic-information\">massage therapy appointment </a>at <a href=\"http://www.kwmassage.com/\">KW massage </a>with me, a few things need to be done in preparation for your <a href=\"http://www.kwmassage.com/\">massage therapy treatment</a>.

First, I do not charge an initial consultation fee. What you pay depends on the length of treatment you request when you book the appointment. I do not charge any additional fees.

I have a <a href=\"http://www.kwmassage.com/wp-content/uploads/2014/01/Health-History.pdf\">health history form </a>that you need to fill out before we get started. Try to come about 10 minutes early to fill out this form. Or, you can also print it out and complete it ahead of time. Just be sure to bring it with you on the day of your first appointment.

This health history form  gives me a general overview of your state of health so that we can be sure there is no risk to the treatment plan I create for you. Once I have gone over your treatment plan, we will have a short discussion about what it is you want me to treat. I try not to take up more than a few minutes with this stage but it is important for me to have a clear picture of what we will be working on before we get started. I commonly ask questions like:
<ul>
	<li>where does it hurt?</li>
	<li>what does the pain feel like?</li>
	<li>what sort of things aggravate the injury?</li>
	<li>was there and accident to create the injury?</li>
</ul>
Sometimes I will want to have a closer look at your posture (the way you stand) or maybe I will want to do some range of motion testing. These tests will allow me to zone in on the source of your problem. Often, I don’t want to do any of these tests; I find I can get the same information while you are on the table by making the testing and treating procedure one and the same.

After I get a general idea of what it is I’m going to work on, it’s time to get started. While I go wash my hands, it’s your chance to get ready for your treatment. You always have the final say regarding how you get ready and what clothes you are comfortable taking off.

Most of my clients are comfortable removing all their clothing but their underpants knowing that I will always make sure they are covered discreetly with a sheet. I only expose one part of your body at a time, and only the specific body part I will be working on.

During your treatment, I will be using an assortment of massage techniques. Some of these can be relaxing and others can be <a href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">kind of tender</a>. In most cases, <a href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">a little pain is necessary </a>to get the results you are looking for from a massage therapy treatment.

It’s important that you be able to rate your discomfort on a scale of 1 to 10, where 10 is the most pain you’ve ever experienced. A discomfort level of 7 or under can be appropriate depending on the injury or need, but any more than that won’t bring you healing benefits. If, at any time during your treatment, your discomfort level becomes intolerable, please speak up. You may find that some areas of the body are more sensitive than others, or that your sensitivity changes day to day. Feel free to let me know how you’re doing. It’s entirely okay to ask me to adjust my pressure and technique at any time during your treatment.

During your massage treatment, I will try to spark up a conversation. Not only does this allow us to become better acquainted, but I also find that a light conversation helps distract you from when I find a sore spot like a <a href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\">Trigger Point </a>or Scar Tissue. This distraction technique allows you to stay relaxed, helps keep your muscles from pushing back against me working, and reduces pain overall. I often try to direct conversation to subjects that might give me clues or hints about what is creating your pain or discomfort. Topics like your work, the kind of car you drive, or sports or athletics you are involved often give me lots of information about you posture, repetitive movements you often do, or strength or flexibility issues.

When your treatment is complete, I will let you know, then go wash my hands again (I do this a lot). This gives you time to get up, get dressed, and come out to see me. If, during your treatment, we discussed any exercises, stretches, or heat/cold treatments for you do at home, this is when I will go over that in more detail.

After the massage treatment, it is also time to handle the payment and rebooking. I don’t have credit or debit machines so cash payment is necessary.

If you have extended health care benefits, on my receipt you will find my <a href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">registration number as a registered massage therapist</a>.  When you send your receipt to your health care company for reimbursement, this registration is what they need for approval.
<div></div>","Note to New Massage Therapy Clients ","","publish","open","open","","note-to-new-massage-therapy-clients","","http://www.kwmassage.com/clinic-information
http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage","2014-01-13 16:26:57","2014-01-13 16:26:57","","0","http://www.kwmassage.com/?p=221","0","post","","0");
INSERT INTO `wp_posts` VALUES("222","3","2014-01-13 14:38:17","2014-01-13 14:38:17","","Note to New Massage Therapy Clients ","","inherit","open","open","","221-revision-v1","","","2014-01-13 14:38:17","2014-01-13 14:38:17","","221","http://www.kwmassage.com/generalmassagetherapy/221-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("206","3","2014-01-12 21:41:11","2014-01-12 21:41:11","<h1>Kitchener Massage Therapy</h1>
Specializing in <a href=\"http://www.kwmassage.com/generalmassagetherapy/what-is-deep-tissue-massage\">Deep Tissue Massage </a>and<a href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\"> Trigger Point Release Therapy </a>to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace, and family life.
<div class=\"testimonialbox\">
<div class=\"testimonialinner\">
<div class=\"quotetop\">
<div class=\"quotebottom\">
<p style=\"padding-bottom: 0px;\"><strong>by Carrie - Technical Writer</strong>
I walked out of my first treatment with Jeremy impressed that he did exactly what I wanted him to do. Deep tissue massage treatment is nothing like a relaxing day at a spa, but it is precisely what I need...</p>

</div>
</div>
</div>
</div>
<div class=\"clear\">

<b> </b>

</div>
<h2>What is Deep Tissue Massage?</h2>
Deep Tissue massage is similar to the most common type of massage, Swedish massage, in that your therapist uses long, smooth, and kneading strokes to achieve healing changes in the body. The two forms of massage differ in that <a title=\"Discomfort of deep tissue massage\" href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">Deep Tissue massage aims to affect the deeper structures of the body </a>and have a deeper level of healing. Deep Tissue massage is very effective in treating chronic muscle and connective tissue injuries. <a title=\"What is Deep Tissue Massage?\" href=\"http://www.kwmassage.com/generalmassagetherapywhat-is-deep-tissue-massage/\">Read more...</a>
<div id=\"formbox\">
<h1>Contact Form</h1>
</div>
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Welcome","","inherit","open","open","","75-revision-v1","","","2014-01-12 21:41:11","2014-01-12 21:41:11","","75","http://www.kwmassage.com/75-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("213","3","2014-01-12 21:57:43","2014-01-12 21:57:43","<h1>Kitchener Massage Therapy</h1>
Specializing in <a href=\"http://www.kwmassage.com/generalmassagetherapy/what-is-deep-tissue-massage\">Deep Tissue Massage </a>and<a href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\"> Trigger Point Release Therapy </a>to bring you the relief you need from repetitive strain injuries and postural dysfunctions related to sports, the workplace, and family life.
<div class=\"testimonialbox\">
<div class=\"testimonialinner\">
<div class=\"quotetop\">
<div class=\"quotebottom\">
<p style=\"padding-bottom: 0px;\"><strong>by Carrie - Technical Writer</strong>
I walked out of my first treatment with Jeremy impressed that he did exactly what I wanted him to do. Deep tissue massage treatment is nothing like a relaxing day at a spa, but it is precisely what I need...</p>

</div>
</div>
</div>
</div>
<div class=\"clear\">

<b> </b>

</div>
<h2>What is Deep Tissue Massage?</h2>
Deep Tissue massage is similar to the most common type of massage, Swedish massage, in that your therapist uses long, smooth, and kneading strokes to achieve healing changes in the body. The two forms of massage differ in that <a title=\"Discomfort of deep tissue massage\" href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">Deep Tissue massage aims to affect the deeper structures of the body </a>and have a deeper level of healing. Deep Tissue massage is very effective in treating chronic muscle and connective tissue injuries. <a title=\"What is Deep Tissue Massage?\" href=\"http://www.kwmassage.com/generalmassagetherapy/what-is-deep-tissue-massage\">Read more...</a>
<div id=\"formbox\">
<h1>Contact Form</h1>
</div>
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Welcome","","inherit","open","open","","75-autosave-v1","","","2014-01-12 21:57:43","2014-01-12 21:57:43","","75","http://www.kwmassage.com/generalmassagetherapy/75-autosave-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("211","3","2014-01-12 21:55:12","2014-01-12 21:55:12","Deep Tissue massage is similar to the most common type of massage, Swedish massage, in that your therapist uses long, smooth, and kneading strokes to achieve healing changes in the body. The two forms of massage differ in that <a title=\"Discomfort of deep tissue massage\" href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">Deep Tissue massage aims to affect the deeper structures of the body </a>and have a deeper level of healing. Deep Tissue massage is very effective in treating chronic muscle and connective tissue injuries.

In order to access deeper layers of muscle and connective tissue in the body, your massage therapist needs to use considerable pressure; to achieve that pressure, he or she needs skilled in using forearms, elbows, and knuckles to perform the massage techniques.

<a href=\"http://maps.google.ca/maps/place?rlz=1I7DDCA_en&amp;oe=UTF-8&amp;redir_esc=&amp;um=1&amp;ie=UTF-8&amp;q=massage+therapist+kitchener&amp;fb=1&amp;gl=ca&amp;hq=massage+therapist&amp;hnear=Kitchener,+ON&amp;cid=4280028541904649170&amp;ei=oGLATc6vDdOftwfb3ey8BQ&amp;sa=X&amp;oi=local_result&amp;ct=map-marker-link&amp;resnum=7&amp;ved=0CG4QrwswBg\">Deep Tissue massage </a>provides a more therapeutic effect by working more than just superficial layers in the body. Deep Tissue massage gets right down to the core of your muscular system to remove chronic tension, scar tissue, and adhesions between muscles and connective tissue, helping you get the relief you need faster.","What is Deep Tissue Massage?","","publish","open","open","","what-is-deep-tissue-massage","","","2014-01-12 21:56:01","2014-01-12 21:56:01","","0","http://www.kwmassage.com/?p=211","0","post","","0");
INSERT INTO `wp_posts` VALUES("212","3","2014-01-12 21:55:12","2014-01-12 21:55:12","Deep Tissue massage is similar to the most common type of massage, Swedish massage, in that your therapist uses long, smooth, and kneading strokes to achieve healing changes in the body. The two forms of massage differ in that <a title=\"Discomfort of deep tissue massage\" href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">Deep Tissue massage aims to affect the deeper structures of the body </a>and have a deeper level of healing. Deep Tissue massage is very effective in treating chronic muscle and connective tissue injuries.

In order to access deeper layers of muscle and connective tissue in the body, your massage therapist needs to use considerable pressure; to achieve that pressure, he or she needs skilled in using forearms, elbows, and knuckles to perform the massage techniques.

<a href=\"http://maps.google.ca/maps/place?rlz=1I7DDCA_en&amp;oe=UTF-8&amp;redir_esc=&amp;um=1&amp;ie=UTF-8&amp;q=massage+therapist+kitchener&amp;fb=1&amp;gl=ca&amp;hq=massage+therapist&amp;hnear=Kitchener,+ON&amp;cid=4280028541904649170&amp;ei=oGLATc6vDdOftwfb3ey8BQ&amp;sa=X&amp;oi=local_result&amp;ct=map-marker-link&amp;resnum=7&amp;ved=0CG4QrwswBg\">Deep Tissue massage </a>provides a more therapeutic effect by working more than just superficial layers in the body. Deep Tissue massage gets right down to the core of your muscular system to remove chronic tension, scar tissue, and adhesions between muscles and connective tissue, helping you get the relief you need faster.","What is Deep Tissue Massage?","","inherit","open","open","","211-revision-v1","","","2014-01-12 21:55:12","2014-01-12 21:55:12","","211","http://www.kwmassage.com/generalmassagetherapy/211-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("231","3","2014-01-13 14:55:55","2014-01-13 14:55:55","When you come in for your first <a href=\"http://www.kwmassage.com/clinic-information\">massage therapy appointment </a>at <a href=\"http://www.kwmassage.com/\">KW massage </a>with me, a few things need to be done in preparation for your <a href=\"http://www.kwmassage.com/\">massage therapy treatment</a>.

First, I do not charge an initial consultation fee. What you pay depends on the length of treatment you request when you book the appointment. I do not charge any additional fees.

I have a <a href=\"http://www.kwmassage.com/wp-content/uploads/2011/06/Health-History.pdf\">health history form </a>that you need to fill out before we get started. Try to come about 10 minutes early to fill out this form. Or, you can also print it out and complete it ahead of time. Just be sure to bring it with you on the day of your first appointment.

This health history form  gives me a general overview of your state of health so that we can be sure there is no risk to the treatment plan I create for you. Once I have gone over your treatment plan, we will have a short discussion about what it is you want me to treat. I try not to take up more than a few minutes with this stage but it is important for me to have a clear picture of what we will be working on before we get started. I commonly ask questions like:

* where does it hurt?
* what does the pain feel like?
* what sort of things aggravate the injury?
* was there and accident to create the injury?
Sometimes I will want to have a closer look at your posture (the way you stand) or maybe I will want to do some range of motion testing. These tests will allow me to zone in on the source of your problem. Often, I don’t want to do any of these tests; I find I can get the same information while you are on the table by making the testing and treating procedure one and the same.

After I get a general idea of what it is I’m going to work on, it’s time to get started. While I go wash my hands, it’s your chance to get ready for your treatment. You always have the final say regarding how you get ready and what clothes you are comfortable taking off.

Most of my clients are comfortable removing all their clothing but their underpants knowing that I will always make sure they are covered discreetly with a sheet. I only expose one part of your body at a time, and only the specific body part I will be working on.

During your treatment, I will be using an assortment of massage techniques. Some of these can be relaxing and others can be <a href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">kind of tender</a>. In most cases, <a href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">a little pain is necessary </a>to get the results you are looking for from a massage therapy treatment.

It’s important that you be able to rate your discomfort on a scale of 1 to 10, where 10 is the most pain you’ve ever experienced. A discomfort level of 7 or under can be appropriate depending on the injury or need, but any more than that won’t bring you healing benefits. If, at any time during your treatment, your discomfort level becomes intolerable, please speak up. You may find that some areas of the body are more sensitive than others, or that your sensitivity changes day to day. Feel free to let me know how you’re doing. It’s entirely okay to ask me to adjust my pressure and technique at any time during your treatment.

During your massage treatment, I will try to spark up a conversation. Not only does this allow us to become better acquainted, but I also find that a light conversation helps distract you from when I find a sore spot like a <a href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\">Trigger Point </a>or Scar Tissue. This distraction technique allows you to stay relaxed, helps keep your muscles from pushing back against me working, and reduces pain overall. I often try to direct conversation to subjects that might give me clues or hints about what is creating your pain or discomfort. Topics like your work, the kind of car you drive, or sports or athletics you are involved often give me lots of information about you posture, repetitive movements you often do, or strength or flexibility issues.

When your treatment is complete, I will let you know, then go wash my hands again (I do this a lot). This gives you time to get up, get dressed, and come out to see me. If, during your treatment, we discussed any exercises, stretches, or heat/cold treatments for you do at home, this is when I will go over that in more detail.

After the massage treatment, it is also time to handle the payment and rebooking. I don’t have credit or debit machines so cash payment is necessary.

If you have extended health care benefits, on my receipt you will find my <a href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">registration number as a registered massage therapist</a>.  When you send your receipt to your health care company for reimbursement, this registration is what they need for approval.
<div></div>","Note to New Massage Clients","","inherit","open","open","","224-revision-v1","","","2014-01-13 14:55:55","2014-01-13 14:55:55","","224","http://www.kwmassage.com/generalmassagetherapy/224-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("225","3","2014-01-13 14:46:49","2014-01-13 14:46:49","When you come in for your first <a href=\"http://www.kwmassage.com/clinic-information\">massage therapy appointment </a>at <a href=\"http://www.kwmassage.com/\">KW massage </a>with me, a few things need to be done in preparation for your <a href=\"http://www.kwmassage.com/\">massage therapy treatment</a>.

First, I do not charge an initial consultation fee. What you pay depends on the length of treatment you request when you book the appointment. I do not charge any additional fees.

I have a <a href=\"http://www.kwmassage.com/wp-content/uploads/2011/06/Health-History.pdf\">health history form </a>that you need to fill out before we get started. Try to come about 10 minutes early to fill out this form. Or, you can also print it out and complete it ahead of time. Just be sure to bring it with you on the day of your first appointment.

This health history form  gives me a general overview of your state of health so that we can be sure there is no risk to the treatment plan I create for you. Once I have gone over your treatment plan, we will have a short discussion about what it is you want me to treat. I try not to take up more than a few minutes with this stage but it is important for me to have a clear picture of what we will be working on before we get started. I commonly ask questions like:
<ul>
	<li>where does it hurt?</li>
	<li>what does the pain feel like?</li>
	<li>what sort of things aggravate the injury?</li>
	<li>was there and accident to create the injury?</li>
</ul>
Sometimes I will want to have a closer look at your posture (the way you stand) or maybe I will want to do some range of motion testing. These tests will allow me to zone in on the source of your problem. Often, I don’t want to do any of these tests; I find I can get the same information while you are on the table by making the testing and treating procedure one and the same.

After I get a general idea of what it is I’m going to work on, it’s time to get started. While I go wash my hands, it’s your chance to get ready for your treatment. You always have the final say regarding how you get ready and what clothes you are comfortable taking off.

Most of my clients are comfortable removing all their clothing but their underpants knowing that I will always make sure they are covered discreetly with a sheet. I only expose one part of your body at a time, and only the specific body part I will be working on.

During your treatment, I will be using an assortment of massage techniques. Some of these can be relaxing and others can be <a href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">kind of tender</a>. In most cases, <a href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">a little pain is necessary </a>to get the results you are looking for from a massage therapy treatment.

It’s important that you be able to rate your discomfort on a scale of 1 to 10, where 10 is the most pain you’ve ever experienced. A discomfort level of 7 or under can be appropriate depending on the injury or need, but any more than that won’t bring you healing benefits. If, at any time during your treatment, your discomfort level becomes intolerable, please speak up. You may find that some areas of the body are more sensitive than others, or that your sensitivity changes day to day. Feel free to let me know how you’re doing. It’s entirely okay to ask me to adjust my pressure and technique at any time during your treatment.

During your massage treatment, I will try to spark up a conversation. Not only does this allow us to become better acquainted, but I also find that a light conversation helps distract you from when I find a sore spot like a <a href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\">Trigger Point </a>or Scar Tissue. This distraction technique allows you to stay relaxed, helps keep your muscles from pushing back against me working, and reduces pain overall. I often try to direct conversation to subjects that might give me clues or hints about what is creating your pain or discomfort. Topics like your work, the kind of car you drive, or sports or athletics you are involved often give me lots of information about you posture, repetitive movements you often do, or strength or flexibility issues.

When your treatment is complete, I will let you know, then go wash my hands again (I do this a lot). This gives you time to get up, get dressed, and come out to see me. If, during your treatment, we discussed any exercises, stretches, or heat/cold treatments for you do at home, this is when I will go over that in more detail.

After the massage treatment, it is also time to handle the payment and rebooking. I don’t have credit or debit machines so cash payment is necessary.

If you have extended health care benefits, on my receipt you will find my <a href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">registration number as a registered massage therapist</a>.  When you send your receipt to your health care company for reimbursement, this registration is what they need for approval.
<div></div>","Note to New Massage Therapy Clients","","inherit","open","open","","224-revision-v1","","","2014-01-13 14:46:49","2014-01-13 14:46:49","","224","http://www.kwmassage.com/generalmassagetherapy/224-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("226","3","2014-01-13 14:50:14","2014-01-13 14:50:14","","Note to New Massage Clients","","publish","open","open","","note-to-new-massage-clients","","","2014-01-13 14:50:14","2014-01-13 14:50:14","","7","http://www.kwmassage.com/?p=226","4","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("228","3","2014-01-13 14:53:09","2014-01-13 14:53:09","When you come in for your first <a href=\"http://www.kwmassage.com/clinic-information\">massage therapy appointment </a>at <a href=\"http://www.kwmassage.com/\">KW massage </a>with me, a few things need to be done in preparation for your <a href=\"http://www.kwmassage.com/\">massage therapy treatment</a>.

First, I do not charge an initial consultation fee. What you pay depends on the length of treatment you request when you book the appointment. I do not charge any additional fees.

I have a <a href=\"http://www.kwmassage.com/wp-content/uploads/2011/06/Health-History.pdf\">health history form </a>that you need to fill out before we get started. Try to come about 10 minutes early to fill out this form. Or, you can also print it out and complete it ahead of time. Just be sure to bring it with you on the day of your first appointment.

This health history form  gives me a general overview of your state of health so that we can be sure there is no risk to the treatment plan I create for you. Once I have gone over your treatment plan, we will have a short discussion about what it is you want me to treat. I try not to take up more than a few minutes with this stage but it is important for me to have a clear picture of what we will be working on before we get started. I commonly ask questions like:
<ul>
	<li>where does it hurt?</li>
	<li>what does the pain feel like?</li>
	<li>what sort of things aggravate the injury?</li>
	<li>was there and accident to create the injury?</li>
</ul></br>
Sometimes I will want to have a closer look at your posture (the way you stand) or maybe I will want to do some range of motion testing. These tests will allow me to zone in on the source of your problem. Often, I don’t want to do any of these tests; I find I can get the same information while you are on the table by making the testing and treating procedure one and the same.

After I get a general idea of what it is I’m going to work on, it’s time to get started. While I go wash my hands, it’s your chance to get ready for your treatment. You always have the final say regarding how you get ready and what clothes you are comfortable taking off.

Most of my clients are comfortable removing all their clothing but their underpants knowing that I will always make sure they are covered discreetly with a sheet. I only expose one part of your body at a time, and only the specific body part I will be working on.

During your treatment, I will be using an assortment of massage techniques. Some of these can be relaxing and others can be <a href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">kind of tender</a>. In most cases, <a href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">a little pain is necessary </a>to get the results you are looking for from a massage therapy treatment.

It’s important that you be able to rate your discomfort on a scale of 1 to 10, where 10 is the most pain you’ve ever experienced. A discomfort level of 7 or under can be appropriate depending on the injury or need, but any more than that won’t bring you healing benefits. If, at any time during your treatment, your discomfort level becomes intolerable, please speak up. You may find that some areas of the body are more sensitive than others, or that your sensitivity changes day to day. Feel free to let me know how you’re doing. It’s entirely okay to ask me to adjust my pressure and technique at any time during your treatment.

During your massage treatment, I will try to spark up a conversation. Not only does this allow us to become better acquainted, but I also find that a light conversation helps distract you from when I find a sore spot like a <a href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\">Trigger Point </a>or Scar Tissue. This distraction technique allows you to stay relaxed, helps keep your muscles from pushing back against me working, and reduces pain overall. I often try to direct conversation to subjects that might give me clues or hints about what is creating your pain or discomfort. Topics like your work, the kind of car you drive, or sports or athletics you are involved often give me lots of information about you posture, repetitive movements you often do, or strength or flexibility issues.

When your treatment is complete, I will let you know, then go wash my hands again (I do this a lot). This gives you time to get up, get dressed, and come out to see me. If, during your treatment, we discussed any exercises, stretches, or heat/cold treatments for you do at home, this is when I will go over that in more detail.

After the massage treatment, it is also time to handle the payment and rebooking. I don’t have credit or debit machines so cash payment is necessary.

If you have extended health care benefits, on my receipt you will find my <a href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">registration number as a registered massage therapist</a>.  When you send your receipt to your health care company for reimbursement, this registration is what they need for approval.
<div></div>","Note to New Massage Clients","","inherit","open","open","","224-autosave-v1","","","2014-01-13 14:53:09","2014-01-13 14:53:09","","224","http://www.kwmassage.com/generalmassagetherapy/224-autosave-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("229","3","2014-01-13 14:54:01","2014-01-13 14:54:01","When you come in for your first <a href=\"http://www.kwmassage.com/clinic-information\">massage therapy appointment </a>at <a href=\"http://www.kwmassage.com/\">KW massage </a>with me, a few things need to be done in preparation for your <a href=\"http://www.kwmassage.com/\">massage therapy treatment</a>.

First, I do not charge an initial consultation fee. What you pay depends on the length of treatment you request when you book the appointment. I do not charge any additional fees.

I have a <a href=\"http://www.kwmassage.com/wp-content/uploads/2011/06/Health-History.pdf\">health history form </a>that you need to fill out before we get started. Try to come about 10 minutes early to fill out this form. Or, you can also print it out and complete it ahead of time. Just be sure to bring it with you on the day of your first appointment.

This health history form  gives me a general overview of your state of health so that we can be sure there is no risk to the treatment plan I create for you. Once I have gone over your treatment plan, we will have a short discussion about what it is you want me to treat. I try not to take up more than a few minutes with this stage but it is important for me to have a clear picture of what we will be working on before we get started. I commonly ask questions like:
<ul>
	<span><li>where does it hurt?</li></span>
	<li>what does the pain feel like?</li>
	<li>what sort of things aggravate the injury?</li>
	<li>was there and accident to create the injury?</li>
</ul></br>
Sometimes I will want to have a closer look at your posture (the way you stand) or maybe I will want to do some range of motion testing. These tests will allow me to zone in on the source of your problem. Often, I don’t want to do any of these tests; I find I can get the same information while you are on the table by making the testing and treating procedure one and the same.

After I get a general idea of what it is I’m going to work on, it’s time to get started. While I go wash my hands, it’s your chance to get ready for your treatment. You always have the final say regarding how you get ready and what clothes you are comfortable taking off.

Most of my clients are comfortable removing all their clothing but their underpants knowing that I will always make sure they are covered discreetly with a sheet. I only expose one part of your body at a time, and only the specific body part I will be working on.

During your treatment, I will be using an assortment of massage techniques. Some of these can be relaxing and others can be <a href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">kind of tender</a>. In most cases, <a href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">a little pain is necessary </a>to get the results you are looking for from a massage therapy treatment.

It’s important that you be able to rate your discomfort on a scale of 1 to 10, where 10 is the most pain you’ve ever experienced. A discomfort level of 7 or under can be appropriate depending on the injury or need, but any more than that won’t bring you healing benefits. If, at any time during your treatment, your discomfort level becomes intolerable, please speak up. You may find that some areas of the body are more sensitive than others, or that your sensitivity changes day to day. Feel free to let me know how you’re doing. It’s entirely okay to ask me to adjust my pressure and technique at any time during your treatment.

During your massage treatment, I will try to spark up a conversation. Not only does this allow us to become better acquainted, but I also find that a light conversation helps distract you from when I find a sore spot like a <a href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\">Trigger Point </a>or Scar Tissue. This distraction technique allows you to stay relaxed, helps keep your muscles from pushing back against me working, and reduces pain overall. I often try to direct conversation to subjects that might give me clues or hints about what is creating your pain or discomfort. Topics like your work, the kind of car you drive, or sports or athletics you are involved often give me lots of information about you posture, repetitive movements you often do, or strength or flexibility issues.

When your treatment is complete, I will let you know, then go wash my hands again (I do this a lot). This gives you time to get up, get dressed, and come out to see me. If, during your treatment, we discussed any exercises, stretches, or heat/cold treatments for you do at home, this is when I will go over that in more detail.

After the massage treatment, it is also time to handle the payment and rebooking. I don’t have credit or debit machines so cash payment is necessary.

If you have extended health care benefits, on my receipt you will find my <a href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">registration number as a registered massage therapist</a>.  When you send your receipt to your health care company for reimbursement, this registration is what they need for approval.
<div></div>","Note to New Massage Clients","","inherit","open","open","","224-revision-v1","","","2014-01-13 14:54:01","2014-01-13 14:54:01","","224","http://www.kwmassage.com/generalmassagetherapy/224-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("230","3","2014-01-13 14:54:20","2014-01-13 14:54:20","When you come in for your first <a href=\"http://www.kwmassage.com/clinic-information\">massage therapy appointment </a>at <a href=\"http://www.kwmassage.com/\">KW massage </a>with me, a few things need to be done in preparation for your <a href=\"http://www.kwmassage.com/\">massage therapy treatment</a>.

First, I do not charge an initial consultation fee. What you pay depends on the length of treatment you request when you book the appointment. I do not charge any additional fees.

I have a <a href=\"http://www.kwmassage.com/wp-content/uploads/2011/06/Health-History.pdf\">health history form </a>that you need to fill out before we get started. Try to come about 10 minutes early to fill out this form. Or, you can also print it out and complete it ahead of time. Just be sure to bring it with you on the day of your first appointment.

This health history form  gives me a general overview of your state of health so that we can be sure there is no risk to the treatment plan I create for you. Once I have gone over your treatment plan, we will have a short discussion about what it is you want me to treat. I try not to take up more than a few minutes with this stage but it is important for me to have a clear picture of what we will be working on before we get started. I commonly ask questions like:
<ul>
	<li>where does it hurt?</li>
	<li>what does the pain feel like?</li>
	<li>what sort of things aggravate the injury?</li>
	<li>was there and accident to create the injury?</li>
</ul></br>
Sometimes I will want to have a closer look at your posture (the way you stand) or maybe I will want to do some range of motion testing. These tests will allow me to zone in on the source of your problem. Often, I don’t want to do any of these tests; I find I can get the same information while you are on the table by making the testing and treating procedure one and the same.

After I get a general idea of what it is I’m going to work on, it’s time to get started. While I go wash my hands, it’s your chance to get ready for your treatment. You always have the final say regarding how you get ready and what clothes you are comfortable taking off.

Most of my clients are comfortable removing all their clothing but their underpants knowing that I will always make sure they are covered discreetly with a sheet. I only expose one part of your body at a time, and only the specific body part I will be working on.

During your treatment, I will be using an assortment of massage techniques. Some of these can be relaxing and others can be <a href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">kind of tender</a>. In most cases, <a href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">a little pain is necessary </a>to get the results you are looking for from a massage therapy treatment.

It’s important that you be able to rate your discomfort on a scale of 1 to 10, where 10 is the most pain you’ve ever experienced. A discomfort level of 7 or under can be appropriate depending on the injury or need, but any more than that won’t bring you healing benefits. If, at any time during your treatment, your discomfort level becomes intolerable, please speak up. You may find that some areas of the body are more sensitive than others, or that your sensitivity changes day to day. Feel free to let me know how you’re doing. It’s entirely okay to ask me to adjust my pressure and technique at any time during your treatment.

During your massage treatment, I will try to spark up a conversation. Not only does this allow us to become better acquainted, but I also find that a light conversation helps distract you from when I find a sore spot like a <a href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\">Trigger Point </a>or Scar Tissue. This distraction technique allows you to stay relaxed, helps keep your muscles from pushing back against me working, and reduces pain overall. I often try to direct conversation to subjects that might give me clues or hints about what is creating your pain or discomfort. Topics like your work, the kind of car you drive, or sports or athletics you are involved often give me lots of information about you posture, repetitive movements you often do, or strength or flexibility issues.

When your treatment is complete, I will let you know, then go wash my hands again (I do this a lot). This gives you time to get up, get dressed, and come out to see me. If, during your treatment, we discussed any exercises, stretches, or heat/cold treatments for you do at home, this is when I will go over that in more detail.

After the massage treatment, it is also time to handle the payment and rebooking. I don’t have credit or debit machines so cash payment is necessary.

If you have extended health care benefits, on my receipt you will find my <a href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">registration number as a registered massage therapist</a>.  When you send your receipt to your health care company for reimbursement, this registration is what they need for approval.
<div></div>","Note to New Massage Clients","","inherit","open","open","","224-revision-v1","","","2014-01-13 14:54:20","2014-01-13 14:54:20","","224","http://www.kwmassage.com/generalmassagetherapy/224-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("232","3","2014-01-13 14:56:16","2014-01-13 14:56:16","When you come in for your first <a href=\"http://www.kwmassage.com/clinic-information\">massage therapy appointment </a>at <a href=\"http://www.kwmassage.com/\">KW massage </a>with me, a few things need to be done in preparation for your <a href=\"http://www.kwmassage.com/\">massage therapy treatment</a>.

First, I do not charge an initial consultation fee. What you pay depends on the length of treatment you request when you book the appointment. I do not charge any additional fees.

I have a <a href=\"http://www.kwmassage.com/wp-content/uploads/2011/06/Health-History.pdf\">health history form </a>that you need to fill out before we get started. Try to come about 10 minutes early to fill out this form. Or, you can also print it out and complete it ahead of time. Just be sure to bring it with you on the day of your first appointment.

This health history form  gives me a general overview of your state of health so that we can be sure there is no risk to the treatment plan I create for you. Once I have gone over your treatment plan, we will have a short discussion about what it is you want me to treat. I try not to take up more than a few minutes with this stage but it is important for me to have a clear picture of what we will be working on before we get started. I commonly ask questions like:

* where does it hurt?
* what does the pain feel like?
* what sort of things aggravate the injury?
* was there and accident to create the injury?

&nbsp;

Sometimes I will want to have a closer look at your posture (the way you stand) or maybe I will want to do some range of motion testing. These tests will allow me to zone in on the source of your problem. Often, I don’t want to do any of these tests; I find I can get the same information while you are on the table by making the testing and treating procedure one and the same.

After I get a general idea of what it is I’m going to work on, it’s time to get started. While I go wash my hands, it’s your chance to get ready for your treatment. You always have the final say regarding how you get ready and what clothes you are comfortable taking off.

Most of my clients are comfortable removing all their clothing but their underpants knowing that I will always make sure they are covered discreetly with a sheet. I only expose one part of your body at a time, and only the specific body part I will be working on.

During your treatment, I will be using an assortment of massage techniques. Some of these can be relaxing and others can be <a href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">kind of tender</a>. In most cases, <a href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">a little pain is necessary </a>to get the results you are looking for from a massage therapy treatment.

It’s important that you be able to rate your discomfort on a scale of 1 to 10, where 10 is the most pain you’ve ever experienced. A discomfort level of 7 or under can be appropriate depending on the injury or need, but any more than that won’t bring you healing benefits. If, at any time during your treatment, your discomfort level becomes intolerable, please speak up. You may find that some areas of the body are more sensitive than others, or that your sensitivity changes day to day. Feel free to let me know how you’re doing. It’s entirely okay to ask me to adjust my pressure and technique at any time during your treatment.

During your massage treatment, I will try to spark up a conversation. Not only does this allow us to become better acquainted, but I also find that a light conversation helps distract you from when I find a sore spot like a <a href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\">Trigger Point </a>or Scar Tissue. This distraction technique allows you to stay relaxed, helps keep your muscles from pushing back against me working, and reduces pain overall. I often try to direct conversation to subjects that might give me clues or hints about what is creating your pain or discomfort. Topics like your work, the kind of car you drive, or sports or athletics you are involved often give me lots of information about you posture, repetitive movements you often do, or strength or flexibility issues.

When your treatment is complete, I will let you know, then go wash my hands again (I do this a lot). This gives you time to get up, get dressed, and come out to see me. If, during your treatment, we discussed any exercises, stretches, or heat/cold treatments for you do at home, this is when I will go over that in more detail.

After the massage treatment, it is also time to handle the payment and rebooking. I don’t have credit or debit machines so cash payment is necessary.

If you have extended health care benefits, on my receipt you will find my <a href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">registration number as a registered massage therapist</a>.  When you send your receipt to your health care company for reimbursement, this registration is what they need for approval.
<div></div>","Note to New Massage Clients","","inherit","open","open","","224-revision-v1","","","2014-01-13 14:56:16","2014-01-13 14:56:16","","224","http://www.kwmassage.com/generalmassagetherapy/224-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("233","3","2014-01-13 14:56:34","2014-01-13 14:56:34","When you come in for your first <a href=\"http://www.kwmassage.com/clinic-information\">massage therapy appointment </a>at <a href=\"http://www.kwmassage.com/\">KW massage </a>with me, a few things need to be done in preparation for your <a href=\"http://www.kwmassage.com/\">massage therapy treatment</a>.

First, I do not charge an initial consultation fee. What you pay depends on the length of treatment you request when you book the appointment. I do not charge any additional fees.

I have a <a href=\"http://www.kwmassage.com/wp-content/uploads/2011/06/Health-History.pdf\">health history form </a>that you need to fill out before we get started. Try to come about 10 minutes early to fill out this form. Or, you can also print it out and complete it ahead of time. Just be sure to bring it with you on the day of your first appointment.

This health history form  gives me a general overview of your state of health so that we can be sure there is no risk to the treatment plan I create for you. Once I have gone over your treatment plan, we will have a short discussion about what it is you want me to treat. I try not to take up more than a few minutes with this stage but it is important for me to have a clear picture of what we will be working on before we get started. I commonly ask questions like:

* where does it hurt?
* what does the pain feel like?
* what sort of things aggravate the injury?
* was there and accident to create the injury?

</br>

Sometimes I will want to have a closer look at your posture (the way you stand) or maybe I will want to do some range of motion testing. These tests will allow me to zone in on the source of your problem. Often, I don’t want to do any of these tests; I find I can get the same information while you are on the table by making the testing and treating procedure one and the same.

After I get a general idea of what it is I’m going to work on, it’s time to get started. While I go wash my hands, it’s your chance to get ready for your treatment. You always have the final say regarding how you get ready and what clothes you are comfortable taking off.

Most of my clients are comfortable removing all their clothing but their underpants knowing that I will always make sure they are covered discreetly with a sheet. I only expose one part of your body at a time, and only the specific body part I will be working on.

During your treatment, I will be using an assortment of massage techniques. Some of these can be relaxing and others can be <a href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">kind of tender</a>. In most cases, <a href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">a little pain is necessary </a>to get the results you are looking for from a massage therapy treatment.

It’s important that you be able to rate your discomfort on a scale of 1 to 10, where 10 is the most pain you’ve ever experienced. A discomfort level of 7 or under can be appropriate depending on the injury or need, but any more than that won’t bring you healing benefits. If, at any time during your treatment, your discomfort level becomes intolerable, please speak up. You may find that some areas of the body are more sensitive than others, or that your sensitivity changes day to day. Feel free to let me know how you’re doing. It’s entirely okay to ask me to adjust my pressure and technique at any time during your treatment.

During your massage treatment, I will try to spark up a conversation. Not only does this allow us to become better acquainted, but I also find that a light conversation helps distract you from when I find a sore spot like a <a href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\">Trigger Point </a>or Scar Tissue. This distraction technique allows you to stay relaxed, helps keep your muscles from pushing back against me working, and reduces pain overall. I often try to direct conversation to subjects that might give me clues or hints about what is creating your pain or discomfort. Topics like your work, the kind of car you drive, or sports or athletics you are involved often give me lots of information about you posture, repetitive movements you often do, or strength or flexibility issues.

When your treatment is complete, I will let you know, then go wash my hands again (I do this a lot). This gives you time to get up, get dressed, and come out to see me. If, during your treatment, we discussed any exercises, stretches, or heat/cold treatments for you do at home, this is when I will go over that in more detail.

After the massage treatment, it is also time to handle the payment and rebooking. I don’t have credit or debit machines so cash payment is necessary.

If you have extended health care benefits, on my receipt you will find my <a href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">registration number as a registered massage therapist</a>.  When you send your receipt to your health care company for reimbursement, this registration is what they need for approval.
<div></div>","Note to New Massage Clients","","inherit","open","open","","224-revision-v1","","","2014-01-13 14:56:34","2014-01-13 14:56:34","","224","http://www.kwmassage.com/generalmassagetherapy/224-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("234","3","2014-01-13 16:19:45","2014-01-13 16:19:45","To save time the day of your first massage appointment please print and complete this form.","Health History Form","Health History Form","inherit","open","open","","health-history","","","2014-01-13 16:19:45","2014-01-13 16:19:45","","0","http://www.kwmassage.com/wp-content/uploads/2014/01/Health-History.pdf","0","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("235","3","2014-01-13 16:22:03","2014-01-13 16:22:03","When you come in for your first <a href=\"http://www.kwmassage.com/clinic-information\">massage therapy appointment </a>at <a href=\"http://www.kwmassage.com/\">KW massage </a>with me, a few things need to be done in preparation for your <a href=\"http://www.kwmassage.com/\">massage therapy treatment</a>.

First, I do not charge an initial consultation fee. What you pay depends on the length of treatment you request when you book the appointment. I do not charge any additional fees.

I have a <a href=\"http://www.kwmassage.com/wp-content/uploads/2014/01/Health-History.pdf\">health history form </a>that you need to fill out before we get started. Try to come about 10 minutes early to fill out this form. Or, you can also print it out and complete it ahead of time. Just be sure to bring it with you on the day of your first appointment.

This health history form  gives me a general overview of your state of health so that we can be sure there is no risk to the treatment plan I create for you. Once I have gone over your treatment plan, we will have a short discussion about what it is you want me to treat. I try not to take up more than a few minutes with this stage but it is important for me to have a clear picture of what we will be working on before we get started. I commonly ask questions like:

* where does it hurt?
* what does the pain feel like?
* what sort of things aggravate the injury?
* was there and accident to create the injury?

Sometimes I will want to have a closer look at your posture (the way you stand) or maybe I will want to do some range of motion testing. These tests will allow me to zone in on the source of your problem. Often, I don’t want to do any of these tests; I find I can get the same information while you are on the table by making the testing and treating procedure one and the same.

After I get a general idea of what it is I’m going to work on, it’s time to get started. While I go wash my hands, it’s your chance to get ready for your treatment. You always have the final say regarding how you get ready and what clothes you are comfortable taking off.

Most of my clients are comfortable removing all their clothing but their underpants knowing that I will always make sure they are covered discreetly with a sheet. I only expose one part of your body at a time, and only the specific body part I will be working on.

During your treatment, I will be using an assortment of massage techniques. Some of these can be relaxing and others can be <a href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">kind of tender</a>. In most cases, <a href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">a little pain is necessary </a>to get the results you are looking for from a massage therapy treatment.

It’s important that you be able to rate your discomfort on a scale of 1 to 10, where 10 is the most pain you’ve ever experienced. A discomfort level of 7 or under can be appropriate depending on the injury or need, but any more than that won’t bring you healing benefits. If, at any time during your treatment, your discomfort level becomes intolerable, please speak up. You may find that some areas of the body are more sensitive than others, or that your sensitivity changes day to day. Feel free to let me know how you’re doing. It’s entirely okay to ask me to adjust my pressure and technique at any time during your treatment.

During your massage treatment, I will try to spark up a conversation. Not only does this allow us to become better acquainted, but I also find that a light conversation helps distract you from when I find a sore spot like a <a href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\">Trigger Point </a>or Scar Tissue. This distraction technique allows you to stay relaxed, helps keep your muscles from pushing back against me working, and reduces pain overall. I often try to direct conversation to subjects that might give me clues or hints about what is creating your pain or discomfort. Topics like your work, the kind of car you drive, or sports or athletics you are involved often give me lots of information about you posture, repetitive movements you often do, or strength or flexibility issues.

When your treatment is complete, I will let you know, then go wash my hands again (I do this a lot). This gives you time to get up, get dressed, and come out to see me. If, during your treatment, we discussed any exercises, stretches, or heat/cold treatments for you do at home, this is when I will go over that in more detail.

After the massage treatment, it is also time to handle the payment and rebooking. I don’t have credit or debit machines so cash payment is necessary.

If you have extended health care benefits, on my receipt you will find my <a href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">registration number as a registered massage therapist</a>.  When you send your receipt to your health care company for reimbursement, this registration is what they need for approval.
<div></div>","Note to New Massage Clients","","inherit","open","open","","224-revision-v1","","","2014-01-13 16:22:03","2014-01-13 16:22:03","","224","http://www.kwmassage.com/generalmassagetherapy/224-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("236","3","2014-01-13 16:26:57","2014-01-13 16:26:57","When you come in for your first <a href=\"http://www.kwmassage.com/clinic-information\">massage therapy appointment </a>at <a href=\"http://www.kwmassage.com/\">KW massage </a>with me, a few things need to be done in preparation for your <a href=\"http://www.kwmassage.com/\">massage therapy treatment</a>.

First, I do not charge an initial consultation fee. What you pay depends on the length of treatment you request when you book the appointment. I do not charge any additional fees.

I have a <a href=\"http://www.kwmassage.com/wp-content/uploads/2014/01/Health-History.pdf\">health history form </a>that you need to fill out before we get started. Try to come about 10 minutes early to fill out this form. Or, you can also print it out and complete it ahead of time. Just be sure to bring it with you on the day of your first appointment.

This health history form  gives me a general overview of your state of health so that we can be sure there is no risk to the treatment plan I create for you. Once I have gone over your treatment plan, we will have a short discussion about what it is you want me to treat. I try not to take up more than a few minutes with this stage but it is important for me to have a clear picture of what we will be working on before we get started. I commonly ask questions like:
<ul>
	<li>where does it hurt?</li>
	<li>what does the pain feel like?</li>
	<li>what sort of things aggravate the injury?</li>
	<li>was there and accident to create the injury?</li>
</ul>
Sometimes I will want to have a closer look at your posture (the way you stand) or maybe I will want to do some range of motion testing. These tests will allow me to zone in on the source of your problem. Often, I don’t want to do any of these tests; I find I can get the same information while you are on the table by making the testing and treating procedure one and the same.

After I get a general idea of what it is I’m going to work on, it’s time to get started. While I go wash my hands, it’s your chance to get ready for your treatment. You always have the final say regarding how you get ready and what clothes you are comfortable taking off.

Most of my clients are comfortable removing all their clothing but their underpants knowing that I will always make sure they are covered discreetly with a sheet. I only expose one part of your body at a time, and only the specific body part I will be working on.

During your treatment, I will be using an assortment of massage techniques. Some of these can be relaxing and others can be <a href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">kind of tender</a>. In most cases, <a href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">a little pain is necessary </a>to get the results you are looking for from a massage therapy treatment.

It’s important that you be able to rate your discomfort on a scale of 1 to 10, where 10 is the most pain you’ve ever experienced. A discomfort level of 7 or under can be appropriate depending on the injury or need, but any more than that won’t bring you healing benefits. If, at any time during your treatment, your discomfort level becomes intolerable, please speak up. You may find that some areas of the body are more sensitive than others, or that your sensitivity changes day to day. Feel free to let me know how you’re doing. It’s entirely okay to ask me to adjust my pressure and technique at any time during your treatment.

During your massage treatment, I will try to spark up a conversation. Not only does this allow us to become better acquainted, but I also find that a light conversation helps distract you from when I find a sore spot like a <a href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\">Trigger Point </a>or Scar Tissue. This distraction technique allows you to stay relaxed, helps keep your muscles from pushing back against me working, and reduces pain overall. I often try to direct conversation to subjects that might give me clues or hints about what is creating your pain or discomfort. Topics like your work, the kind of car you drive, or sports or athletics you are involved often give me lots of information about you posture, repetitive movements you often do, or strength or flexibility issues.

When your treatment is complete, I will let you know, then go wash my hands again (I do this a lot). This gives you time to get up, get dressed, and come out to see me. If, during your treatment, we discussed any exercises, stretches, or heat/cold treatments for you do at home, this is when I will go over that in more detail.

After the massage treatment, it is also time to handle the payment and rebooking. I don’t have credit or debit machines so cash payment is necessary.

If you have extended health care benefits, on my receipt you will find my <a href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">registration number as a registered massage therapist</a>.  When you send your receipt to your health care company for reimbursement, this registration is what they need for approval.
<div></div>","Note to New Massage Therapy Clients ","","inherit","open","open","","221-revision-v1","","","2014-01-13 16:26:57","2014-01-13 16:26:57","","221","http://www.kwmassage.com/generalmassagetherapy/221-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("238","3","2014-01-13 17:45:32","2014-01-13 17:45:32","Trigger Point reference chart used by registered massage therapists.","trigger_point_chart","","inherit","open","open","","trigger_point_chart","","","2014-01-13 17:45:32","2014-01-13 17:45:32","","219","http://www.kwmassage.com/wp-content/uploads/2014/01/trigger_point_chart.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("239","3","2014-01-13 17:46:05","2014-01-13 17:46:05","<a href=\"http://www.kwmassage.com/about\">After studying and treating Trigger Points for many years, </a>I describe them to my clients as a part of muscle that has become hyper-sensitive and irritable. Trigger Points are found in a tight or stiff band of muscle, and they can be found in muscles throughout the body. The following video shows me describing a Trigger Point to a client:

<iframe src=\"//www.youtube.com/embed/shGC3k2tlb0?rel=0\" height=\"315\" width=\"560\" allowfullscreen=\"\" frameborder=\"0\"></iframe>

Trigger Points are sensitive to touch and they usually have a pattern of pain that presents in another part of the body. Sometimes where you hurt is not necessarily where the problem needs to be treated. The Trigger Point Chart below shows you how this referral pain travels. A Trigger Point in the Lower Trapezius muscle (represented as an X in the pink area) can show up as pain at the base of the skull because a Trigger Point in that one muscle can affect a significant area. It is very common to have pain referred from one part of your body to another, and I use Trigger Point Charts in my office to locate, connect, and treat pain on a regular basis.

&nbsp;

Over time, trigger points can create a chronic shortening of affected muscle, and trigger points are often responsible for many chronic pain syndromes such as torticollis, <a href=\"http://www.kwmassage.com/generalmassagetherapy/tension-headaches-3\">headaches</a>, <a href=\"http://www.kwmassage.com/stretching/low-back-pain\">back pain</a>, knee pain, and postural stress.

At<a href=\"http://www.kwmassage.com/\"> Kitchener Massage Therapy </a>I use a few different <a href=\"http://www.kwmassage.com/generalmassagetherapy/what-is-deep-tissue-massage\">Deep Tissue Massage </a>techniques like muscle stripping, direct pressure held for up to a minute, and<a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\"> stretching</a>to treat Trigger Points.

<a href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">It is uncomfortable to have a Trigger Point worked out </a>but the relief you get from the <a href=\"http://www.kwmassage.com/generalmassagetherapy/tension-headaches-3\">headache</a>, <a href=\"http://www.kwmassage.com/stretching/low-back-pain\">sore back </a>or <a href=\"http://www.kwmassage.com/generalmassagetherapy/what-can-deep-tissue-massage-treat\">whatever it is you are experiencing</a> can be great. My clients often describe the pain from Trigger Point work as a good pain . I think this stems from the fact that someone has finally been able to pinpoint and address the source of their discomfort after what could have been many years.","Trigger Points and Trigger Point Therapy ","","inherit","open","open","","219-autosave-v1","","","2014-01-13 17:46:05","2014-01-13 17:46:05","","219","http://www.kwmassage.com/generalmassagetherapy/219-autosave-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("240","3","2014-01-13 17:47:58","2014-01-13 17:47:58","<a href=\"http://www.kwmassage.com/about\">After studying and treating Trigger Points for many years, </a>I describe them to my clients as a part of muscle that has become hyper-sensitive and irritable. Trigger Points are found in a tight or stiff band of muscle, and they can be found in muscles throughout the body. The following video shows me describing a Trigger Point to a client:

<iframe src=\"//www.youtube.com/embed/shGC3k2tlb0?rel=0\" height=\"315\" width=\"560\" allowfullscreen=\"\" frameborder=\"0\"></iframe>

Trigger Points are sensitive to touch and they usually have a pattern of pain that presents in another part of the body. Sometimes where you hurt is not necessarily where the problem needs to be treated. The Trigger Point Chart below shows you how this referral pain travels. A Trigger Point in the Lower Trapezius muscle (represented as an X in the pink area) can show up as pain at the base of the skull because a Trigger Point in that one muscle can affect a significant area. It is very common to have pain referred from one part of your body to another, and I use Trigger Point Charts in my office to locate, connect, and treat pain on a regular basis.

<a href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy/attachment/trigger_point_chart\" rel=\"attachment wp-att-238\"><img class=\"alignleft size-medium wp-image-238\" alt=\"trigger_point_chart\" src=\"http://www.kwmassage.com/wp-content/uploads/2014/01/trigger_point_chart-300x247.jpg\" width=\"300\" height=\"247\" /></a>

Over time, trigger points can create a chronic shortening of affected muscle, and trigger points are often responsible for many chronic pain syndromes such as torticollis, <a href=\"http://www.kwmassage.com/generalmassagetherapy/tension-headaches-3\">headaches</a>, <a href=\"http://www.kwmassage.com/stretching/low-back-pain\">back pain</a>, knee pain, and postural stress.

At<a href=\"http://www.kwmassage.com/\"> Kitchener Massage Therapy </a>I use a few different <a href=\"http://www.kwmassage.com/generalmassagetherapy/what-is-deep-tissue-massage\">Deep Tissue Massage </a>techniques like muscle stripping, direct pressure held for up to a minute, and<a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\"> stretching</a>to treat Trigger Points.

<a href=\"http://www.kwmassage.com/generalmassagetherapy/does-deep-tissue-massage-heart\">It is uncomfortable to have a Trigger Point worked out </a>but the relief you get from the <a href=\"http://www.kwmassage.com/generalmassagetherapy/tension-headaches-3\">headache</a>, <a href=\"http://www.kwmassage.com/stretching/low-back-pain\">sore back </a>or <a href=\"http://www.kwmassage.com/generalmassagetherapy/what-can-deep-tissue-massage-treat\">whatever it is you are experiencing</a> can be great. My clients often describe the pain from Trigger Point work as a good pain . I think this stems from the fact that someone has finally been able to pinpoint and address the source of their discomfort after what could have been many years.","Trigger Points and Trigger Point Therapy ","","inherit","open","open","","219-revision-v1","","","2014-01-13 17:47:58","2014-01-13 17:47:58","","219","http://www.kwmassage.com/generalmassagetherapy/219-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("241","3","2014-01-13 19:30:52","2014-01-13 19:30:52","To <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">stretch</a> your <a href=\"http://www.kwmassage.com/generalmassagetherapy/tension-headaches-3\">Upper Trapezius Muscle, </a>begin in a seated position.

With your shoulders relaxed and your head in a natural position, carefully bend your neck to bring your right ear toward your right armpit. If more pressure is needed to feel the <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">stretch</a>, you can use your right hand to gently pull from the side of your head just above your left ear toward your right armpit.

Be sure not to allow your left shoulder to rise, as this will prevent the muscle from lengthening into a stretched position. Repeat on the other side.

Be sure to review to my <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">General Guidelines for stretching </a>before doing any of the stretches I demonstrate and recommend. It’s always a good idea to see a <a href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">health care professional </a>before starting a new exercise program.","Stretch Your Upper Trapezius Muscle ","","trash","open","open","","stretch-your-upper-trapezius-muscle","","","2014-01-13 19:31:39","2014-01-13 19:31:39","","0","http://www.kwmassage.com/?p=241","0","post","","0");
INSERT INTO `wp_posts` VALUES("242","3","2014-01-13 19:31:29","0000-00-00 00:00:00","","Auto Draft","","auto-draft","open","open","","","","","2014-01-13 19:31:29","0000-00-00 00:00:00","","0","http://www.kwmassage.com/?p=242","0","post","","0");
INSERT INTO `wp_posts` VALUES("243","3","2014-01-13 19:31:39","2014-01-13 19:31:39","To <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">stretch</a> your <a href=\"http://www.kwmassage.com/generalmassagetherapy/tension-headaches-3\">Upper Trapezius Muscle, </a>begin in a seated position.

With your shoulders relaxed and your head in a natural position, carefully bend your neck to bring your right ear toward your right armpit. If more pressure is needed to feel the <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">stretch</a>, you can use your right hand to gently pull from the side of your head just above your left ear toward your right armpit.

Be sure not to allow your left shoulder to rise, as this will prevent the muscle from lengthening into a stretched position. Repeat on the other side.

Be sure to review to my <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">General Guidelines for stretching </a>before doing any of the stretches I demonstrate and recommend. It’s always a good idea to see a <a href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">health care professional </a>before starting a new exercise program.","Stretch Your Upper Trapezius Muscle ","","inherit","open","open","","241-revision-v1","","","2014-01-13 19:31:39","2014-01-13 19:31:39","","241","http://www.kwmassage.com/generalmassagetherapy/241-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("244","3","2014-01-13 19:32:17","2014-01-13 19:32:17","<a href=\"http://www.kwmassage.com/wp-content/uploads/2014/01/up-trap-stretch-picture.jpg\"><img class=\"alignleft size-full wp-image-247\" alt=\"Stretch Upper Trap\" src=\"http://www.kwmassage.com/wp-content/uploads/2014/01/up-trap-stretch-picture.jpg\" width=\"195\" height=\"151\" /></a>To <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">stretch</a> your <a href=\"http://www.kwmassage.com/generalmassagetherapy/tension-headaches-3\">Upper Trapezius Muscle, </a>begin in a seated position.

With your shoulders relaxed and your head in a natural position, carefully bend your neck to bring your right ear toward your right armpit. If more pressure is needed to feel the <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">stretch</a>, you can use your right hand to gently pull from the side of your head just above your left ear toward your right armpit.

Be sure not to allow your left shoulder to rise, as this will prevent the muscle from lengthening into a stretched position. Repeat on the other side.

Be sure to review to my <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">General Guidelines for stretching </a>before doing any of the stretches I demonstrate and recommend. It’s always a good idea to see a <a href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">health care professional </a>before starting a new exercise program.","Stretch Your Upper Trapezius Muscle ","","publish","open","open","","stretch-your-upper-trapezius-muscle-2","","","2014-01-13 19:36:07","2014-01-13 19:36:07","","0","http://www.kwmassage.com/?p=244","0","post","","0");
INSERT INTO `wp_posts` VALUES("245","3","2014-01-13 19:32:17","2014-01-13 19:32:17","To <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">stretch</a> your <a href=\"http://www.kwmassage.com/generalmassagetherapy/tension-headaches-3\">Upper Trapezius Muscle, </a>begin in a seated position.

With your shoulders relaxed and your head in a natural position, carefully bend your neck to bring your right ear toward your right armpit. If more pressure is needed to feel the <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">stretch</a>, you can use your right hand to gently pull from the side of your head just above your left ear toward your right armpit.

Be sure not to allow your left shoulder to rise, as this will prevent the muscle from lengthening into a stretched position. Repeat on the other side.

Be sure to review to my <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">General Guidelines for stretching </a>before doing any of the stretches I demonstrate and recommend. It’s always a good idea to see a <a href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">health care professional </a>before starting a new exercise program.","Stretch Your Upper Trapezius Muscle ","","inherit","open","open","","244-revision-v1","","","2014-01-13 19:32:17","2014-01-13 19:32:17","","244","http://www.kwmassage.com/generalmassagetherapy/244-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("246","3","2014-01-13 19:35:25","2014-01-13 19:35:25","","levator stretch pic","","inherit","open","open","","levator-stretch-pic","","","2014-01-13 19:35:25","2014-01-13 19:35:25","","244","http://www.kwmassage.com/wp-content/uploads/2014/01/levator-stretch-pic.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("247","3","2014-01-13 19:35:26","2014-01-13 19:35:26","","up trap stretch picture","","inherit","open","open","","up-trap-stretch-picture","","","2014-01-13 19:35:26","2014-01-13 19:35:26","","244","http://www.kwmassage.com/wp-content/uploads/2014/01/up-trap-stretch-picture.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("248","3","2014-01-13 19:36:07","2014-01-13 19:36:07","<a href=\"http://www.kwmassage.com/wp-content/uploads/2014/01/up-trap-stretch-picture.jpg\"><img class=\"alignleft size-full wp-image-247\" alt=\"Stretch Upper Trap\" src=\"http://www.kwmassage.com/wp-content/uploads/2014/01/up-trap-stretch-picture.jpg\" width=\"195\" height=\"151\" /></a>To <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">stretch</a> your <a href=\"http://www.kwmassage.com/generalmassagetherapy/tension-headaches-3\">Upper Trapezius Muscle, </a>begin in a seated position.

With your shoulders relaxed and your head in a natural position, carefully bend your neck to bring your right ear toward your right armpit. If more pressure is needed to feel the <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">stretch</a>, you can use your right hand to gently pull from the side of your head just above your left ear toward your right armpit.

Be sure not to allow your left shoulder to rise, as this will prevent the muscle from lengthening into a stretched position. Repeat on the other side.

Be sure to review to my <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">General Guidelines for stretching </a>before doing any of the stretches I demonstrate and recommend. It’s always a good idea to see a <a href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">health care professional </a>before starting a new exercise program.","Stretch Your Upper Trapezius Muscle ","","inherit","open","open","","244-revision-v1","","","2014-01-13 19:36:07","2014-01-13 19:36:07","","244","http://www.kwmassage.com/generalmassagetherapy/244-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("249","3","2014-01-13 19:41:08","2014-01-13 19:41:08","Stretching your muscles can be very benificial and a great way to incurage the results your massage therapist worked so hard for. But you need to be careful not to injure yourself while stretching. Follow these 5 principles of stretching to reduce the risks of injury.
<ol>
	<li>1. Stretch only to the point where you feel tightness or resistance to the stretch or perhaps some discomfort. Stretching should never be painful.</li>
	<li>2. Always stretch slowly and with control.</li>
	<li>3. Hold stretches for at least 30 seconds, and repeat each stretch 3 times.</li>
	<li>4. Be sure to breathe normally during a stretch. Do not hold your breath.</li>
	<li>5. Be sure to warm your muscles before stretching. You can warm your muscles by exercising lightly, by taking a warm bath or shower, or by applying heat.</li>
</ol>","General Guidelines for Stretching","","publish","open","open","","general-guidelines-for-stretching","","","2014-01-13 19:41:08","2014-01-13 19:41:08","","0","http://www.kwmassage.com/?p=249","0","post","","0");
INSERT INTO `wp_posts` VALUES("250","3","2014-01-13 19:41:08","2014-01-13 19:41:08","Stretching your muscles can be very benificial and a great way to incurage the results your massage therapist worked so hard for. But you need to be careful not to injure yourself while stretching. Follow these 5 principles of stretching to reduce the risks of injury.
<ol>
	<li>1. Stretch only to the point where you feel tightness or resistance to the stretch or perhaps some discomfort. Stretching should never be painful.</li>
	<li>2. Always stretch slowly and with control.</li>
	<li>3. Hold stretches for at least 30 seconds, and repeat each stretch 3 times.</li>
	<li>4. Be sure to breathe normally during a stretch. Do not hold your breath.</li>
	<li>5. Be sure to warm your muscles before stretching. You can warm your muscles by exercising lightly, by taking a warm bath or shower, or by applying heat.</li>
</ol>","General Guidelines for Stretching","","inherit","open","open","","249-revision-v1","","","2014-01-13 19:41:08","2014-01-13 19:41:08","","249","http://www.kwmassage.com/generalmassagetherapy/249-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("251","3","2014-01-13 19:48:16","2014-01-13 19:48:16","Massage therapy is a <a href=\"http://www.kwmassage.com/knowledge-centre/facts-about-registered-massage-therapy-in-ontario\">regulated health profession</a>. The <a href=\"http://www.cmto.com/\">College of Massage Therapist of Ontario </a>(CMTO) is the governing board that oversees and regulates <a href=\"http://www.kwmassage.com/\">massage therapists in Ontario</a>. If you have any questions related to the governance of massage therapy in Ontario, <a href=\"http://www.cmto.com/\">http://www.cmto.com/</a> is a great resource.

The <a href=\"http://www.rmtao.com/\">Registered Massage Therapists’ Association of Ontario</a>(RMTAO) is the association that supports massage therapists in Ontario. They lobby the government on behalf of all massage therapists in Ontario. They are the association that fought to get massage therapy into the Regulated Health Professionals Act (RHPA). Massage therapy being part of the RHPA is what allows you to have <a href=\"http://www.kwmassage.com/generalmassagetherapy/facts-about-registered-massage-therapy-in-ontario\">massage therapy coverage </a>in your extended health benefits plan. The RMTAO did their best to avoid the new <a href=\"http://www.kwmassage.com/generalmassagetherapy/registered-massage-therapy-and-hst\">Harmonized Sales Tax </a>(HST) from affecting the rate of massage therapy in Ontario. The <span style=\"text-decoration: underline;\">RMTAO</span> is a great education resource.

The RMTAO also has a sister website <a href=\"http://www.rmtfind.com/\">RMTfind.com</a> that will allow you to search by <a href=\"http://www.kwmassage.com/contact\">location for a massage therapist </a>in your area.","Governance of massage therapy ","","publish","open","open","","governance-of-massage-therapy","","http://www.kwmassage.com/contact
http://www.kwmassage.com/knowledge-centre/facts-about-registered-massage-therapy-in-ontario","2014-01-13 20:08:38","2014-01-13 20:08:38","","0","http://www.kwmassage.com/?p=251","0","post","","0");
INSERT INTO `wp_posts` VALUES("252","3","2014-01-13 19:48:16","2014-01-13 19:48:16","Massage therapy is a <a href=\"http://www.kwmassage.com/generalmassagetherapy/facts-about-registered-massage-therapy-in-ontario\">regulated health profession</a>. The <a href=\"http://www.cmto.com/\">College of Massage Therapist of Ontario </a>(CMTO) is the governing board that oversees and regulates <a href=\"http://www.kwmassage.com/\">massage therapists in Ontario</a>. If you have any questions related to the governance of massage therapy in Ontario, <a href=\"http://www.cmto.com/\">http://www.cmto.com/</a> is a great resource.

The <a href=\"http://www.rmtao.com/\">Registered Massage Therapists’ Association of Ontario</a>(RMTAO) is the association that supports massage therapists in Ontario. They lobby the government on behalf of all massage therapists in Ontario. They are the association that fought to get massage therapy into the Regulated Health Professionals Act (RHPA). Massage therapy being part of the RHPA is what allows you to have <a href=\"http://www.kwmassage.com/generalmassagetherapy/facts-about-registered-massage-therapy-in-ontario\">massage therapy coverage </a>in your extended health benefits plan. The RMTAO did their best to avoid the new <a href=\"http://www.kwmassage.com/generalmassagetherapy/registered-massage-therapy-and-hst\">Harmonized Sales Tax </a>(HST) from affecting the rate of massage therapy in Ontario. The <span style=\"text-decoration: underline;\">RMTAO</span> is a great education resource.

The RMTAO also has a sister website <a href=\"http://www.rmtfind.com/\">RMTfind.com</a> that will allow you to search by <a href=\"http://www.kwmassage.com/contact\">location for a massage therapist </a>in your area.","Governance of massage therapy ","","inherit","open","open","","251-revision-v1","","","2014-01-13 19:48:16","2014-01-13 19:48:16","","251","http://www.kwmassage.com/generalmassagetherapy/251-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("253","3","2014-01-13 19:49:41","2014-01-13 19:49:41","Your headache can leave you feeling helpless. You might be surprised to learn that there are things we can do to improve or prevent the crippling pain of a headache without the use of Tylenol, Advil, or other pain controlling medications.  Regular <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">stretching</a>, exercise, and <a href=\"http://www.kwmassage.com/\">massage therapy </a>can bring so much relief you would wonder why you never tried these simple ideas before.

The most common cause for your headache is Referral Pain from muscle tension in your neck and shoulders. Overuse of vulnerable muscles can cause large painful knots in your muscles called<a title=\"Trigger Points and Trigger Point Therapy\" href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\"> Trigger Points</a>. The pain created by Trigger Points is not always located in the area of the Trigger Point itself. Referred pain from the muscles in your neck and shoulders is often called a tension headache.

To reduce your tension headache, you need to relax the <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">affected muscles </a>and reduce these Trigger Points. Three ways for you to do this are to:

* Relax the muscle through the application of heat
* Stretch the effected muscle
* Massage therapy

I have detailed a few general neck stretches and exercises below. These stretches target muscles that commonly cause a tension headache. Gentle massage from a loved one can be very beneficial but could potentially cause irritation to the Trigger Point. <a href=\"http://www.kwmassage.com/about\">A registered massage therapist </a>is highly skilled in Trigger Point release.

Be sure to review to my <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">General Guidelines for stretching </a>before doing any of the stretches I demonstrate and recommend. It’s always a good idea to see a <a href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">health care professional </a>before starting a new exercise program.

<b>Muscle #1: Upper Trapezius</b>

The <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">Upper Trapezius </a>is a flat triangular muscle that runs from the base of your skull and neck to your shoulder. The <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">Upper Trapezius </a>elevates the shoulder and supports the shoulder girdle when lifting a load. An Upper Trapezius muscle Trigger Point will commonly create pain around the ear and into the temple. Find directions on how to stretch the upper trapezius muscle <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">here</a>.

<b>Muscle #2: Levator Scapula</b>

The <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">Levator Scapula </a>muscle runs from the top tip of the shoulder blade up to the top four joints of the neck. The <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">Levator Scapula </a>lifts the shoulder blade and helps control side-to-side movement of the head. A Trigger Point in the Levator Scapula muscle can cause pain behind the head and to the back of the neck. Find directions to stretch the Levator Scapula <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">here</a>.

<b>Muscle #3: Sub-Occipital Muscles</b>

Your sub-occipital muscles are a group of small muscles below the base of your skull at the back of your neck. These muscles control fine movements of your head. Trigger Points in this group of muscles will refer pain into your forehead and behind your eyes.

Due to the complexity of movements required to stretch the sub-occipital muscles I’m going to suggest gentle self-massage at the space between your neck and the base of your skull.
<div></div>","Tension Headaches","","publish","open","open","","tension-headaches-3","","http://www.kwmassage.com/stretching/general-guidelines-for-stretching
http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy
http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy","2014-01-13 20:24:07","2014-01-13 20:24:07","","0","http://www.kwmassage.com/?p=253","0","post","","0");
INSERT INTO `wp_posts` VALUES("254","3","2014-01-13 19:49:41","2014-01-13 19:49:41","Your headache can leave you feeling helpless. You might be surprised to learn that there are things we can do to improve or prevent the crippling pain of a headache without the use of Tylenol, Advil, or other pain controlling medications.  Regular <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">stretching</a>, exercise, and <a href=\"http://www.kwmassage.com/\">massage therapy </a>can bring so much relief you would wonder why you never tried these simple ideas before.

The most common cause for your headache is Referral Pain from muscle tension in your neck and shoulders. Overuse of vulnerable muscles can cause large painful knots in your muscles called Trigger Points<a href=\"file:///C:/Users/KWmassage/Documents/JeremyBissonnetteWebsiteReview-progression.docx#_msocom_1\">[C1]</a> . The pain created by Trigger Points is not always located in the area of the Trigger Point itself. Referred pain from the muscles in your neck and shoulders is often called a tension headache.

To reduce your tension headache, you need to relax the <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">affected muscles </a>and reduce these Trigger Points. Three ways for you to do this are to:
<ul>
	<li>relax the muscle through the <a href=\"http://www.kwmassage.com/generalmassagetherapy/epsom-salt-bath\">application of heat</a></li>
	<li>stretch the effected muscle</li>
	<li>massage therapy</li>
</ul>
I have detailed a few general neck stretches and exercises below. These stretches target muscles that commonly cause a tension headache. Gentle massage from a loved one can be very beneficial but could potentially cause irritation to the Trigger Point. <a href=\"http://www.kwmassage.com/about\">A registered massage therapist </a>is highly skilled in Trigger Point release.

Be sure to review to my <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">General Guidelines for stretching </a>before doing any of the stretches I demonstrate and recommend. It’s always a good idea to see a <a href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">health care professional </a>before starting a new exercise program.

<b>Muscle #1: Upper Trapezius</b>

The <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">Upper Trapezius </a>is a flat triangular muscle that runs from the base of your skull and neck to your shoulder. The <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">Upper Trapezius </a>elevates the shoulder and supports the shoulder girdle when lifting a load. An Upper Trapezius muscle Trigger Point will commonly create pain around the ear and into the temple. Find directions on how to stretch the upper trapezius muscle <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">here</a>.

<b>Muscle #2: Levator Scapula</b>

The <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">Levator Scapula </a>muscle runs from the top tip of the shoulder blade up to the top four joints of the neck. The <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">Levator Scapula </a>lifts the shoulder blade and helps control side-to-side movement of the head. A Trigger Point in the Levator Scapula muscle can cause pain behind the head and to the back of the neck. Find directions to stretch the Levator Scapula <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">here</a>.

<b>Muscle #3: Sub-Occipital Muscles</b>

Your sub-occipital muscles are a group of small muscles below the base of your skull at the back of your neck. These muscles control fine movements of your head. Trigger Points in this group of muscles will refer pain into your forehead and behind your eyes.

Due to the complexity of movements required to stretch the sub-occipital muscles I’m going to suggest gentle self-massage at the space between your neck and the base of your skull.
<div>

<hr align=\"left\" size=\"1\" width=\"33%\" />

<div>
<div>

 <a href=\"file:///C:/Users/KWmassage/Documents/JeremyBissonnetteWebsiteReview-progression.docx#_msoanchor_1\">[C1]</a>a good place to include a link to the Trigger Point topic

</div>
</div>
</div>","Tension Headaches","","inherit","open","open","","253-revision-v1","","","2014-01-13 19:49:41","2014-01-13 19:49:41","","253","http://www.kwmassage.com/generalmassagetherapy/253-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("255","3","2014-01-13 19:52:08","2014-01-13 19:52:08","Your headache can leave you feeling helpless. You might be surprised to learn that there are things we can do to improve or prevent the crippling pain of a headache without the use of Tylenol, Advil, or other pain controlling medications.  Regular <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">stretching</a>, exercise, and <a href=\"http://www.kwmassage.com/\">massage therapy </a>can bring so much relief you would wonder why you never tried these simple ideas before.

The most common cause for your headache is Referral Pain from muscle tension in your neck and shoulders. Overuse of vulnerable muscles can cause large painful knots in your muscles called<a title=\"Trigger Points and Trigger Point Therapy\" href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\"> Trigger Points</a>. The pain created by Trigger Points is not always located in the area of the Trigger Point itself. Referred pain from the muscles in your neck and shoulders is often called a tension headache.

To reduce your tension headache, you need to relax the <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">affected muscles </a>and reduce these Trigger Points. Three ways for you to do this are to:
<ul>
	<li>relax the muscle through the <a href=\"http://www.kwmassage.com/generalmassagetherapy/epsom-salt-bath\">application of heat</a></li>
	<li>stretch the effected muscle</li>
	<li>massage therapy</li>
</ul>
I have detailed a few general neck stretches and exercises below. These stretches target muscles that commonly cause a tension headache. Gentle massage from a loved one can be very beneficial but could potentially cause irritation to the Trigger Point. <a href=\"http://www.kwmassage.com/about\">A registered massage therapist </a>is highly skilled in Trigger Point release.

Be sure to review to my <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">General Guidelines for stretching </a>before doing any of the stretches I demonstrate and recommend. It’s always a good idea to see a <a href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">health care professional </a>before starting a new exercise program.

<b>Muscle #1: Upper Trapezius</b>

The <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">Upper Trapezius </a>is a flat triangular muscle that runs from the base of your skull and neck to your shoulder. The <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">Upper Trapezius </a>elevates the shoulder and supports the shoulder girdle when lifting a load. An Upper Trapezius muscle Trigger Point will commonly create pain around the ear and into the temple. Find directions on how to stretch the upper trapezius muscle <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">here</a>.

<b>Muscle #2: Levator Scapula</b>

The <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">Levator Scapula </a>muscle runs from the top tip of the shoulder blade up to the top four joints of the neck. The <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">Levator Scapula </a>lifts the shoulder blade and helps control side-to-side movement of the head. A Trigger Point in the Levator Scapula muscle can cause pain behind the head and to the back of the neck. Find directions to stretch the Levator Scapula <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">here</a>.

<b>Muscle #3: Sub-Occipital Muscles</b>

Your sub-occipital muscles are a group of small muscles below the base of your skull at the back of your neck. These muscles control fine movements of your head. Trigger Points in this group of muscles will refer pain into your forehead and behind your eyes.

Due to the complexity of movements required to stretch the sub-occipital muscles I’m going to suggest gentle self-massage at the space between your neck and the base of your skull.
<div></div>","Tension Headaches","","inherit","open","open","","253-revision-v1","","","2014-01-13 19:52:08","2014-01-13 19:52:08","","253","http://www.kwmassage.com/generalmassagetherapy/253-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("271","3","2014-01-13 20:24:07","2014-01-13 20:24:07","Your headache can leave you feeling helpless. You might be surprised to learn that there are things we can do to improve or prevent the crippling pain of a headache without the use of Tylenol, Advil, or other pain controlling medications.  Regular <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">stretching</a>, exercise, and <a href=\"http://www.kwmassage.com/\">massage therapy </a>can bring so much relief you would wonder why you never tried these simple ideas before.

The most common cause for your headache is Referral Pain from muscle tension in your neck and shoulders. Overuse of vulnerable muscles can cause large painful knots in your muscles called<a title=\"Trigger Points and Trigger Point Therapy\" href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\"> Trigger Points</a>. The pain created by Trigger Points is not always located in the area of the Trigger Point itself. Referred pain from the muscles in your neck and shoulders is often called a tension headache.

To reduce your tension headache, you need to relax the <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">affected muscles </a>and reduce these Trigger Points. Three ways for you to do this are to:

* Relax the muscle through the application of heat
* Stretch the effected muscle
* Massage therapy

I have detailed a few general neck stretches and exercises below. These stretches target muscles that commonly cause a tension headache. Gentle massage from a loved one can be very beneficial but could potentially cause irritation to the Trigger Point. <a href=\"http://www.kwmassage.com/about\">A registered massage therapist </a>is highly skilled in Trigger Point release.

Be sure to review to my <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">General Guidelines for stretching </a>before doing any of the stretches I demonstrate and recommend. It’s always a good idea to see a <a href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">health care professional </a>before starting a new exercise program.

<b>Muscle #1: Upper Trapezius</b>

The <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">Upper Trapezius </a>is a flat triangular muscle that runs from the base of your skull and neck to your shoulder. The <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">Upper Trapezius </a>elevates the shoulder and supports the shoulder girdle when lifting a load. An Upper Trapezius muscle Trigger Point will commonly create pain around the ear and into the temple. Find directions on how to stretch the upper trapezius muscle <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">here</a>.

<b>Muscle #2: Levator Scapula</b>

The <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">Levator Scapula </a>muscle runs from the top tip of the shoulder blade up to the top four joints of the neck. The <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">Levator Scapula </a>lifts the shoulder blade and helps control side-to-side movement of the head. A Trigger Point in the Levator Scapula muscle can cause pain behind the head and to the back of the neck. Find directions to stretch the Levator Scapula <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">here</a>.

<b>Muscle #3: Sub-Occipital Muscles</b>

Your sub-occipital muscles are a group of small muscles below the base of your skull at the back of your neck. These muscles control fine movements of your head. Trigger Points in this group of muscles will refer pain into your forehead and behind your eyes.

Due to the complexity of movements required to stretch the sub-occipital muscles I’m going to suggest gentle self-massage at the space between your neck and the base of your skull.
<div></div>","Tension Headaches","","inherit","open","open","","253-revision-v1","","","2014-01-13 20:24:07","2014-01-13 20:24:07","","253","http://www.kwmassage.com/generalmassagetherapy/253-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("256","3","2014-01-13 19:52:45","2014-01-13 19:52:45","Your headache can leave you feeling helpless. You might be surprised to learn that there are things we can do to improve or prevent the crippling pain of a headache without the use of Tylenol, Advil, or other pain controlling medications.  Regular <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">stretching</a>, exercise, and <a href=\"http://www.kwmassage.com/\">massage therapy </a>can bring so much relief you would wonder why you never tried these simple ideas before.

The most common cause for your headache is Referral Pain from muscle tension in your neck and shoulders. Overuse of vulnerable muscles can cause large painful knots in your muscles called<a title=\"Trigger Points and Trigger Point Therapy\" href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\"> Trigger Points</a>. The pain created by Trigger Points is not always located in the area of the Trigger Point itself. Referred pain from the muscles in your neck and shoulders is often called a tension headache.

To reduce your tension headache, you need to relax the <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">affected muscles </a>and reduce these Trigger Points. Three ways for you to do this are to:
<ol>
	<li>relax the muscle through the <a href=\"http://www.kwmassage.com/generalmassagetherapy/epsom-salt-bath\">application of heat</a></li>
	<li>stretch the effected muscle</li>
	<li>massage therapy</li>
</ol>
I have detailed a few general neck stretches and exercises below. These stretches target muscles that commonly cause a tension headache. Gentle massage from a loved one can be very beneficial but could potentially cause irritation to the Trigger Point. <a href=\"http://www.kwmassage.com/about\">A registered massage therapist </a>is highly skilled in Trigger Point release.

Be sure to review to my <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">General Guidelines for stretching </a>before doing any of the stretches I demonstrate and recommend. It’s always a good idea to see a <a href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">health care professional </a>before starting a new exercise program.

<b>Muscle #1: Upper Trapezius</b>

The <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">Upper Trapezius </a>is a flat triangular muscle that runs from the base of your skull and neck to your shoulder. The <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">Upper Trapezius </a>elevates the shoulder and supports the shoulder girdle when lifting a load. An Upper Trapezius muscle Trigger Point will commonly create pain around the ear and into the temple. Find directions on how to stretch the upper trapezius muscle <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">here</a>.

<b>Muscle #2: Levator Scapula</b>

The <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">Levator Scapula </a>muscle runs from the top tip of the shoulder blade up to the top four joints of the neck. The <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">Levator Scapula </a>lifts the shoulder blade and helps control side-to-side movement of the head. A Trigger Point in the Levator Scapula muscle can cause pain behind the head and to the back of the neck. Find directions to stretch the Levator Scapula <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">here</a>.

<b>Muscle #3: Sub-Occipital Muscles</b>

Your sub-occipital muscles are a group of small muscles below the base of your skull at the back of your neck. These muscles control fine movements of your head. Trigger Points in this group of muscles will refer pain into your forehead and behind your eyes.

Due to the complexity of movements required to stretch the sub-occipital muscles I’m going to suggest gentle self-massage at the space between your neck and the base of your skull.
<div></div>","Tension Headaches","","inherit","open","open","","253-revision-v1","","","2014-01-13 19:52:45","2014-01-13 19:52:45","","253","http://www.kwmassage.com/generalmassagetherapy/253-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("257","3","2014-01-13 19:55:07","0000-00-00 00:00:00","•Your Massage Therapist is a regulated Health Care professional who has received two years of comprehensive training in anatomy, physiology, and health sciences.

•Massage Therapy in Ontario is regulated under the RHPA (Regulated Health Professionals Act), the same governing body that oversees nurses and physicians. This requires that your Massage Therapist conducts his/her practice in a way that offers his/her clients a safe and professional experience.

•Most extended Health Care companies cover Massage Therapy in part or in whole.

•If you plan to claim your Massage Therapy treatment, please contact your insurance company and find out whether you need a referral from your doctor in order to be reimbursed.","Facts about Registered Massage Therapy in Ontario ","","draft","open","open","","","","","2014-01-13 19:55:07","2014-01-13 19:55:07","","0","http://www.kwmassage.com/?p=257","0","post","","0");
INSERT INTO `wp_posts` VALUES("258","3","2014-01-13 19:56:59","2014-01-13 19:56:59","<a title=\"Kitchener Massage Therapy Welcome Video\" href=\"http://youtu.be/XSRrvEXZSdk\" target=\"_blank\" rel=\"http://youtu.be/XSRrvEXZSdk\"><img class=\" wp-image-155 alignleft\" alt=\"Jeremy Bissonnette, Registered Massage Therapist\" src=\"http://www.kwmassage.com/wp-content/uploads/2014/01/img_video-300x276.gif\" width=\"240\" height=\"221\" /></a>I graduated with Honours from the <a href=\"http://www.collegeofmassage.com/cambridge/\">Canadian College of Massage and Hydrotherapy </a>in 2005 as a <a href=\"http://www.cmto.com/\">Registered Massage Therapist </a>(RMT). I’ve practiced massage therapy in Kitchener and Waterloo in a variety of locations in including a home practice, the <a href=\"http://www.uoguelph.ca/hpc/\">University of Guelph’s Health and Performance Center, </a>and most recently, in an independently owned chiropractic office. I have also provided chair treatments at the <a href=\"http://www.kitchenermarket.ca/\">Kitchener Market </a>on a monthly basis in the past.

My massage therapy treatment style has been focused around <a href=\"http://www.kwmassage.com/deleteme/what-is-deep-tissue-massage\">Deep Tissue Therapy </a>with an emphasis on helping clients learn to care for their own bodies. I have practiced yoga for the past 10 years and find my clients respond well to my recommendations around specific yoga asana and stretches to help with the different ailments they need to address. I find my knowledge of anatomy helps create clarity on the yoga mat and I have an interest in sharing this experience.
<div class=\"shadowbox\">
<h2>My Personal World</h2>
My main focus in life is caring for my 2 daughters, Rowan (7) and Breanne (5). I’m busy getting kids fed, dressed, doing hair, making bread, doing homework and housework, planning a garden, and all the activities associated with being a parent. Being a dad can have its challenges but it is also very rewarding. I feel very lucky to be able to fill this role while my wife works full-time.

In my spare time, I enjoy <a href=\"http://www.kwmassage.com/rock_climbing/rock-climbing-as-a-life-style\">rock climbing</a>, yoga, reading, camping, and gardening. Prior to becoming a registered massage therapist, I used to work in a <a href=\"http://www.paramountsports.ca/\">bike and snow board shop</a>, so when I can, I love to hit the hills and get back to my original roots.

</div>","About","","inherit","open","open","","19-revision-v1","","","2014-01-13 19:56:59","2014-01-13 19:56:59","","19","http://www.kwmassage.com/generalmassagetherapy/19-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("259","3","2014-01-13 20:01:57","2014-01-13 20:01:57","• Your Massage Therapist in Ontario is a regulated Health Care professional who has received two years of comprehensive training in anatomy, physiology, and health sciences.
• <a title=\"Registered Massage Therapy in Ontario\" href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">Massage Therapy in Ontario</a> is regulated under the <a title=\"RHPA\" href=\"http://74.213.160.105/oahai/Acrobatfiles/regulatedact.pdf\" target=\"_blank\">RHPA (Regulated Health Professionals Act)</a>, the same governing body that oversees nurses and physicians. This requires that your Massage Therapist conducts his/her practice in a way that offers his/her clients a safe and professional experience.
• Most extended Health Care companies cover Massage Therapy in part or in whole.
• If you plan to claim your Massage Therapy treatment, please contact your insurance company and find out whether you need a referral from your doctor in order to be reimbursed.","Facts","","publish","open","open","","facts-about-registered-massage-therapy-in-ontario","","","2014-01-13 20:12:18","2014-01-13 20:12:18","","20","http://www.kwmassage.com/?page_id=259","0","page","","0");
INSERT INTO `wp_posts` VALUES("263","3","2014-01-13 20:05:17","2014-01-13 20:05:17","• Your Massage Therapist is a regulated Health Care professional who has received two years of comprehensive training in anatomy, physiology, and health sciences.
• Massage Therapy in Ontario is regulated under the RHPA (Regulated Health Professionals Act), the same governing body that oversees nurses and physicians. This requires that your Massage Therapist conducts his/her practice in a way that offers his/her clients a safe and professional experience.
• Most extended Health Care companies cover Massage Therapy in part or in whole.
• If you plan to claim your Massage Therapy treatment, please contact your insurance company and find out whether you need a referral from your doctor in order to be reimbursed.","Facts","","inherit","open","open","","259-revision-v1","","","2014-01-13 20:05:17","2014-01-13 20:05:17","","259","http://www.kwmassage.com/generalmassagetherapy/259-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("264","3","2014-01-13 20:05:54","2014-01-13 20:05:54","• Your Massage Therapist is a regulated Health Care professional who has received two years of comprehensive training in anatomy, physiology, and health sciences.</br>
• Massage Therapy in Ontario is regulated under the RHPA (Regulated Health Professionals Act), the same governing body that oversees nurses and physicians. This requires that your Massage Therapist conducts his/her practice in a way that offers his/her clients a safe and professional experience.</br>
• Most extended Health Care companies cover Massage Therapy in part or in whole.</br>
• If you plan to claim your Massage Therapy treatment, please contact your insurance company and find out whether you need a referral from your doctor in order to be reimbursed.</br>","Facts","","inherit","open","open","","259-revision-v1","","","2014-01-13 20:05:54","2014-01-13 20:05:54","","259","http://www.kwmassage.com/generalmassagetherapy/259-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("262","3","2014-01-13 20:03:00","2014-01-13 20:03:00","<p class=\"MsoNormal\" style=\"mso-margin-top-alt: auto; mso-margin-bottom-alt: auto; line-height: normal;\"><span style=\"font-size: 12.0pt; font-family: \'Times New Roman\',\'serif\'; mso-fareast-font-family: \'Times New Roman\'; mso-fareast-language: EN-CA;\">•Your Massage Therapist is a regulated Health Care professional who has received two years of comprehensive training in anatomy, physiology, and health sciences.</span></p>
<p class=\"MsoNormal\" style=\"mso-margin-top-alt: auto; mso-margin-bottom-alt: auto; line-height: normal;\"><span style=\"font-size: 12.0pt; font-family: \'Times New Roman\',\'serif\'; mso-fareast-font-family: \'Times New Roman\'; mso-fareast-language: EN-CA;\">•Massage Therapy in Ontario is regulated under the RHPA (Regulated Health Professionals Act), the same governing body that oversees nurses and physicians. This requires that your Massage Therapist conducts his/her practice in a way that offers his/her clients a safe and professional experience.</span></p>
<p class=\"MsoNormal\" style=\"mso-margin-top-alt: auto; mso-margin-bottom-alt: auto; line-height: normal;\"><span style=\"font-size: 12.0pt; font-family: \'Times New Roman\',\'serif\'; mso-fareast-font-family: \'Times New Roman\'; mso-fareast-language: EN-CA;\">•Most extended Health Care companies cover Massage Therapy in part or in whole.</span></p>
&nbsp;
<p class=\"MsoNormal\" style=\"mso-margin-top-alt: auto; mso-margin-bottom-alt: auto; line-height: normal;\"><span style=\"font-size: 12.0pt; font-family: \'Times New Roman\',\'serif\'; mso-fareast-font-family: \'Times New Roman\'; mso-fareast-language: EN-CA;\">•If you plan to claim your Massage Therapy treatment, please contact your insurance company and find out whether you need a referral from your doctor in order to be reimbursed. </span></p>","Facts","","inherit","open","open","","259-revision-v1","","","2014-01-13 20:03:00","2014-01-13 20:03:00","","259","http://www.kwmassage.com/generalmassagetherapy/259-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("260","3","2014-01-13 20:01:57","2014-01-13 20:01:57","<p class=\"MsoNormal\" style=\"mso-margin-top-alt: auto; mso-margin-bottom-alt: auto; line-height: normal;\"><span style=\"font-size: 12.0pt; font-family: \'Times New Roman\',\'serif\'; mso-fareast-font-family: \'Times New Roman\'; mso-fareast-language: EN-CA;\">•Your Massage Therapist is a regulated Health Care professional who has received two years of comprehensive training in anatomy, physiology, and health sciences.</span></p>
<p class=\"MsoNormal\" style=\"mso-margin-top-alt: auto; mso-margin-bottom-alt: auto; line-height: normal;\"><span style=\"font-size: 12.0pt; font-family: \'Times New Roman\',\'serif\'; mso-fareast-font-family: \'Times New Roman\'; mso-fareast-language: EN-CA;\">•Massage Therapy in Ontario is regulated under the RHPA (Regulated Health Professionals Act), the same governing body that oversees nurses and physicians. This requires that your Massage Therapist conducts his/her practice in a way that offers his/her clients a safe and professional experience.</span></p>
<p class=\"MsoNormal\" style=\"mso-margin-top-alt: auto; mso-margin-bottom-alt: auto; line-height: normal;\"><span style=\"font-size: 12.0pt; font-family: \'Times New Roman\',\'serif\'; mso-fareast-font-family: \'Times New Roman\'; mso-fareast-language: EN-CA;\">•Most extended Health Care companies cover Massage Therapy in part or in whole.</span></p>
&nbsp;
<p class=\"MsoNormal\" style=\"mso-margin-top-alt: auto; mso-margin-bottom-alt: auto; line-height: normal;\"><span style=\"font-size: 12.0pt; font-family: \'Times New Roman\',\'serif\'; mso-fareast-font-family: \'Times New Roman\'; mso-fareast-language: EN-CA;\">•If you plan to claim your Massage Therapy treatment, please contact your insurance company and find out whether you need a referral from your doctor in order to be reimbursed. </span></p>","Facts about Registered Massage Therapy in Ontario ","","inherit","open","open","","259-revision-v1","","","2014-01-13 20:01:57","2014-01-13 20:01:57","","259","http://www.kwmassage.com/generalmassagetherapy/259-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("261","3","2014-01-13 20:10:05","2014-01-13 20:10:05","• Your Massage Therapist in Ontario is a regulated Health Care professional who has received two years of comprehensive training in anatomy, physiology, and health sciences.
• Massage Therapy in Ontario is regulated under the RHPA (Regulated Health Professionals Act), the same governing body that oversees nurses and physicians. This requires that your Massage Therapist conducts his/her practice in a way that offers his/her clients a safe and professional experience.
• Most extended Health Care companies cover Massage Therapy in part or in whole.
• If you plan to claim your Massage Therapy treatment, please contact your insurance company and find out whether you need a referral from your doctor in order to be reimbursed.","Facts","","inherit","open","open","","259-autosave-v1","","","2014-01-13 20:10:05","2014-01-13 20:10:05","","259","http://www.kwmassage.com/generalmassagetherapy/259-autosave-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("265","3","2014-01-13 20:07:37","2014-01-13 20:07:37","Massage therapy is a <a title=\"Facts about Registered Massage Therapy\" href=\"http://www.kwmassage.com/knowledge-centre/facts-about-registered-massage-therapy-in-ontario\">regulated health profession</a>. The <a href=\"http://www.cmto.com/\">College of Massage Therapist of Ontario </a>(CMTO) is the governing board that oversees and regulates <a href=\"http://www.kwmassage.com/\">massage therapists in Ontario</a>. If you have any questions related to the governance of massage therapy in Ontario, <a href=\"http://www.cmto.com/\">http://www.cmto.com/</a> is a great resource.

The <a href=\"http://www.rmtao.com/\">Registered Massage Therapists’ Association of Ontario</a>(RMTAO) is the association that supports massage therapists in Ontario. They lobby the government on behalf of all massage therapists in Ontario. They are the association that fought to get massage therapy into the Regulated Health Professionals Act (RHPA). Massage therapy being part of the RHPA is what allows you to have <a href=\"http://www.kwmassage.com/generalmassagetherapy/facts-about-registered-massage-therapy-in-ontario\">massage therapy coverage </a>in your extended health benefits plan. The RMTAO did their best to avoid the new <a href=\"http://www.kwmassage.com/generalmassagetherapy/registered-massage-therapy-and-hst\">Harmonized Sales Tax </a>(HST) from affecting the rate of massage therapy in Ontario. The <span style=\"text-decoration: underline;\">RMTAO</span> is a great education resource.

The RMTAO also has a sister website <a href=\"http://www.rmtfind.com/\">RMTfind.com</a> that will allow you to search by <a href=\"http://www.kwmassage.com/contact\">location for a massage therapist </a>in your area.","Governance of massage therapy ","","inherit","open","open","","251-autosave-v1","","","2014-01-13 20:07:37","2014-01-13 20:07:37","","251","http://www.kwmassage.com/generalmassagetherapy/251-autosave-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("266","3","2014-01-13 20:08:38","2014-01-13 20:08:38","Massage therapy is a <a href=\"http://www.kwmassage.com/knowledge-centre/facts-about-registered-massage-therapy-in-ontario\">regulated health profession</a>. The <a href=\"http://www.cmto.com/\">College of Massage Therapist of Ontario </a>(CMTO) is the governing board that oversees and regulates <a href=\"http://www.kwmassage.com/\">massage therapists in Ontario</a>. If you have any questions related to the governance of massage therapy in Ontario, <a href=\"http://www.cmto.com/\">http://www.cmto.com/</a> is a great resource.

The <a href=\"http://www.rmtao.com/\">Registered Massage Therapists’ Association of Ontario</a>(RMTAO) is the association that supports massage therapists in Ontario. They lobby the government on behalf of all massage therapists in Ontario. They are the association that fought to get massage therapy into the Regulated Health Professionals Act (RHPA). Massage therapy being part of the RHPA is what allows you to have <a href=\"http://www.kwmassage.com/generalmassagetherapy/facts-about-registered-massage-therapy-in-ontario\">massage therapy coverage </a>in your extended health benefits plan. The RMTAO did their best to avoid the new <a href=\"http://www.kwmassage.com/generalmassagetherapy/registered-massage-therapy-and-hst\">Harmonized Sales Tax </a>(HST) from affecting the rate of massage therapy in Ontario. The <span style=\"text-decoration: underline;\">RMTAO</span> is a great education resource.

The RMTAO also has a sister website <a href=\"http://www.rmtfind.com/\">RMTfind.com</a> that will allow you to search by <a href=\"http://www.kwmassage.com/contact\">location for a massage therapist </a>in your area.","Governance of massage therapy ","","inherit","open","open","","251-revision-v1","","","2014-01-13 20:08:38","2014-01-13 20:08:38","","251","http://www.kwmassage.com/generalmassagetherapy/251-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("267","3","2014-01-13 20:10:56","2014-01-13 20:10:56","• Your Massage Therapist in Ontario is a regulated Health Care professional who has received two years of comprehensive training in anatomy, physiology, and health sciences.
• <a title=\"Registered Massage Therapy in Ontario\" href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">Massage Therapy in Ontario</a> is regulated under the RHPA (Regulated Health Professionals Act), the same governing body that oversees nurses and physicians. This requires that your Massage Therapist conducts his/her practice in a way that offers his/her clients a safe and professional experience.
• Most extended Health Care companies cover Massage Therapy in part or in whole.
• If you plan to claim your Massage Therapy treatment, please contact your insurance company and find out whether you need a referral from your doctor in order to be reimbursed.","Facts","","inherit","open","open","","259-revision-v1","","","2014-01-13 20:10:56","2014-01-13 20:10:56","","259","http://www.kwmassage.com/generalmassagetherapy/259-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("268","3","2014-01-13 20:12:18","2014-01-13 20:12:18","• Your Massage Therapist in Ontario is a regulated Health Care professional who has received two years of comprehensive training in anatomy, physiology, and health sciences.
• <a title=\"Registered Massage Therapy in Ontario\" href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">Massage Therapy in Ontario</a> is regulated under the <a title=\"RHPA\" href=\"http://74.213.160.105/oahai/Acrobatfiles/regulatedact.pdf\" target=\"_blank\">RHPA (Regulated Health Professionals Act)</a>, the same governing body that oversees nurses and physicians. This requires that your Massage Therapist conducts his/her practice in a way that offers his/her clients a safe and professional experience.
• Most extended Health Care companies cover Massage Therapy in part or in whole.
• If you plan to claim your Massage Therapy treatment, please contact your insurance company and find out whether you need a referral from your doctor in order to be reimbursed.","Facts","","inherit","open","open","","259-revision-v1","","","2014-01-13 20:12:18","2014-01-13 20:12:18","","259","http://www.kwmassage.com/generalmassagetherapy/259-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("269","3","2014-01-13 20:13:43","2014-01-13 20:13:43","The quickest way to book an appointment with me is to <a href=\"http://www.kwmassage.com/clinic-information\">book a treatment online</a>.

To get in touch with me directly to make a <a title=\"Book Massage Therapy Appointment Online\" href=\"http://www.kwmassage.com/clinic-information\">massage therapy appointment </a>in Kitchener/Waterloo, you can call me, send me an email or text message, or you can <a href=\"http://www.facebook.com/pages/KWmassage/354131367967709\">Facebook</a> me. You can also use the form below to send me a message.

229 Frederick Street
Kitchener, ON
(519) 745-4112
<a href=\"mailto:Jeremy@kwmassage.com\">Jeremy@kwmassage.com</a>
<div></div>
<iframe src=\"https://mapsengine.google.com/map/embed?mid=z1kzsRant038.kwaZ-HV4FUfg\" height=\"400\" width=\"550\"></iframe>
<div id=\"formbox\">
<h1>Contact Form</h1>
</div>
[contact-form-7 id=\"9\" title=\"Contact form 1\"]","Contact","","inherit","open","open","","21-revision-v1","","","2014-01-13 20:13:43","2014-01-13 20:13:43","","21","http://www.kwmassage.com/generalmassagetherapy/21-revision-v1","0","revision","","0");
INSERT INTO `wp_posts` VALUES("270","3","2014-01-13 20:23:42","2014-01-13 20:23:42","Your headache can leave you feeling helpless. You might be surprised to learn that there are things we can do to improve or prevent the crippling pain of a headache without the use of Tylenol, Advil, or other pain controlling medications.  Regular <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">stretching</a>, exercise, and <a href=\"http://www.kwmassage.com/\">massage therapy </a>can bring so much relief you would wonder why you never tried these simple ideas before.

The most common cause for your headache is Referral Pain from muscle tension in your neck and shoulders. Overuse of vulnerable muscles can cause large painful knots in your muscles called<a title=\"Trigger Points and Trigger Point Therapy\" href=\"http://www.kwmassage.com/generalmassagetherapy/trigger-points-and-trigger-point-therapy\"> Trigger Points</a>. The pain created by Trigger Points is not always located in the area of the Trigger Point itself. Referred pain from the muscles in your neck and shoulders is often called a tension headache.

To reduce your tension headache, you need to relax the <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">affected muscles </a>and reduce these Trigger Points. Three ways for you to do this are to:

Relax the muscle through the application of heat
Stretch the effected muscle
Massage therapy

I have detailed a few general neck stretches and exercises below. These stretches target muscles that commonly cause a tension headache. Gentle massage from a loved one can be very beneficial but could potentially cause irritation to the Trigger Point. <a href=\"http://www.kwmassage.com/about\">A registered massage therapist </a>is highly skilled in Trigger Point release.

Be sure to review to my <a href=\"http://www.kwmassage.com/stretching/general-guidelines-for-stretching\">General Guidelines for stretching </a>before doing any of the stretches I demonstrate and recommend. It’s always a good idea to see a <a href=\"http://www.kwmassage.com/generalmassagetherapy/governance-of-massage-therapy\">health care professional </a>before starting a new exercise program.

<b>Muscle #1: Upper Trapezius</b>

The <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">Upper Trapezius </a>is a flat triangular muscle that runs from the base of your skull and neck to your shoulder. The <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">Upper Trapezius </a>elevates the shoulder and supports the shoulder girdle when lifting a load. An Upper Trapezius muscle Trigger Point will commonly create pain around the ear and into the temple. Find directions on how to stretch the upper trapezius muscle <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">here</a>.

<b>Muscle #2: Levator Scapula</b>

The <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">Levator Scapula </a>muscle runs from the top tip of the shoulder blade up to the top four joints of the neck. The <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">Levator Scapula </a>lifts the shoulder blade and helps control side-to-side movement of the head. A Trigger Point in the Levator Scapula muscle can cause pain behind the head and to the back of the neck. Find directions to stretch the Levator Scapula <a href=\"http://www.kwmassage.com/stretching/stretch-your-upper-trapezius-muscle\">here</a>.

<b>Muscle #3: Sub-Occipital Muscles</b>

Your sub-occipital muscles are a group of small muscles below the base of your skull at the back of your neck. These muscles control fine movements of your head. Trigger Points in this group of muscles will refer pain into your forehead and behind your eyes.

Due to the complexity of movements required to stretch the sub-occipital muscles I’m going to suggest gentle self-massage at the space between your neck and the base of your skull.
<div></div>","Tension Headaches","","inherit","open","open","","253-autosave-v1","","","2014-01-13 20:23:42","2014-01-13 20:23:42","","253","http://www.kwmassage.com/generalmassagetherapy/253-autosave-v1","0","revision","","0");


DROP TABLE IF EXISTS `wp_term_relationships`;

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `wp_term_relationships` VALUES("226","8","0");
INSERT INTO `wp_term_relationships` VALUES("249","10","0");
INSERT INTO `wp_term_relationships` VALUES("216","1","0");
INSERT INTO `wp_term_relationships` VALUES("219","1","0");
INSERT INTO `wp_term_relationships` VALUES("221","1","0");
INSERT INTO `wp_term_relationships` VALUES("244","10","0");
INSERT INTO `wp_term_relationships` VALUES("211","1","0");
INSERT INTO `wp_term_relationships` VALUES("241","1","0");
INSERT INTO `wp_term_relationships` VALUES("253","1","0");
INSERT INTO `wp_term_relationships` VALUES("257","1","0");
INSERT INTO `wp_term_relationships` VALUES("251","1","0");
INSERT INTO `wp_term_relationships` VALUES("105","8","0");
INSERT INTO `wp_term_relationships` VALUES("106","8","0");
INSERT INTO `wp_term_relationships` VALUES("107","8","0");
INSERT INTO `wp_term_relationships` VALUES("108","8","0");
INSERT INTO `wp_term_relationships` VALUES("109","8","0");


DROP TABLE IF EXISTS `wp_term_taxonomy`;

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO `wp_term_taxonomy` VALUES("1","1","category","General information about Registered massage therapy from Kitchener massage therapy.","0","6");
INSERT INTO `wp_term_taxonomy` VALUES("5","5","nav_menu","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("8","8","nav_menu","","0","6");
INSERT INTO `wp_term_taxonomy` VALUES("10","10","category","","0","2");


DROP TABLE IF EXISTS `wp_terms`;

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO `wp_terms` VALUES("1","General Massage Therapy","generalmassagetherapy","0");
INSERT INTO `wp_terms` VALUES("5","Main Menu","main-menu","0");
INSERT INTO `wp_terms` VALUES("8","Footer Menu","footer-menu","0");
INSERT INTO `wp_terms` VALUES("10","Stretching","stretching","0");


DROP TABLE IF EXISTS `wp_usermeta`;

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

INSERT INTO `wp_usermeta` VALUES("1","3","first_name","Jeremy");
INSERT INTO `wp_usermeta` VALUES("2","3","last_name","Bissonnette");
INSERT INTO `wp_usermeta` VALUES("3","3","nickname","Jeremy");
INSERT INTO `wp_usermeta` VALUES("4","3","description","");
INSERT INTO `wp_usermeta` VALUES("5","3","rich_editing","true");
INSERT INTO `wp_usermeta` VALUES("6","3","comment_shortcuts","false");
INSERT INTO `wp_usermeta` VALUES("7","3","admin_color","fresh");
INSERT INTO `wp_usermeta` VALUES("8","3","use_ssl","0");
INSERT INTO `wp_usermeta` VALUES("9","3","show_admin_bar_front","false");
INSERT INTO `wp_usermeta` VALUES("10","3","wp_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `wp_usermeta` VALUES("11","3","wp_user_level","10");
INSERT INTO `wp_usermeta` VALUES("12","3","dismissed_wp_pointers","wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks,aioseop_menu_211,aioseop_welcome_211");
INSERT INTO `wp_usermeta` VALUES("13","3","show_welcome_panel","1");
INSERT INTO `wp_usermeta` VALUES("14","3","wp_dashboard_quick_press_last_post_id","3");
INSERT INTO `wp_usermeta` VALUES("15","3","wp_user-settings","editor=tinymce&libraryContent=browse&wplink=1&align=left&urlbutton=post");
INSERT INTO `wp_usermeta` VALUES("16","3","wp_user-settings-time","1389643675");
INSERT INTO `wp_usermeta` VALUES("17","3","meta-box-order_page","a:3:{s:4:\"side\";s:36:\"submitdiv,pageparentdiv,postimagediv\";s:6:\"normal\";s:70:\"revisionsdiv,postcustom,commentstatusdiv,commentsdiv,slugdiv,authordiv\";s:8:\"advanced\";s:0:\"\";}");
INSERT INTO `wp_usermeta` VALUES("18","3","screen_layout_page","2");
INSERT INTO `wp_usermeta` VALUES("19","3","closedpostboxes_page","a:1:{i:0;s:12:\"postimagediv\";}");
INSERT INTO `wp_usermeta` VALUES("20","3","metaboxhidden_page","a:5:{i:0;s:12:\"revisionsdiv\";i:1;s:10:\"postcustom\";i:2;s:11:\"commentsdiv\";i:3;s:7:\"slugdiv\";i:4;s:9:\"authordiv\";}");
INSERT INTO `wp_usermeta` VALUES("21","3","nav_menu_recently_edited","8");
INSERT INTO `wp_usermeta` VALUES("22","3","managenav-menuscolumnshidden","a:4:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";}");
INSERT INTO `wp_usermeta` VALUES("23","3","metaboxhidden_nav-menus","a:2:{i:0;s:8:\"add-post\";i:1;s:12:\"add-post_tag\";}");
INSERT INTO `wp_usermeta` VALUES("40","3","metaboxhidden_post","a:8:{i:0;s:12:\"revisionsdiv\";i:1;s:11:\"postexcerpt\";i:2;s:13:\"trackbacksdiv\";i:3;s:10:\"postcustom\";i:4;s:16:\"commentstatusdiv\";i:5;s:11:\"commentsdiv\";i:6;s:7:\"slugdiv\";i:7;s:9:\"authordiv\";}");
INSERT INTO `wp_usermeta` VALUES("39","3","closedpostboxes_post","a:0:{}");
INSERT INTO `wp_usermeta` VALUES("38","3","metaboxhidden_toplevel_page_wpcf7","a:1:{i:0;s:7:\"formdiv\";}");
INSERT INTO `wp_usermeta` VALUES("37","3","closedpostboxes_toplevel_page_wpcf7","a:0:{}");
INSERT INTO `wp_usermeta` VALUES("36","3","googleplus","");


DROP TABLE IF EXISTS `wp_users`;

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `wp_users` VALUES("3","Elliot","$P$B4ct891IutvYyrjGhsAdZIAtfA3MNj/","admin","jeremy.kwmassage@gmail.com","","2014-01-10 10:46:52","$P$BBDUsasgi0aZkyc0ZLWZ0MW7hNWdLd.","0","Jeremy");


DROP TABLE IF EXISTS `wp_wpb2d_excluded_files`;

CREATE TABLE `wp_wpb2d_excluded_files` (
  `file` varchar(255) NOT NULL,
  `isdir` tinyint(1) NOT NULL,
  UNIQUE KEY `file` (`file`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `wp_wpb2d_options`;

CREATE TABLE `wp_wpb2d_options` (
  `name` varchar(50) NOT NULL,
  `value` varchar(255) NOT NULL,
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `wp_wpb2d_options` VALUES("database_version","2");
INSERT INTO `wp_wpb2d_options` VALUES("oauth_state","access");
INSERT INTO `wp_wpb2d_options` VALUES("request_token","CgD4O3O8dvB89QFh");
INSERT INTO `wp_wpb2d_options` VALUES("request_token_secret","7ZeWbsUQ6YuXoMup");
INSERT INTO `wp_wpb2d_options` VALUES("access_token","bezohr0qf2je49yh");
INSERT INTO `wp_wpb2d_options` VALUES("access_token_secret","qglmxsr5bh5nyvn");
INSERT INTO `wp_wpb2d_options` VALUES("store_in_subfolder","");
INSERT INTO `wp_wpb2d_options` VALUES("dropbox_location","");


DROP TABLE IF EXISTS `wp_wpb2d_processed_dbtables`;

CREATE TABLE `wp_wpb2d_processed_dbtables` (
  `name` varchar(255) NOT NULL,
  `count` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `wp_wpb2d_processed_files`;

CREATE TABLE `wp_wpb2d_processed_files` (
  `file` varchar(255) NOT NULL,
  `offset` int(11) NOT NULL DEFAULT '0',
  `uploadid` varchar(50) DEFAULT NULL,
  UNIQUE KEY `file` (`file`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;





